import { getLeaderboard } from '../firebase.js';

export const LeaderboardPlugin = {
  command: '/liderlik',
  icon: '🏆',
  description: 'Global liderlik tablosunu göster (En çok XP Kazananlar).',
  needsArg: false,
  async run({ input, args, user, memory, addBotMsg }) {
    addBotMsg("🏆 Liderlik tablosu sunucudan çekiliyor...", false);
    try {
        const board = await getLeaderboard();
        if (!board || board.length === 0) {
            addBotMsg("⚠️ Henüz kimse giriş yapmamış veya bulut sunucuya bağlanılamadı.");
            return;
        }
        let html = "<h2>🏆 Liderlik Tablosu (Top 10)</h2><div style='background:rgba(0,0,0,0.2);padding:10px;border-radius:8px;'>";
        board.forEach((u, idx) => {
            let medal = idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : '🔹';
            // KVKK / Gizlilik için sadece ismin ilk halini gösterelim (eğer kullanıcı isterse). 
            // Şu anlık tam isim gösteriyoruz (örnek amaçlı).
            let safeName = u.name || "İsimsiz Oyuncu";
            html += `<div style="display:flex; justify-content:space-between; margin-bottom: 5px; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 3px;">
                        <span>${medal} <b>${safeName}</b></span>
                        <span style="color:#fde047; font-weight:bold;">${u.xp} XP</span>
                     </div>`;
        });
        html += "</div>";
        addBotMsg(html, true);
    } catch (err) {
        console.error(err);
        addBotMsg("❌ Liderlik tablosu çekilemedi: " + err.message);
    }
  }
}
