import { saveUserData, getUserData, auth } from '../firebase.js';

export const AgendaPlugin = {
  command: '/ajanda',
  icon: '📅',
  description: 'Sınav veya ödev tarihlerini kaydet ve görüntüle.',
  needsArg: true,
  async run({ input, args, user, memory, addBotMsg }) {
    if (!args) {
      // Listele
      let agendaList = JSON.parse(localStorage.getItem('bot_agenda') || '[]');
      if (agendaList.length === 0) {
        addBotMsg("📅 Ajandanda hiç kayıt yok. Eklemek için:<br><b>/ajanda Matematik Sınavı (Yarın)</b>");
      } else {
        const html = "📅 <b>Yaklaşan Görev/Sınavların:</b><br>" + agendaList.map((a, i) => `[${i+1}] ${a}`).join('<br>');
        addBotMsg(html);
      }
      return;
    }
    
    // Ekle
    let agendaList = JSON.parse(localStorage.getItem('bot_agenda') || '[]');
    if (args.toLowerCase() === 'temizle') {
      agendaList = [];
      localStorage.setItem('bot_agenda', '[]');
      addBotMsg("✅ Ajanda temizlendi.");
      return;
    }
    
    agendaList.push(args);
    localStorage.setItem('bot_agenda', JSON.stringify(agendaList));
    
    // Buluta senkronize et
    if (auth.currentUser) {
        saveUserData(auth.currentUser.uid, { agenda: agendaList }).catch(console.error);
    }
    
    addBotMsg(`✅ Ajandaya eklendi: <b>${args}</b>`);
  }
}
