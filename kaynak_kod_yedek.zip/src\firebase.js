// Firebase entegrasyonu devre dışı
// Bu dosya gelecekte Firebase yapılandırıldığında kullanılacak.
// Şu an DEMO key'ler ile çalışmıyor, bu yüzden main.js'den import edilmiyor.
// Build'in patlamaması için (Agenda, Leaderboard kullananlar için) stub fonksyionlar eklendi:

export const saveUserData = async () => {};
export const getUserData = async () => null;
export const getLeaderboard = async () => [];
export const auth = { currentUser: null };
export const loginWithGoogle = async () => null;
export const logoutUser = async () => {};
export const onAuthStateChanged = () => {};
