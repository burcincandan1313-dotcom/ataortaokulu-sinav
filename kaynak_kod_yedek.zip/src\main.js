
// ================================================
// MEGA Asistan Bot v10.0 PRO — SECURITY HEADER
// ================================================

'use strict';

// PWA Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(err => console.warn("SW Registration:", err));
  });
}

'use strict';

// ===== PROXY ENDPOINT (Cloudflare Worker — Gemini Edition) =====
// Varsayılan proxy URL getProxyEndpoint() fonksiyonunda tanımlı.
// Kullanıcı kendi key'ini girerse doğrudan Gemini API kullanılır.
// Yerel geliştirme için Worker henüz deploy edilmemişse boş bırak,
// sistem otomatik olarak ücretsiz Pollinations AI'ya geçer.
// Worker backend: Google Gemini 1.5 Flash (ücretsiz, hızlı, Türkçe)

function getProxyEndpoint() {
  return 'https://mega-asistan-proxy.mega-asistan-burcan.workers.dev';
}

// Performans modu: ağır animasyonları devre dışı bırak
function isLowEndMode() {
  return localStorage.getItem('mega_lowend_mode') === 'true';
}
function applyPerformanceMode() {
  const lowEnd = isLowEndMode();
  const matrixEl = document.getElementById('matrixCanvas');
  const confettiEl = document.getElementById('confettiCanvas');
  const bgGlow = document.querySelector('.bg-glow');
  if (matrixEl) matrixEl.style.display = lowEnd ? 'none' : '';
  if (confettiEl) confettiEl.style.display = lowEnd ? 'none' : '';
  if (bgGlow) bgGlow.style.display = lowEnd ? 'none' : '';
  document.body.classList.toggle('lowend-mode', lowEnd);
}

// Firebase devre dışı (DEMO key - gerçek proje için firebase.js'i yapılandırın)
// Bu stub fonksiyonlar uygulama çalışmasını bozmaz
const loginWithGoogle = () => Promise.reject('Firebase yapılandırılmamış');
const logoutUser = () => {};
const saveUserData = () => Promise.resolve();
const getUserData = () => Promise.resolve(null);
const auth = { currentUser: null };
const onAuthStateChanged = () => {};

import { extractTextFromPDF } from './features/PDFReader.js';
import { AgendaPlugin } from './features/Agenda.js';
import { LeaderboardPlugin } from './features/Leaderboard.js';
import { StudyAnalyzer } from './features/StudyAnalyzer.js';

const studyAnalyzer = new StudyAnalyzer();

// PDF/TXT Upload event listeners
setTimeout(() => {
  const btnPdf = document.getElementById('btnUploadPdf');
  const inputPdf = document.getElementById('pdfUploadInput');
  if (btnPdf && inputPdf) {
    btnPdf.addEventListener('click', () => inputPdf.click());
    inputPdf.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const isText = file.type === 'text/plain' || file.name.endsWith('.txt');
      const isPdf = file.type === 'application/pdf';
      if (!isText && !isPdf) {
        alert("Lütfen PDF veya TXT dosyası yükleyin.");
        return;
      }
      try {
        addBotMsg("📄 Dosya okunuyor, lütfen bekleyin...", false);
        const text = isText ? await file.text() : await extractTextFromPDF(file);
        // metni belleğe ekle (uzun metinler için kes)
        const summary = text.substring(0, 1500); 
        Memory.remember("Son yüklenen belgenin özeti: " + summary);
        // StudyAnalyzer'a da yükle
        studyAnalyzer.loadText(text, file.name);
        addBotMsg("✅ " + file.name + " başarıyla yüklendi!<br><br>💡 <b>Ne yapabilirsiniz?</b><br>• <code>/ders-analiz</code> — Quiz oluştur<br>• ⚙️ Ayarlar → Ders Analiz sekmesi<br>• Doğrudan soru sorabilirsiniz", true);
        gainXP(15, "Dosya Okuma");
        updateQuest('pdf');
      } catch (err) {
        alert(err.message);
      } finally {
        inputPdf.value = ''; // Reset
      }
    });
  }
}, 1000);

// DOMPurify: npm paketinden import (dev + build uyumlu)
import DOMPurify from 'dompurify';

// ===== DOMPurify SAFE WRAPPER =====
// Tüm innerHTML noktaları bu fonksiyondan geçmeli.
// İzin verilen HTML etiketleri ve özellikler whitelist ile belirlendi.
function safeHTML(html) {
  if (!html) return '';
  if (typeof DOMPurify === 'undefined') {
    // Fallback: script tag'leri sil, temel koruma
    return html.replace(/<script[\s\S]*?<\/script>/gi, '')
               .replace(/javascript:/gi, '')
               .replace(/on\w+\s*=/gi, 'data-blocked=');
  }
  return DOMPurify.sanitize(html, {
    ALLOWED_TAGS: [
      'b', 'i', 'u', 'strong', 'em', 'br', 'span', 'div', 'p', 'a',
      'img', 'input', 'button', 'canvas', 'textarea', 'label', 'select',
      'option', 'h1', 'h2', 'h3', 'h4', 'ul', 'ol', 'li', 'table',
      'tr', 'td', 'th', 'thead', 'tbody', 'code', 'pre', 'blockquote',
      'iframe', 'form'
    ],
    ALLOWED_ATTR: [
      'style', 'id', 'class', 'href', 'src', 'alt', 'title',
      'type', 'value', 'placeholder', 'min', 'max', 'maxlength',
      'data-k', 'data-emoji', 'width', 'height', 'autocomplete',
      'disabled', 'checked', 'selected', 'multiple', 'rows', 'cols',
      // onclick vb. event handler'lar SADECE iç HTML için (bot mesajları)
      // Kullanıcı içeriği için bunları kaldır → safeUserContent() kullan
      'onclick', 'onkeypress', 'oninput', 'onmouseover', 'onmouseout',
      'onchange', 'onfocus', 'onblur'
    ],
    ALLOW_DATA_ATTR: true,
    FORCE_BODY: false,
  });
}

// Kullanıcı girdisi için SIKI sanitize (event handler'lar yok)
function safeUserContent(text) {
  if (!text) return '';
  if (typeof DOMPurify === 'undefined') {
    const d = document.createElement('div');
    d.textContent = text;
    return d.innerHTML;
  }
  return DOMPurify.sanitize(text, {
    ALLOWED_TAGS: ['b', 'i', 'br', 'span', 'a'],
    ALLOWED_ATTR: ['href', 'style', 'class'],
    ALLOW_DATA_ATTR: false,
  });
}
// ============================================
// MEGA Asistan Bot v10.0 PRO — Core Engine
// Part 1: Security + User + Memory + Intent + Plugins + Modes
// ============================================

// ===== 1. SECURITY & STORAGE =====
// btoa/atob kaldırıldı — sahte şifreleme güvenlik sağlamaz, düz JSON yeterlidir.
// Eski btoa verisini otomatik olarak düz JSON'a taşırız (migration).
const Storage = {
  set(k, v) { localStorage.setItem(k, JSON.stringify(v)); },
  get(k, def) {
    const raw = localStorage.getItem(k);
    if (!raw) return def;
    try {
      return JSON.parse(raw);
    } catch(e) {
      // Migration: eski btoa+encodeURIComponent verisini oku
      try {
        const migrated = JSON.parse(decodeURIComponent(atob(raw)));
        // Başarılıysa hemen düz JSON formatına güncelle
        localStorage.setItem(k, JSON.stringify(migrated));
        return migrated;
      } catch(e2) { return def; }
    }
  },
  remove(k) { localStorage.removeItem(k); }
};

const Security = {
  sanitize(input) {
    if (typeof DOMPurify !== 'undefined') return DOMPurify.sanitize(input);
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
  },
  timestamps: [],
  rateLimit(limit=15, window=60000) {
    const now = Date.now();
    this.timestamps = this.timestamps.filter(t => now - t < window);
    if (this.timestamps.length >= limit) return false;
    this.timestamps.push(now);
    return true;
  },
  validate(input) {
    if (!input || !input.trim()) return { valid: false, msg: '' };
    if (input.length > 500) return { valid: false, msg: 'Maksimum 500 karakter!' };
    if (/<script/i.test(input)) return { valid: false, msg: 'Güvenlik: Script engellendi.' };
    return { valid: true };
  }
};

// ============================================
// 1. GLOBAL APP STATE
// ============================================
const AppState = {
  botState: 'NORMAL',
  proMode: 'NORMAL',
  currentMode: 'normal',
  currentChar: 'normal',
  isMicOn: false,
  isMatrixRunning: false,
  matrixRAF: null,
  isStreaming: false,
  streamStop: false,
  activeGame: null,
  gameInterval: null,
  gameRAF: null,
  modeState: {},
  cache: { weather: null, currency: null, lastUpdate: 0 }
};

// ===== 2. USER SYSTEM =====
const AVATARS = [
  { id: 'boy', src: '👦', label: 'Öğrenci (E)' },
  { id: 'girl', src: '👧', label: 'Öğrenci (K)' },
  { id: 'robot', src: '🤖', label: 'Robot' },
  { id: 'cat', src: '🐱', label: 'Kedi' },
  { id: 'fox', src: '🦊', label: 'Tilki' },
  { id: 'panda', src: '🐼', label: 'Panda' },
];
let userProfile = Storage.get('bot_user', null);

function createUser(name, avatar) {
  userProfile = {
    id: 'usr_' + Date.now(),
    name: name,
    avatar: avatar || '👦',
    level: 0,
    xp: 0,
    interests: [],
    personality: 'normal',
    streak: 0,
    lastLogin: Date.now(),
    questsToday: {},
    createdAt: Date.now()
  };
  saveUser();
  return userProfile;
}

function saveUser() {
  Storage.set('bot_user', userProfile);
  if (userProfile && auth.currentUser) {
    saveUserData(auth.currentUser.uid, userProfile).catch(console.error);
  }
}

// Google Login butonu — Firebase yapılandırılmadığı için bilgilendirici mesaj göster
setTimeout(() => {
  const btnLoginG = document.getElementById('btnLoginGoogle');
  if (btnLoginG) {
    btnLoginG.onclick = () => {
      alert('Google ile giriş henüz yapılandırılmamıştır.\nLütfen "Misafir Girişi" veya isim yazarak giriş yapın.');
    };
  }
}, 500);

function checkStreak() {
  if (!userProfile) return;
  const now = new Date();
  const last = new Date(userProfile.lastLogin);
  const dayDiff = Math.floor((now - last) / 86400000);
  if (dayDiff === 1) {
    userProfile.streak++;
    const bonus = Math.min(5 + userProfile.streak * 5, 50);
    gainXP(bonus, 'Gün streak: ' + userProfile.streak + ' gün!');
  } else if (dayDiff > 1) {
    userProfile.streak = 1;
  }
  // Reset daily quests if new day
  const todayKey = now.toISOString().slice(0, 10);
  if (!userProfile.questsToday || userProfile.questsToday._date !== todayKey) {
    userProfile.questsToday = { _date: todayKey };
  }
  userProfile.lastLogin = Date.now();
  saveUser();
}

function showOnboarding() {
  const overlay = document.getElementById('onboardOverlay');
  if (!overlay) return;
  overlay.style.display = 'flex';
  const picker = document.getElementById('avatarPicker');
  if (picker) {
    picker.innerHTML = AVATARS.map(a =>
      `<span class="avatar-opt" onclick="selectAvatar(this,'${a.src}')" title="${a.label}" style="font-size:2.2rem">${a.src}</span>`
    ).join('');
  }
}

function selectAvatar(el, emoji) {
  document.querySelectorAll('.avatar-opt').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
  document.getElementById('selectedAvatar').value = emoji;
}

function demoOnboarding() {
  createUser('Misafir', '🤖');
  document.getElementById('onboardOverlay').style.display = 'none';
  initAfterUser();
  addBotMsg('Merhaba <b>Misafir</b>! 🎉 Seni tanıdığıma çok memnunum!<br>Ben <b>Ata Ortaokulu Sohbet Programı</b>. İstediğin zaman adını ayarlardan değiştirebilirsin!', true);
}
function completeOnboarding() {
  const name = document.getElementById('onboardName').value.trim();
  const avatar = document.getElementById('selectedAvatar').value || '🧑‍🎓';
  if (!name || name.length < 2) { alert('Lütfen adını yaz (en az 2 harf)!'); return; }
  createUser(Security.sanitize(name), avatar);
  document.getElementById('onboardOverlay').style.display = 'none';
  initAfterUser();
  addBotMsg('Merhaba <b>' + userProfile.name + '</b>! 🎉 Seni tanıdığıma çok memnunum!<br>Ben <b>Ata Ortaokulu Sohbet Programı</b>. Bana her şeyi sorabilirsin!<br><br><b>Ctrl+K</b> ile komut paletini aç, <b>/oyun</b> ile oyna, <b>/quiz</b> ile teste gir!', true);
}

function renderUserCard() {
  const el = document.getElementById('userCard');
  if (!el || !userProfile) return;
  const lvl = LEVELS[userProfile.level] || LEVELS[0];
  const avatarHtml = userProfile.avatar.startsWith('http') || (userProfile.avatar.length > 2 && userProfile.avatar.includes('/')) 
    ? '<img src="' + userProfile.avatar + '" alt="Avatar" style="width:100%;height:100%;object-fit:cover;border-radius:50%">'
    : userProfile.avatar;
  el.innerHTML = `
    <div class="user-avatar">${avatarHtml}</div>
    <div class="user-info">
      <h3>${userProfile.name}</h3>
      <div class="user-meta">${lvl.icon} Lv.${userProfile.level + 1} ${lvl.name}</div>
    </div>
    ${userProfile.streak > 1 ? '<span class="streak-badge">🔥' + userProfile.streak + '</span>' : ''}
  `;
}

// ===== 3. MEMORY SYSTEM (3-Layer) =====
const Memory = {
  shortTerm: [],    // son 15 mesaj
  sessionTopics: [],
  longTerm: Storage.get('bot_longmem', []),

  addMessage(role, text) {
    this.shortTerm.push({ role, text, ts: Date.now() });
    if (this.shortTerm.length > 15) this.shortTerm.shift();
    if (this.shortTerm.length % 5 === 0) this.analyzeTopics();
  },

  analyzeTopics() {
    const recent = this.shortTerm.slice(-5).map(m => m.text.toLowerCase()).join(' ');
    const topicMap = {
      oyun: ['oyun','oyna','wordle','quiz','macera','xox'],
      bilim: ['bilim','deney','atom','kimya','fizik','biyoloji'],
      matematik: ['matematik','hesap','sayı','toplam','çarp','formül'],
      tarih: ['tarih','osmanlı','cumhuriyet','savaş','fetih'],
      teknoloji: ['bilgisay','robot','yapay zeka','kod','program'],
      sanat: ['resim','müzik','çiz','şiir','hikaye','yaz'],
      spor: ['futbol','basket','spor','maç','gol','koş'],
      doğa: ['hayvan','bitki','orman','deniz','uzay','gezegen']
    };
    for (const [topic, keywords] of Object.entries(topicMap)) {
      if (keywords.some(k => recent.includes(k)) && !this.sessionTopics.includes(topic)) {
        this.sessionTopics.push(topic);
        if (this.sessionTopics.length > 5) this.sessionTopics.shift();
      }
    }
  },

  remember(fact) {
    if (!this.longTerm.includes(fact)) {
      this.longTerm.push(fact);
      if (this.longTerm.length > 50) this.longTerm.shift();
      Storage.set('bot_longmem', this.longTerm);
    }
  },

  getContext() {
    return {
      recent: this.shortTerm.slice(-5).map(m => m.role + ': ' + m.text).join('\n'),
      topics: this.sessionTopics.join(', '),
      facts: this.longTerm.slice(-5).join('; ')
    };
  }
};

// ===== 4. INTENT (NLP) SYSTEM =====
const INTENTS = {
  greeting:   { patterns: ['merhaba','selam','günaydın','naber','hey','meraba','selamun','iyi günler','iyi akşam'], priority: 1 },
  farewell:   { patterns: ['hoşça kal','bye','görüşür','güle güle','iyi geceler'], priority: 1 },
  weather:    { patterns: ['hava durumu','hava nasıl','sıcaklık','yağmur','dışarısı','derece'], priority: 2 },
  image:      { patterns: ['resim','görsel','fotoğraf','çiz','oluştur'], priority: 2 },
  game:       { patterns: ['oyun','oyna','eğlen','sıkıl','canım sıkıl','oyun oyna'], priority: 2 },
  learn:      { patterns: ['öğret','öğren','ders','konu','anlat','açıkla','nedir','ne demek'], priority: 2 },
  quiz:       { patterns: ['quiz','test','sınav','soru'], priority: 2 },
  fun:        { patterns: ['şaka','fıkra','espri','komik','güldür','eğlence','soğuk şaka','caps'], priority: 3 },
  mood:       { patterns: ['üzgün','mutlu','kızgın','sinir','mutsuz','keyif','moral','stres'], priority: 3 },
  compliment: { patterns: ['teşekkür','sağol','süper','harika','bravo','iyi','güzel'], priority: 3 },
  identity:   { patterns: ['kimsin','adın ne','nesin','sen ne','ne yapabilir'], priority: 3 },
  help:       { patterns: ['yardım','komut','nasıl','help','ne yapa'], priority: 3 },
};

function detectIntent(input) {
  const lw = input.toLowerCase();
  let best = null, bestScore = 0;
  for (const [name, data] of Object.entries(INTENTS)) {
    const score = data.patterns.filter(p => lw.includes(p)).length * data.priority;
    if (score > bestScore) { bestScore = score; best = name; }
  }
  return best;
}

// ===== 5. PLUGIN ENGINE =====
const PLUGINS = {};
const CMD_LIST = [];

function registerPlugin(p) {
  PLUGINS[p.command] = p;
  CMD_LIST.push({ icon: p.icon, name: p.command, desc: p.description, cmd: p.command + (p.needsArg ? ' ' : '') });
}

// Yeni Pluginleri buraya kaydediyoruz
registerPlugin(AgendaPlugin);
registerPlugin(LeaderboardPlugin);

// Eski komutları siliyoruz
function routeCommand(input) {
  const lw = input.toLowerCase();
  for (const [cmd, plugin] of Object.entries(PLUGINS)) {
    if (lw === cmd || lw.startsWith(cmd + ' ')) {
      const args = input.substring(cmd.length).trim();
      plugin.run({ input, args, user: userProfile, memory: Memory });
      return true;
    }
  }
  return false;
}

// ===== 6. MODE SYSTEM =====
const MODES = {
  normal:  { name: 'Normal', icon: '🤖', color: '#3b82f6', greeting: 'Normal moddayım.', rules: ['Dengeli ve yardımcı ol'] },
  teacher: { name: 'Öğretmen', icon: '🎓', color: '#10b981', greeting: 'Öğretmen modundayım! Soruları adım adım açıklayacağım.', rules: ['Konuyu adım adım anlat','Örnekler ver','Mini soru sor','Teşvik et'] },
  fun:     { name: 'Eğlence', icon: '😂', color: '#f97316', greeting: 'Eğlence modundayım! Şakalar ve sürprizler beni bekliyor!', rules: ['Espirili ol','Emojileri bol kullan','Sürprizler yap','Oyunlar öner'] },
  expert:  { name: 'Uzman', icon: '🧠', color: '#8b5cf6', greeting: 'Uzman modundayım. Derinlemesine bilgi sunacağım.', rules: ['Detaylı ve teknik açıkla','Kaynak belirt','Karşılaştırma yap'] },
  game:    { name: 'Oyun', icon: '🎮', color: '#ef4444', greeting: 'Oyun modundayım! Ne oynayalım?', rules: ['Oyun öner','Skorları takip et','Rekabet kur'] }
};


function setMode(mode) {
  if (!MODES[mode]) return;
  AppState.currentMode = mode;
  const m = MODES[mode];
  document.getElementById('botName').textContent = m.icon + ' Ata Sohbet — ' + m.name;
  renderModeButtons();
  if (mode === 'game') {
    openGameMenu();
    addBotMsg('🎮 <b>Oyun Merkezi açıldı!</b> Açılır pencereden istediğin oyunu seç!', true);
  } else {
    addBotMsg(m.icon + ' ' + m.greeting);
  }
  gainXP(2, 'Mod değiştirildi: ' + m.name);
}

function renderModeButtons() {
  const el = document.getElementById('modeSelector');
  if (!el) return;
  el.innerHTML = Object.entries(MODES).map(([key, m]) =>
    `<button class="mode-btn ${key === AppState.currentMode ? 'active' : ''}" style="background:${m.color}" onclick="setMode('${key}')">${m.icon} ${m.name}</button>`
  ).join('');
}

// ===== 7. XP & LEVEL SYSTEM =====
const LEVELS = [
  { name: 'Çırak', minXP: 0, icon: '⭐' },
  { name: 'Kalfa', minXP: 100, icon: '🌟' },
  { name: 'Usta', minXP: 300, icon: '💫' },
  { name: 'Efsane', minXP: 600, icon: '🔥' },
  { name: 'Tanrısal', minXP: 1000, icon: '👑' },
  { name: 'Galaktik', minXP: 1500, icon: '🌌' }
];

function gainXP(amount, reason) {
  if (!userProfile) return;
  const oldLv = userProfile.level;
  userProfile.xp += amount;
  let newLv = 0;
  for (let i = LEVELS.length - 1; i >= 0; i--) { if (userProfile.xp >= LEVELS[i].minXP) { newLv = i; break; } }
  userProfile.level = newLv;
  saveUser();
  if (newLv > oldLv) {
    showToast(LEVELS[newLv].icon, 'Seviye Atladın!', LEVELS[newLv].name + ' oldun! (+' + amount + ' XP)', 'badge-toast');
    triggerConfetti();
  } else if (reason) {
    showToast('✨', 'XP Kazandın!', '+' + amount + ' XP: ' + reason, 'success');
  }
  updateXPBar();
  checkBadges();
  renderUserCard();
}

function updateXPBar() {
  if (!userProfile) return;
  const lv = LEVELS[userProfile.level], nxt = LEVELS[userProfile.level + 1];
  const cur = userProfile.xp - lv.minXP, max = nxt ? (nxt.minXP - lv.minXP) : 1;
  const pct = nxt ? Math.min(100, cur / max * 100) : 100;
  const el = (id) => document.getElementById(id);
  if (el('xpLevelLabel')) el('xpLevelLabel').textContent = lv.icon + ' Lv.' + (userProfile.level + 1) + ' ' + lv.name;
  if (el('xpValueLabel')) el('xpValueLabel').textContent = userProfile.xp + '/' + (nxt ? nxt.minXP : 'MAX') + ' XP';
  if (el('xpBarFill')) el('xpBarFill').style.width = pct + '%';
  if (el('xpRank')) el('xpRank').textContent = nxt ? 'Sonraki: ' + nxt.name + ' (' + nxt.minXP + ' XP)' : '🏆 Maksimum seviye!';
}

// ===== 8. BADGE SYSTEM =====
let stats = Storage.get('bot_stats', {msg:0,games:0,react:0});
let learnedRaw = Storage.get('bot_hafiza', []);
let RULES = [
  { kw: ['hacker modu','matrix','hacker ol'], r: 'Sistem KONTROL ALTINA ALINDI. Terminal\'e geçiliyor... Hoş geldin, Neo.', a: 'HACKER_MODE', p: 100 },
  { kw: ['normal mod','eski haline','hacker modunu kapat'], r: 'Sistem güvenliği sağlandı.', a: 'NORMAL_MODE', p: 100 },
  { kw: ['ekranı salla','deprem','titre'], r: 'Sıkı tutun!! 8.0 şiddetinde titreşim! 🌍', a: 'SHAKE', p: 10 },
  { kw: ['şifre üret','şifre ver','güvenli şifre'], r: 'Kırılmaz şifre üretiliyor...', a: 'PASSWORD', p: 10 },
  { kw: ['alarm','saniye say','dakika','timer'], r: '__ALARM__', a: 'TIMER', p: 10 },
];
RULES = RULES.concat(learnedRaw.map(r => ({ kw: r.keywords, r: r.response, p: r.priority || 1, regex: r.isRegex || false })));

const BADGE_DEFS = [
  { id: 'first_msg', icon: '🗣️', name: 'İlk Söz', desc: 'İlk mesajını gönder', check: () => stats.msg >= 1 },
  { id: 'msg_50', icon: '💬', name: 'Sohbet Ustası', desc: '50 mesaj gönder', check: () => stats.msg >= 50 },
  { id: 'msg_200', icon: '🗨️', name: 'Konuşma Kralı', desc: '200 mesaj gönder', check: () => stats.msg >= 200 },
  { id: 'learn_5', icon: '🧠', name: 'Bilgi Kurdu', desc: '5 şey öğret', check: () => learnedRaw.length >= 5 },
  { id: 'learn_20', icon: '📚', name: 'Profesör', desc: '20 şey öğret', check: () => learnedRaw.length >= 20 },
  { id: 'game_5', icon: '🎮', name: 'Oyuncu', desc: '5 oyun oyna', check: () => stats.games >= 5 },
  { id: 'game_20', icon: '🕹️', name: 'Oyun Canavarı', desc: '20 oyun oyna', check: () => stats.games >= 20 },
  { id: 'react_10', icon: '❤️', name: 'Duygusal', desc: '10 tepki ver', check: () => stats.react >= 10 },
  { id: 'xp_300', icon: '💎', name: 'Deneyimli', desc: '300 XP kazan', check: () => (userProfile ? userProfile.xp >= 300 : false) },
  { id: 'xp_1000', icon: '👑', name: 'Efsanevi', desc: '1000 XP kazan', check: () => (userProfile ? userProfile.xp >= 1000 : false) },
  { id: 'streak_7', icon: '🔥', name: 'Alev Topu', desc: '7 gün streak', check: () => (userProfile ? userProfile.streak >= 7 : false) },
  { id: 'mode_all', icon: '🎭', name: 'Çok Yönlü', desc: 'Tüm modları dene', check: () => false },
  { id: 'image_5', icon: '🖼️', name: 'Sanatçı', desc: '5 görsel oluştur', check: () => (stats.images || 0) >= 5 },
];
let earnedBadges = Storage.get('bot_badges', []);

function checkBadges() {
  BADGE_DEFS.forEach(b => {
    if (!earnedBadges.includes(b.id) && b.check()) {
      earnedBadges.push(b.id);
      Storage.set('bot_badges', earnedBadges);
      showToast(b.icon, 'Rozet Kazandın!', b.name + ': ' + b.desc, 'badge-toast');
      gainXP(25, 'Rozet: ' + b.name);
    }
  });
  renderBadges();
}

function renderBadges() {
  const g = document.getElementById('badgeGrid'); if (!g) return; g.innerHTML = '';
  BADGE_DEFS.forEach(b => {
    const d = document.createElement('div');
    d.className = 'badge-item ' + (earnedBadges.includes(b.id) ? 'earned' : 'locked');
    d.innerHTML = b.icon + '<span class="badge-tip">' + (earnedBadges.includes(b.id) ? '✅ ' : '') + b.name + '<br>' + b.desc + '</span>';
    g.appendChild(d);
  });
}

// ===== 9. DAILY QUESTS =====
const DAILY_QUESTS = [
  { id: 'send_5', text: '5 mesaj gönder', target: 5, xp: 15, icon: '💬', stat: 'msg' },
  { id: 'play_1', text: '1 oyun oyna', target: 1, xp: 20, icon: '🎮', stat: 'games' },
  { id: 'pdf_1', text: '1 PDF Oku/Analiz Et', target: 1, xp: 30, icon: '📄', stat: 'pdf' },
  { id: 'learn_1', text: 'Yeni 1 kelime/konu öğren', target: 1, xp: 25, icon: '🧠', stat: 'learned' },
];

function renderQuests() {
  const el = document.getElementById('questCard'); if (!el || !userProfile) return;
  const today = userProfile.questsToday || {};
  let html = '<div class="quest-title">📋 Günlük Görevler</div>';
  DAILY_QUESTS.forEach(q => {
    const progress = today[q.id] || 0;
    const done = progress >= q.target;
    html += `<div class="quest-item ${done ? 'done' : ''}">
      <span class="quest-icon">${q.icon}</span>
      <span>${q.text}</span>
      <span style="margin-left:auto;font-size:.68rem">${done ? '✅' : progress + '/' + q.target}</span>
    </div>`;
  });
  el.innerHTML = html;
}

function updateQuest(statName) {
  if (!userProfile || !userProfile.questsToday) return;
  const today = userProfile.questsToday;
  DAILY_QUESTS.forEach(q => {
    if (q.stat === statName) {
      const before = today[q.id] || 0;
      today[q.id] = before + 1;
      if (before < q.target && today[q.id] >= q.target) {
        gainXP(q.xp, 'Görev: ' + q.text);
        showToast('✅', 'Görev Tamamlandı!', q.text + ' (+' + q.xp + ' XP)', 'badge-toast');
      }
    }
  });
  saveUser();
  renderQuests();
}

// ===== 10. AI PROMPT BUILDER =====
function buildPrompt(input, intent) {
  const m = MODES[AppState.currentMode];
  const ctx = Memory.getContext();
  const name = userProfile ? userProfile.name : 'Kullanıcı';
  const interests = userProfile ? (userProfile.interests.join(', ') || 'belirlenmedi') : '';
  const now = new Date();
  const tarihBilgisi = now.toLocaleDateString('tr-TR', {weekday:'long',year:'numeric',month:'long',day:'numeric'}) + ' ' + now.toLocaleTimeString('tr-TR', {hour:'2-digit',minute:'2-digit'});
  return `Sen "Ata Ortaokulu Sohbet Programı" adlı sanal bir cevap botusun.
Kullanıcının adı: ${name}
Şu anki tarih ve saat: ${tarihBilgisi}
Mod: ${m.name} — ${m.rules.join(', ')}
İlgi: ${interests}
Hafıza: ${ctx.facts}
Konuşma: ${ctx.recent}
Niyet: ${intent || 'belirsiz'}
Türkçe yanıt ver, net ve anlaşılır yaz. Tarih/saat sorularında yukarıdaki bilgiyi kullan.`;
}

// ===== 11. SUGGESTIONS =====
function getSuggestions(intent) {
  const map = {
    greeting: ['📊 Quiz başlat', '🎮 Oyun oyna', '📚 Ders anlat'],
    weather: ['☀️ Başka şehir', '📊 Quiz yap', '🎮 Oyun'],
    game: ['🟩 Wordle', '⚔️ Macera', '📊 Quiz'],
    learn: ['🧠 Detay anlat', '📊 Test et', '🎮 Oyunla öğren'],
    quiz: ['🔬 Bilim', '📜 Tarih', '🌍 Coğrafya'],
    compliment: ['🎮 Oyun oyna', '📚 Ders', '🎲 Rastgele bilgi'],
    mood: ['🚀 Motivasyon', '🎮 Oyun oyna', '😂 Eğlence modu'],
    farewell: ['👋 Görüşürüz!'],
    help: ['📋 Komutlar', '🎮 Oyunlar', '📚 Ders'],
  };
  return map[intent] || ['💡 Yardım', '🎮 Oyun', '📚 Ders'];
}

function renderSuggestions(intent) {
  const items = getSuggestions(intent);
  const row = document.createElement('div');
  row.className = 'suggestion-row';
  items.forEach(s => {
    const btn = document.createElement('button');
    btn.className = 'suggestion-chip';
    btn.textContent = s;
    btn.onclick = () => { userInput.value = s.replace(/^[^\s]+\s/, ''); sendMessage(); };
    row.appendChild(btn);
  });
  return row;
}
// ============================================
// MEGA Asistan Bot v10.0 PRO — Part 2
// UI + Messages + Router + Games + Utils
// ============================================

// DOM refs (set after DOM ready)
let chatbox, userInput, typing, botStatusEl;

// ===== TOAST =====
function showToast(icon, title, desc, type) {
  const c = document.getElementById('toastContainer');
  if (!c) return;
  const t = document.createElement('div');
  t.className = 'toast ' + (type || '');
  t.innerHTML = '<span class="toast-icon">' + icon + '</span><div class="toast-body"><div class="toast-title">' + title + '</div><div class="toast-desc">' + desc + '</div></div>';
  c.appendChild(t);
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, 3500);
}

// ===== CONFETTI =====
function triggerConfetti() {
  AudioEngine.levelUp();
  if (document.hidden) return;
  const cv = document.getElementById('confettiCanvas'); if (!cv) return;
  cv.style.display = 'block'; cv.width = window.innerWidth; cv.height = window.innerHeight;
  const ctx = cv.getContext('2d');
  const colors = ['#3b82f6','#ec4899','#4ade80','#fde047','#f97316','#a855f7','#06b6d4'];
  let parts = [];
  for (let i = 0; i < 130; i++) parts.push({ x: Math.random() * cv.width, y: -10, w: Math.random() * 11 + 4, h: Math.random() * 6 + 3, c: colors[Math.floor(Math.random() * colors.length)], vx: (Math.random() - .5) * 5, vy: Math.random() * 4 + 1.5, a: Math.random() * 360, va: Math.random() * 6 - 3, life: 1 });
  let fr = 0;
  (function draw() {
    ctx.clearRect(0, 0, cv.width, cv.height);
    parts.forEach(p => { p.x += p.vx; p.y += p.vy; p.a += p.va; p.vy += 0.05; ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a * Math.PI / 180); ctx.globalAlpha = p.life; ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore(); p.life -= 0.013; });
    parts = parts.filter(p => p.life > 0); fr++;
    if (fr < 150 && parts.length > 0) requestAnimationFrame(draw);
    else { ctx.clearRect(0, 0, cv.width, cv.height); cv.style.display = 'none'; }
  })();
}

// ===== MESSAGES =====
function addUserMsg(txt) {
  const d = document.createElement('div');
  d.className = 'message msg-user';
  d.textContent = txt;
  chatbox.insertBefore(d, typing);
  chatbox.scrollTop = chatbox.scrollHeight;
}

function addBotMsg(html, withSuggestions) {
  const wrap = document.createElement('div'); wrap.className = 'bot-wrap';
  const msg = document.createElement('div'); msg.className = 'message msg-bot'; msg.innerHTML = html;
  const row = document.createElement('div'); row.className = 'reacts';
  ['👍','❤️','😂','🤯','🔥'].forEach(e => {
    const b = document.createElement('button'); b.className = 'rbt'; b.textContent = e;
    b.onclick = function() {
      this.classList.toggle('on');
      if (this.classList.contains('on')) stats.react++; else if (stats.react > 0) stats.react--;
      updateStats(); saveStats();
    };
    row.appendChild(b);
  });
  const tb = document.createElement('button'); tb.className = 'tts-b'; tb.textContent = '🔊 Dinle';
  tb.onclick = () => speakText(msg.innerText); row.appendChild(tb);
  wrap.appendChild(msg); wrap.appendChild(row);

  // Suggestion chips
  if (withSuggestions) {
    const intent = detectIntent(html);
    const sugRow = renderSuggestions(intent);
    wrap.appendChild(sugRow);
  }

  chatbox.insertBefore(wrap, typing);
  chatbox.scrollTop = chatbox.scrollHeight;
  const av = document.getElementById('avatarIcon');
  if (av) { av.classList.add('speaking'); setTimeout(() => av.classList.remove('speaking'), 1400); }
}

function qCmd(cmd) { 
  if (window.innerWidth <= 768) { const sb = document.querySelector('.sidebar'); if(sb && sb.classList.contains('open')) toggleSidebar(); }
  userInput.value = cmd; sendMessage(); 
}

// ===== STREAMING BOT MESSAGE =====

async function streamBotMsg(html, withSuggestions = false, speed = 12) {
  AppState.streamStop = false;
  AppState.isStreaming = true;

  // Wrapper oluştur (addBotMsg ile aynı yapı)
  const wrap = document.createElement('div');
  wrap.className = 'bot-wrap';
  const msg = document.createElement('div');
  msg.className = 'message msg-bot';
  msg.style.minHeight = '24px';
  chatbox.insertBefore(wrap, typing);
  wrap.appendChild(msg);
  chatbox.scrollTop = chatbox.scrollHeight;

  // Avatar animasyonu
  const av = document.getElementById('avatarIcon');
  if (av) av.classList.add('speaking');

  // HTML'yi karakter/tag parçalarına böl
  const chunks = [];
  const splitter = /(<[^>]+>|&[a-z#\d]+;)/g;
  let last = 0, m;
  while ((m = splitter.exec(html)) !== null) {
    // Tag öncesindeki metin → tek tek karakter
    for (const c of html.slice(last, m.index)) chunks.push({ t: 'c', v: c });
    // Tag / entity → bir seferde
    chunks.push({ t: 'x', v: m[0] });
    last = m.index + m[0].length;
  }
  for (const c of html.slice(last)) chunks.push({ t: 'c', v: c });

  // Stream
  let built = '';
  for (const chunk of chunks) {
    if (AppState.streamStop) break;
    built += chunk.v;
    msg.innerHTML = built + '<span class="stream-cursor">\u2588</span>';
    chatbox.scrollTop = chatbox.scrollHeight;
    if (chunk.t === 'c' && chunk.v.trim()) { // sadece görünür karakter
      await new Promise(r => setTimeout(r, speed));
    }
  }

  // Cursor kaldır, final HTML
  msg.innerHTML = built;
  if (av) { av.classList.add('speaking'); setTimeout(() => av.classList.remove('speaking'), 1000); }

  // Tıklayarak stream'i atla (zaten bitince de çalışır)
  msg.style.cursor = 'default';

  // Tepki butonları
  const row = document.createElement('div'); row.className = 'reacts';
  ['\ud83d\udc4d','\u2764\ufe0f','\ud83d\ude02','\ud83e\udd2f','\ud83d\udd25'].forEach(e => {
    const b = document.createElement('button'); b.className = 'rbt'; b.textContent = e;
    b.onclick = function() {
      this.classList.toggle('on');
      if (this.classList.contains('on')) stats.react++; else if (stats.react > 0) stats.react--;
      updateStats(); saveStats();
    };
    row.appendChild(b);
  });
  const tb = document.createElement('button'); tb.className = 'tts-b'; tb.textContent = '\ud83d\udd0a Dinle';
  tb.onclick = () => speakText(msg.innerText); row.appendChild(tb);
  wrap.appendChild(row);

  if (withSuggestions) {
    const intent = detectIntent(html);
    const sugRow = renderSuggestions(intent);
    wrap.appendChild(sugRow);
  }
  chatbox.scrollTop = chatbox.scrollHeight;
  AppState.isStreaming = false;
}

// Mesaj kutusuna tıklayarak stream'i atla
document.addEventListener('click', e => {
  if (e.target.classList.contains('msg-bot') && document.querySelector('.stream-cursor')) {
    AppState.streamStop = true;
  }
});

// ===== TTS =====
function speakText(txt) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(txt.substring(0, 400));
  u.lang = 'tr-TR'; u.rate = 0.95; u.pitch = 1.1;
  window.speechSynthesis.speak(u);
}

// ===== VOICE INPUT =====
let recognition = null;
function toggleVoice() {
  const btn = document.getElementById('btnToggleVoice');
  if (AppState.isMicOn) { if (recognition) recognition.stop(); AppState.isMicOn = false; btn.classList.remove('listening'); btn.textContent = '🎤'; return; }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { addBotMsg('❌ Tarayıcın sesli girişi desteklemiyor!'); return; }
  recognition = new SR(); recognition.lang = 'tr-TR'; recognition.continuous = false;
  recognition.onstart = () => { AppState.isMicOn = true; btn.classList.add('listening'); btn.textContent = '🔴 Dinliyorum...'; };
  recognition.onresult = e => { userInput.value = e.results[0][0].transcript; sendMessage(); };
  recognition.onend = () => { AppState.isMicOn = false; btn.classList.remove('listening'); btn.textContent = '🎤'; };
  recognition.onerror = () => { AppState.isMicOn = false; btn.classList.remove('listening'); btn.textContent = '🎤'; };
  recognition.start();
}

// ===== STATS =====
function updateStats() {
  const el = id => document.getElementById(id);
  if (el('stMsg')) el('stMsg').textContent = stats.msg;
  if (el('stRules')) el('stRules').textContent = learnedRaw.length;
  if (el('stGames')) el('stGames').textContent = stats.games;
  if (el('stReact')) el('stReact').textContent = stats.react;
}
function saveStats() { Storage.set('bot_stats', stats); }

// ===== SEND MESSAGE =====


function sendMessage() {
  if (typeof AppState.isStreaming !== 'undefined' && AppState.isStreaming) {
      addBotMsg('<span style="color:#ef4444;font-size:0.85em">⚠️ Lütfen botun yanıtını tamamlamasını bekleyin veya atlamak için cevaba tıklayın!</span>');
      return;
  }
  const txt = userInput.value.trim(); if (!txt) return;

  // Security checks
  const v = Security.validate(txt);
  if (!v.valid) { if (v.msg) addBotMsg('⚠️ ' + v.msg); return; }
  if (!Security.rateLimit()) { addBotMsg('<span class="rate-warning">⚠️ Çok hızlı yazıyorsun! Biraz bekle.</span>'); return; }

  addUserMsg(txt); userInput.value = '';
  stats.msg++; updateStats(); saveStats();
  gainXP(2);
  Memory.addMessage('user', txt);
  updateQuest('msg');
  checkBadges();

  typing.style.display = 'flex';
  chatbox.scrollTop = chatbox.scrollHeight;

  if (AppState.botState === 'WAITING_FOR_WORD') { AppState.botState = 'SEARCHING'; setTimeout(() => fetchWiki(txt), 400); }
  else setTimeout(() => { typing.style.display = 'none'; getBotResp(txt); }, 700 + Math.random() * 400);
}

// ===== MAIN ROUTER =====
const CHARS = {
  korsan: { n: '⚓ Kaptan Bot', a: '🏴‍☠️', p: 'Ahoy! ' },
  robot: { n: 'UNIT-9', a: '🤖', p: '[SİSTEM]: ' },
  bilim: { n: 'Dr. Bot Ph.D', a: '🔬', p: 'Analizlerime göre: ' },
  masal: { n: 'Masalcı Bot', a: '📖', p: 'Bir varmış bir yokmuş, ' },
  kedi: { n: 'Miyav Bot', a: '🐱', p: 'Miyav~ ' },
  astronot: { n: 'Uzay Kaptan', a: '🚀', p: 'Houston, ' },
};
const charKeys = Object.keys(CHARS);
const alarmReg = /(\d+)\s*(saniye|dakika|sn|dk)/i;
const PWCH = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*';
const TRIVIA = [
  '🌍 Pasifik Okyanusu yeryüzünün %30\'unu kaplar!',
  '🧠 İnsan beyni yaklaşık 86 milyar nörondan oluşur.',
  '🚀 Işık saniyede yaklaşık 300.000 km gider.',
  '🐙 Ahtapolların 3 kalbi ve mavi kanı vardır.',
  '🌙 Ay\'ın kendi ışığı yoktur, Güneş\'i yansıtır.',
  '🦋 Kelebeklerin tat duyusu ayaklarındadır.',
  '🐬 Yunuslar uyurken beyninin sadece yarısını uyutur.',
];


function handleGameTriggers(lw) {
  // 🔥 Eğer "kodla/programla/oluştur/geliştir" varsa canlı kod playground'a bırak
  if (/kodla|programla|oluştur|geliştir|kodlasana|kodlayalım/.test(lw)) return false;

  const oyunKelimeler = ['oyun oynayalım','oyun oynayım','oynamak istiyorum','oynayalım mı','oyun açalım',
    'bana oyun','oyun var mı','eğlenelim','eğlenceli bir şey','canım sıkıldı','sıkıldım'];
  const oyunIcerir = lw.includes('oyun') || /^(game|games|oyna)$/i.test(lw.trim());
  if (oyunIcerir || oyunKelimeler.some(k => lw.includes(k))) {
    openGameMenu();
    addBotMsg('🎮 <b>Oyun Merkezi açıldı!</b> Açılır pencereden istediğin oyunu seç!', true);
    AudioEngine.click(); return true;
  }
  const dogruOyunMap = {'yılan':'snake','snake':'snake','xox':'xox','tic tac':'xox','breakout':'breakout',
    'tuğla kır':'breakout','pong':'pong','masa tenisi':'pong','mayın':'minesweeper','minesweeper':'minesweeper',
    'tepki':'reaction','reaction':'reaction','hafıza':'memory','hafıza kartı':'memory',
    'matematik':'math','sudoku':'sudoku','uç vurma':'shooting','uçak vurma':'shooting','shooting':'shooting','uçak':'shooting',
    'araba yarışı':'racing','araba':'racing','yarış':'racing','racing':'racing','sürüş':'racing'};
  for (const [ad, id] of Object.entries(dogruOyunMap)) {
    if (lw === ad || lw === ad + ' oyna' || lw === ad + ' aç') {
      openGameMenu();
      setTimeout(() => openGameInModal(id), 300);
      addBotMsg('🎮 <b>' + ad.charAt(0).toUpperCase() + ad.slice(1) + '</b> oyunu açılıyor! İyi eğlenceler! 🕹️', true);
      AudioEngine.click(); return true;
    }
  }
  return false;
}

function getBotResp(input) {
  const lw = input.toLowerCase();

  // 1. Plugin commands first
  if (routeCommand(input)) return;

  // 2. Öğret komutu
  if (lw.startsWith('/öğret ')) {
    const parts = input.substring(7).split('=');
    if (parts.length < 2) { addBotMsg('Kullanım: <b>/öğret anahtar=cevap</b>'); return; }
    const kw = parts[0].trim(), res = parts.slice(1).join('=').trim();
    if (!kw || !res) { addBotMsg('❌ Anahtar ve cevap gerekli!'); return; }
    const kws = kw.split(',').map(k => k.trim().toLowerCase()).filter(Boolean);
    const rule = { keywords: kws, response: res };
    learnedRaw.push(rule); RULES.push({ kw: kws, r: res });
    localStorage.setItem('bot_hafiza', JSON.stringify(learnedRaw));
    updateStats(); saveStats(); triggerConfetti(); gainXP(5, 'Yeni şey öğrettin');
    Memory.remember(userProfile.name + ' şunu öğretti: ' + kw);
    addBotMsg('✅ Öğrendim! "<b>' + kw + '</b>" → "<b>' + res + '</b>" 🧠'); return;
  }

  // 3. Doğal dil görsel üretme
  const imgKeywords = ['görsel oluştur','resim oluştur','resim yap','görsel yap','resim üret','görsel üret','görsel çiz','resim çiz','fotoğraf oluştur','fotoğraf yap'];
  for (let kw of imgKeywords) {
    if (lw.includes(kw)) {
      let prompt = input.replace(new RegExp(kw, 'gi'), '').replace(/^(bana|bir|lütfen|\s)+/i, '').replace(/(lütfen|bana|\s)+$/i, '').trim();
      if (prompt.length < 2) prompt = input;
      generateImage(prompt); return;
    }
  }
  const imgRegex = /(.*?)\s*(resmini|resmi|görseli|görselini|fotoğrafı|fotoğrafını)\s*(göster|çiz|yap|oluştur|üret|ver|bul)/i;
  const imgMatch = input.match(imgRegex);
  if (imgMatch) { let p = imgMatch[1].replace(/^(bana|bir|lütfen)\s*/i, '').trim(); if (p.length < 2) p = input; generateImage(p); return; }

  // 5. Mod komutları
  if (lw === '/komutlar') { openCmdPalette(); addBotMsg('⌨️ Komut paletini açtım!'); return; }
  const modeMap = { '/normal': 'normal', '/öğretmen': 'teacher', '/eğlence': 'fun', '/uzman': 'expert', '/oyunmod': 'game' };
  if (modeMap[lw]) { setMode(modeMap[lw]); return; }

  // 5. Hava durumu
  if (lw.startsWith('/hava')) { fetchWeather(input.substring(5).trim() || 'Istanbul'); return; }
  if (lw.includes('hava nasıl') || lw.includes('bugün hava') || lw.includes('hava durumu')) { getLocWeather(); return; }

  // 6. Pro mode handling
  if (AppState.proMode !== 'NORMAL') { addBotMsg(handleProMode(AppState.proMode, input)); return; }

  // 7. Calculator
  const calc = tryCalc(input); if (calc) { addBotMsg(calc); gainXP(3, 'Hesaplama'); return; }

  if (handleGameTriggers(lw)) return;

  // 7.4 DEVAM / BAĞLAMSAL DETAYLANDIRMA (araştırma tetikleyicilerinden ÖNCE)
  const devamKelimeler = [
    'detay anlat','daha fazla anlat','devam et','daha detay','daha fazla bilgi',
    'devam','açar mısın','nasıl yani','peki ya','bunu açıkla','bunu anlat',
    'daha fazla','konuyu genişlet','üzerine devam'
  ];
  if (devamKelimeler.some(k => lw.includes(k))) {
    // Hafızadan son kullanıcı mesajını al (şimdiki mesaj HARİÇ)
    const prevUserMsgs = Memory.shortTerm.filter(m => m.role === 'user');
    const lastMsg = prevUserMsgs.length >= 2
      ? prevUserMsgs[prevUserMsgs.length - 2].text
      : null;
    if (lastMsg && lastMsg.trim().length > 10) {
      const konu = lastMsg.trim().substring(0, 120);
      addBotMsg('🧠 <b>Devam ediyorum...</b> Önceki konu hakkında daha fazla bilgi getiriyorum.');
      fetchAI(konu + ' hakkında daha detaylı açıkla');
    } else {
      fetchAI(input);
    }
    return;
  }

  // 7.3 EĞİTİM TALİBİ — Genel konu/soru istekleri (araştırma tetikleyicilerinden ÖNCE)
  const egitimKelimeler = [
    'örnek soru','örnek sorular','soru çöz','sorular çöz','problem çöz',
    'alıştırma yap','alıştırma ver','egzersiz yap',
    'konusunda örnek','konusunda açıkla','konusunda anlat','konusunda öğret','konusunda ders',
    'düzeyinde örnek','düzeyinde ders','düzeyinde anlat',
    'seviyesinde örnek','seviyesinde ders',
    'konu anlat','konu açıkla', 'öğret bana'
  ];
  if (egitimKelimeler.some(k => lw.includes(k))) {
    // Konuyu ve seviyeyi çıkar
    let konu = input;
    for (const k of egitimKelimeler) konu = konu.replace(new RegExp(k, 'gi'), '');
    // trigger kelimeleri de temizle
    const dersKKopyasi = ['ders çalışalım','ders ver','ders anlat','ders yap','hakkında ders',
      'eğitim ver','öğretir misin','öğret bana','konu anlat','konudan ders'];
    for (const k of dersKKopyasi) konu = konu.replace(new RegExp(k, 'gi'), '');
    konu = konu
      .replace(/^(bana|bir|lütfen|hakkında|konusunda|da|de|'da|'de|\s)+/i, '')
      .replace(/(konusunda|hakkında|lütfen|bana|da|de|\?|!|\s)+$/i, '')
      .trim();

    if (konu.length <= 2) {
      const prevU = Memory.shortTerm.filter(m => m.role === 'user');
      const prev = prevU.length >= 2 ? prevU[prevU.length - 2].text : null;
      if (prev && prev.trim().length > 2) {
        konu = prev.trim();
      } else {
        konu = "matematik/genelkültür (kullanıcı sadece örnek soru istedi)";
      }
    }

    const seviye = input.match(/(\d+\s*\.?\s*s[ıi]n[ıi]f|temel|ba[sş]lang[ıi][çc]|ileri|orta)/i);
    const seviyeNot = seviye ? ` (${seviye[0]} düzeyinde)` : '';
    const istekler = [];
    if (/örnek soru|soru çöz|problem çöz/i.test(input)) istekler.push('örnek sorular çöz ve cevaplarını göster');
    if (/alıştırma|egzersiz/i.test(input)) istekler.push('alıştırmalar ver');
    if (istekler.length === 0) istekler.push('konuyu açıkla ve 2-3 örnek çöz');

    const hedef = konu.length > 2 ? konu : input.split(' ').slice(0, 3).join(' ');
    const lessonPrompt = `"${hedef}" konusunda${seviyeNot} eğitici bir ders ver: ${istekler.join(', ')}. Emoji kullan, kısa ve anlaşılır ol, adım adım açıkla.`;
    addBotMsg(`📚 <b>"${Security.sanitize(hedef)}"</b> konusunda ders hazırlanıyor${seviyeNot}...`);
    fetchAI(lessonPrompt); AudioEngine.click(); return;
  }

  const arastirmaKelimeler = [
    'araştır','araştırma yap','hakkında bilgi','hakkında araştır','araştırabilir misin',
    'bul bana','bilgi ver','nedir bu','ne hakkında','anlat bana','öğrenmek istiyorum'
  ];
  for (const k of arastirmaKelimeler) {
    if (lw.includes(k)) {
      // Araştırma konusunu cümleden çıkar
      let konu = input
        .replace(new RegExp(k, 'gi'), '')
        .replace(/^(bana|lütfen|bir|şunu|bunu|hakkında|da|de|'da|'de|\s)+/i, '')
        .replace(/(hakkında|lütfen|bana|misin|istiyorum|\?|!|\s)+$/i, '')
        .trim();
      // Konu çıkarılamazsa hafızadan bak
      if (konu.length <= 1) {
        const prevUser = Memory.shortTerm.filter(m => m.role === 'user');
        const prev = prevUser.length >= 2 ? prevUser[prevUser.length - 2].text : null;
        if (prev && prev.length > 5) {
          konu = prev.split(' ').slice(0, 4).join(' ');
        }
      }
      if (konu.length > 1) {
        addBotMsg('🔍 <b>"' + Security.sanitize(konu) + '"</b> araştırılıyor...');
        fetchWiki(konu);
      } else {
        AppState.botState = 'WAITING_FOR_WORD';
        addBotMsg('🔍 Hangi konuyu araştırmamı istersin? <b>Bir konu veya kelime yaz:</b>', true);
      }
      return;
    }
  }

  // Çizim tetikleyicileri
  const cizimKelimeler = ['çizim yap','çiz bir şey','çizmek istiyorum','resim yapalım','çizim açalım',
    'boyama','çizim tahtası','resim çizelim','serbest çiz','canvas aç'];
  if (cizimKelimeler.some(k => lw.includes(k))) {
    addBotMsg('🎨 Çizim tahtası açılıyor!');
    startDrawing(); AudioEngine.click(); return;
  }

  // Görsel Oluşturma (Yapay Zeka Resim) Tetikleyicileri
  const gorselKelimeler = ['görseli', 'görselleri', 'resmi', 'resimleri', 'fotoğrafı', 'görsel oluştur', 'resim oluştur', 'fotoğraf oluştur'];
  if (gorselKelimeler.some(k => lw.includes(k))) {
    // Eğer cümle içinde '/görsel' yoksa, buradan generateImage çağıralım
    if (!input.includes('/görsel')) {
      generateImage(input);
      return;
    }
  }

  // Not tetikleyicileri
  const notKelimeler = ['not al','not tut','bunu kaydet','hatırla bunu','not defteri','not ekle'];
  if (notKelimeler.some(k => lw.includes(k))) {
    const notIcerik = input.replace(/(not al|not tut|bunu kaydet|hatırla bunu|not defteri|not ekle)/gi, '').trim();
    if (notIcerik.length > 1) { handleNotes(notIcerik); }
    else { handleNotes(''); }
    return;
  }

  // Ders / eğitim tetikleyicileri — AKILLI KONU TESPİTİ
  const dersKelimeler = [
    'ders çalışalım','ders ver','ders anlat','ders yap','hakkında ders',
    'yapay zeka öğret','yz dersi','yapay zeka dersi','eğitim ver',
    'konuyu anlat','konudan ders','öğretir misin','öğret bana',
    'anlat ve soru çöz','örnek sorular çöz','konu anlat'
  ];
  if (dersKelimeler.some(k => lw.includes(k))) {
    // Konu çıkar: trigger kelimeleri sil, temizle
    let konu = input;
    for (const k of dersKelimeler) konu = konu.replace(new RegExp(k, 'gi'), '');
    konu = konu
      .replace(/^(bana|bir|lütfen|hakkında|da|de|'da|'de|\s)+/i, '')
      .replace(/(hakkında|lütfen|bana|da|de|\?|!|\s)+$/i, '')
      .trim();

    // YZ ünitesi mi? (nedir, ml, kural, gunluk, gelecek)
    const yzUnit = LESSON_DATA.find(u =>
      konu.toLowerCase().includes(u.id) ||
      input.toLowerCase().includes('yapay zeka') ||
      input.toLowerCase().includes('makine öğren') ||
      input.toLowerCase().includes('yz')
    );

    if (yzUnit) {
      showLesson(yzUnit.id); AudioEngine.click(); return;
    }

    if (konu.length > 2) {
      // Genel konu → AI ile yapılandırılmış ders
      // Orijinal cümlede seviye/bağlam ipuçlarını koru (2.sınıf, örnek vs.)
      const seviye = input.match(/(\d+\s*\.?\s*s[ıi]n[ıi]f|temel|ba[sş]lang[ıi][çc]|ileri|orta)/i);
      const seviyeNot = seviye ? ` (${seviye[0]} seviyesinde)` : '';
      const istekler = [];
      if (/örnek soru|soru çöz|soru sor/i.test(input)) istekler.push('örnek sorular çöz ve cevapları göster');
      if (/alıştırma|egzersiz/i.test(input)) istekler.push('alıştırmalar ver');
      if (istekler.length === 0) istekler.push('konuyu açıkla ve 2-3 örnek soru çöz');

      const lessonPrompt = `"${konu}" konusunda${seviyeNot} eğitici bir ders ver: ${istekler.join(', ')}. Emoji kullan, kısa ve anlaşılır ol, adım adım açıkla.`;

      addBotMsg(`📚 <b>"${Security.sanitize(konu)}"</b> konusunda ders hazırlanıyor${seviyeNot}...`);
      fetchAI(lessonPrompt); AudioEngine.click(); return;
    }

    // Konu bulunamadı → YZ menüsü
    showLesson(''); AudioEngine.click(); return;
  }

  // 7.6 Şaka / Eğlence tetikleyicileri (intent'ten ÖNCE yakala)
  const sakaKelimeler = ['şaka yap','soğuk şaka','fıkra anlat','espri yap','beni güldür',
    'komik bir şey','şaka söyle','fıkra söyle','espri anlat','güldür beni',
    'şaka anlat','komik şey söyle','caps yap','eğlenceli bir şey'];
  if (sakaKelimeler.some(k => lw.includes(k)) || /^(şaka|fıkra|espri)$/i.test(lw.trim())) {
    const localJoke = LOCAL_AI.tryLocal('şaka yap');
    if (localJoke) {
      streamBotMsg(localJoke, true);
      Memory.addMessage('bot', localJoke.replace(/<[^>]+>/g, '').substring(0, 200));
      gainXP(3, 'Eğlence');
    } else {
      fetchAI(input);
    }
    AudioEngine.click(); return;
  }


  // 8. Rules (built-in + learned)

  for (let rule of RULES) {
    if (rule.kw.some(k => lw.includes(k.toLowerCase()))) {
      if (rule.r === '__ALARM__') { triggerAction('TIMER', input); return; }
      addBotMsg(rule.r);
      if (rule.a) triggerAction(rule.a, input);
      return;
    }
  }

  // 9. Intent-based response
  const intent = detectIntent(input);
  if (intent) {
    handleIntent(intent, input);
    return;
  }

  // 10. AI fallback
  addBotMsg('🧠 "<b>' + Security.sanitize(input) + '</b>" için yapay zeka ile düşünüyorum...');
  fetchAI(input);
}

// ===== INTENT HANDLERS =====
function handleIntent(intent, input) {
  const name = userProfile ? userProfile.name : '';
  switch (intent) {
    case 'greeting':
      const h = new Date().getHours();
      const timeGreet = h < 12 ? 'Günaydın' : h < 18 ? 'İyi günler' : 'İyi akşamlar';
      addBotMsg(timeGreet + (name ? ' <b>' + name + '</b>' : '') + '! 😊 Bugün sana nasıl yardımcı olabilirim?<br><b>Ctrl+K</b> ile komut paletini aç!', true);
      break;
    case 'farewell':
      addBotMsg('Görüşmek üzere' + (name ? ' ' + name : '') + '! 👋 Kendine iyi bak! 🌟');
      break;
    case 'compliment':
      addBotMsg('Teşekkürler! 😊 Senin için buradayım. Başka ne yapmamı istersin?', true);
      triggerConfetti();
      break;
    case 'mood':
      addBotMsg('🤗 Seni anlıyorum. Unutma, her zor gün geçicidir!<br><br>🔥 <b>Şunları deneyebilirsin:</b><br>1️⃣ <b>/oyun</b> ile eğlen<br>2️⃣ <b>/motivasyon</b> ile güç al<br>3️⃣ <b>/pet</b> ile hayvanınla oyna', true);
      break;
    case 'identity':
      addBotMsg('Ben <b>Ata Ortaokulu Sohbet Programı</b>! 🏫🤖<br>• 🧠 3 katmanlı hafızam var<br>• 🎭 5 farklı mod<br>• 🎮 10+ oyun<br>• 📊 Quiz &amp; testler<br>• 🖼️ Görsel sentez<br>• ⏱️ Pomodoro &amp; not defteri<br><br><b>Ctrl+K</b> ile tüm komutlarımı gör!', true);
      break;
    case 'help':
      addBotMsg('📋 <b>Temel Komutlar:</b><br>🎮 /oyun · 📊 /quiz · 🟩 /wordle<br>🐾 /pet · ⚔️ /macera · 🎨 /çiz<br>📝 /not · ⏱️ /pomodoro · 🌐 /çevir<br>🖼️ /görsel · 🌡️ /hava · 💡 /öğret<br><br><b>Ctrl+K</b> ile komut paletini aç!', true);
      break;
    case 'game':
      openGameMenu();
      addBotMsg('🎮 <b>Oyun Merkezi açıldı!</b> Açılır pencereden istediğin oyunu seç!', true);
      break;
    case 'learn':
      // Kullanıcı doğrudan "sevgi nedir", "fotosentez anlat" dediyse doğrudan AI'ya gönder
      const isJustCommand = /^(öğret|anlat|açıkla|ders|nedir|bilgi ver)$/i.test(input.trim());
      if (!isJustCommand && input.length > 5) {
        fetchAI(input);
      } else {
        // Sadece "anlat" dediyse önceki konuya bak
        const prevU = Memory.shortTerm.filter(m => m.role === 'user');
        const prevTopic = prevU.length >= 2 ? prevU[prevU.length - 2].text : null;
        if (prevTopic && prevTopic.length > 10) {
          fetchAI(prevTopic + ' hakkında daha detaylı açıkla');
        } else {
          AppState.botState = 'WAITING_FOR_WORD';
          addBotMsg('📚 Neyi araştırmamı istersin? Bir konu veya kelime yaz:', true);
        }
      }
      break;
    case 'quiz':
      showQuizMenu();
      break;
    case 'image':
      generateImage(input);
      break;
    case 'weather':
      getLocWeather();
      break;
    case 'fun': {
      const joke = LOCAL_AI.tryLocal('şaka yap');
      if (joke) {
        streamBotMsg(joke, true);
        Memory.addMessage('bot', joke.replace(/<[^>]+>/g, '').substring(0, 200));
        gainXP(3, 'Eğlence');
      } else {
        fetchAI(input);
      }
      break;
    }
    default:
      // Son çare: AI'ya gönder (bilinmeyen intent'ler için)
      addBotMsg('🧠 "<b>' + Security.sanitize(input) + '</b>" için yapay zeka ile düşünüyorum...');
      fetchAI(input);
  }
}

// ===== ACTIONS =====
function triggerAction(act, input) {
  if (act === 'HACKER_MODE') { document.body.classList.add('hacker-mode'); }
  else if (act === 'NORMAL_MODE') { document.body.classList.remove('hacker-mode'); applyChar(); }
  else if (act === 'SHAKE') { document.body.classList.add('quake'); setTimeout(() => document.body.classList.remove('quake'), 2500); }
  else if (act === 'PASSWORD') {
    let pw = ''; for (let i = 0; i < 14; i++) pw += PWCH[Math.floor(Math.random() * PWCH.length)];
    setTimeout(() => addBotMsg('🔐 Şifre:<br><b style="font-size:1.4rem;letter-spacing:3px;color:#fde047">' + pw + '</b>'), 700);
  } else if (act === 'TIMER') {
    const m = alarmReg.exec(input); const n = m ? parseInt(m[1]) : 5;
    const u = m ? (m[2].startsWith('d') ? 'dakika' : 'saniye') : 'saniye';
    const ms = u === 'dakika' ? n * 60000 : n * 1000;
    addBotMsg('⏱️ <b>' + n + ' ' + u + '</b> sonra alarm çalacak...');
    setTimeout(() => { document.body.classList.add('quake'); addBotMsg('🚨 BİİİP! SÜRE DOLDU! 🚨'); triggerConfetti(); setTimeout(() => document.body.classList.remove('quake'), 3000); }, ms);
  } else if (act === 'CONFETTI') { triggerConfetti(); }
}

function applyChar() {
  if (!AppState.currentChar || AppState.currentChar === 'normal') {
    document.getElementById('botName').textContent = MODES[AppState.currentMode].icon + ' Ata Sohbet — ' + MODES[AppState.currentMode].name;
    document.getElementById('avatarIcon').innerHTML = '<img src="https://img.icons8.com/fluency/96/robot-2.png" alt="Bot">';
  } else {
    document.getElementById('botName').textContent = CHARS[AppState.currentChar].n;
    document.getElementById('avatarIcon').innerHTML = '<span style="font-size:1.4rem">' + CHARS[AppState.currentChar].a + '</span>';
  }
}

// ===== CALCULATOR (new Function kaldırıldı — güvenli tokenizer) =====
function safeEval(expression) {
  // Basit recursive descent parser: sadece sayılar ve +-*/ ile () destekler
  // Math.sqrt ve Math.pow ayrıca desteklenir — başka her şey reddedilir.
  const tokens = expression.match(/(Math\.sqrt|Math\.pow|Math\.PI|[\d.]+|[+\-*/(),])/g);
  if (!tokens) throw new Error('invalid');
  let pos = 0;
  function peek() { return tokens[pos]; }
  function consume(expected) {
    if (expected && peek() !== expected) throw new Error('expected ' + expected);
    return tokens[pos++];
  }
  function parseExpr() { let v = parseTerm(); while (peek() === '+' || peek() === '-') { const op = consume(); const r = parseTerm(); v = op === '+' ? v + r : v - r; } return v; }
  function parseTerm() { let v = parseFactor(); while (peek() === '*' || peek() === '/') { const op = consume(); const r = parseFactor(); v = op === '*' ? v * r : v / r; } return v; }
  function parseFactor() {
    const t = peek();
    if (t === '(') { consume('('); const v = parseExpr(); consume(')'); return v; }
    if (t === 'Math.sqrt') { consume(); consume('('); const v = parseExpr(); consume(')'); return Math.sqrt(v); }
    if (t === 'Math.pow') { consume(); consume('('); const a = parseExpr(); consume(','); const b = parseExpr(); consume(')'); return Math.pow(a, b); }
    if (t === 'Math.PI') { consume(); return Math.PI; }
    if (t === '-') { consume(); return -parseFactor(); }
    const num = parseFloat(consume());
    if (isNaN(num)) throw new Error('NaN');
    return num;
  }
  const result = parseExpr();
  if (pos < tokens.length) throw new Error('trailing');
  return result;
}

function tryCalc(input) {
  if (!input.toLowerCase().startsWith('hesapla')) return null;
  let ex = input.toLowerCase().replace('hesapla', '').trim()
    .replace(/karekök\s*\(?(\d+\.?\d*)\)?/g, (_, n) => 'Math.sqrt(' + n + ')')
    .replace(/(\d+\.?\d*)\s*üssü\s*(\d+)/g, (_, a, b) => 'Math.pow(' + a + ',' + b + ')')
    .replace(/\bpi\b/g, 'Math.PI');
  try {
    const r = safeEval(ex);
    if (typeof r !== 'number' || !isFinite(r)) return '❌ Geçersiz sonuç.';
    return '🧮 Sonuç → <b style="font-size:1.4rem;color:#4ade80">' + (Number.isInteger(r) ? r : parseFloat(r.toFixed(4))) + '</b>';
  } catch (e) { return 'Örn: <b>hesapla karekök 144</b>'; }
}

// ===== PRO MODES =====
function handleProMode(mode, input) {
  const lw = input.toLowerCase();
  if (mode === 'OYUN') {
    AppState.proMode = 'NORMAL'; stats.games++; updateStats(); saveStats(); updateQuest('games');
    if (lw.includes('wordle')) { startWordle(); return ''; }
    if (lw.includes('quiz')) { showQuizMenu(); return ''; }
    if (lw.includes('macera')) { startAdventure(); return ''; }
    if (lw.includes('yılan') || lw.includes('snake')) { openGameMenu(); setTimeout(()=>openGameInModal('snake'),300); return ''; }
    if (lw.includes('xox') || lw.includes('tic')) { openGameMenu(); setTimeout(()=>openGameInModal('xox'),300); return ''; }
    if (lw.includes('breakout') || lw.includes('tuğla')) { openGameMenu(); setTimeout(()=>openGameInModal('breakout'),300); return ''; }
    if (lw.includes('pong') || lw.includes('tenis')) { openGameMenu(); setTimeout(()=>openGameInModal('pong'),300); return ''; }
    if (lw.includes('mayın') || lw.includes('mine')) { openGameMenu(); setTimeout(()=>openGameInModal('minesweeper'),300); return ''; }
    if (lw.includes('tepki') || lw.includes('reaction')) { openGameMenu(); setTimeout(()=>openGameInModal('reaction'),300); return ''; }
    if (lw.includes('uç vurma') || lw.includes('uçak') || lw.includes('shooting')) { openGameMenu(); setTimeout(()=>openGameInModal('shooting'),300); return ''; }
    if (lw.includes('araba') || lw.includes('yarış') || lw.includes('racing') || lw.includes('sürüş')) { openGameMenu(); setTimeout(()=>openGameInModal('racing'),300); return ''; }
    openGameMenu();
    return '🎮 Oyun Merkezi açıldı!';
  }
  if (mode === 'EMOJI_GUESS') {
    AppState.modeState.tries++;
    if (lw.includes(AppState.modeState.answer) || AppState.modeState.answer.includes(lw)) {
      AppState.proMode = 'NORMAL'; triggerConfetti(); gainXP(10);
      return '🎉 <b>DOĞRU!</b> ' + AppState.modeState.emoji + ' = <b>' + AppState.modeState.answer + '</b>';
    }
    if (AppState.modeState.tries >= 3) { AppState.proMode = 'NORMAL'; return '❌ Cevap: <b>' + AppState.modeState.answer + '</b>'; }
    return '❌ Yanlış! ' + (3 - AppState.modeState.tries) + ' hakkın kaldı.';
  }
  AppState.proMode = 'NORMAL';
  return '✅ Normal moda döndüm!';
}

// ===== IMAGE GENERATION (NLP Hibrit) =====
// Prompt'tan adet çıkarma: "10 tane elma" → { count: 10, keyword: "elma" }
function parseImageCount(prompt) {
  // "10 tane elma", "5 adet kedi", "3 elma", "elma 10 tane" vb.
  const patterns = [
    /(\d+)\s*(?:tane|adet|adet\w*)\s+(.+)/i,       // "10 tane elma"
    /(.+?)\s+(\d+)\s*(?:tane|adet|adet\w*)/i,       // "elma 10 tane"
    /(\d+)\s+(.+)/i,                                   // "10 elma"
  ];
  for (const pat of patterns) {
    const m = prompt.match(pat);
    if (m) {
      // İlk pattern: m[1]=sayı, m[2]=keyword
      // İkinci pattern: m[1]=keyword, m[2]=sayı
      if (/^\d+$/.test(m[1])) {
        const count = Math.min(Math.max(parseInt(m[1]), 1), 20);
        const keyword = m[2].replace(/\s*(resmi|resmini|görseli|görselini|fotoğrafı)\s*/gi, '').trim();
        if (keyword.length > 0) return { count, keyword };
      } else if (/^\d+$/.test(m[2])) {
        const count = Math.min(Math.max(parseInt(m[2]), 1), 20);
        const keyword = m[1].replace(/\s*(resmi|resmini|görseli|görselini|fotoğrafı)\s*/gi, '').trim();
        if (keyword.length > 0) return { count, keyword };
      }
    }
  }
  return { count: 1, keyword: prompt };
}

async function generateImage(prompt) {
  const uid = 'img' + Date.now();
  const { count, keyword } = parseImageCount(prompt);
  stats.images = (stats.images || 0) + count; saveStats(); updateQuest('images');

  const countLabel = count > 1 ? ` (${count} adet)` : '';
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px" id="' + uid + '">' +
    '<p style="font-weight:700;color:#c084fc;margin-bottom:8px">🖼️ Görsel: "' + Security.sanitize(keyword) + '"' + countLabel + '</p>' +
    '<div id="spin_' + uid + '" style="text-align:center;padding:30px 0">' +
      '<div style="display:inline-block;width:40px;height:40px;border:3px solid #c084fc;border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite"></div>' +
      '<p style="color:var(--sub);font-size:.82rem;margin-top:10px">' + (count > 1 ? count + ' görsel hazırlanıyor...' : 'Sözcükler analiz ediliyor...') + '</p>' +
    '</div>' +
    '<div id="res_' + uid + '" style="display:none;"></div>' +
  '</div>');
  botStatusEl.textContent = '🖼️ Aranıyor...'; botStatusEl.style.color = '#c084fc';

  try {
    // Anahtar kelimeyi İngilizce'ye çevir (LoremFlickr için)
    let engKeyword = keyword;
    try {
      const tRes = await fetch('https://translate.googleapis.com/translate_a/single?client=gtx&sl=tr&tl=en&dt=t&q=' + encodeURIComponent(keyword));
      const tData = await tRes.json();
      engKeyword = tData[0][0][0].replace(/[^\w\s]/g, '').toLowerCase();
      engKeyword = engKeyword.replace(/\b(a|an|the|in|on|at|of|with|is|are|and|or|to|pieces?|items?)\b/g, '').trim().replace(/\s+/g, ',') || 'nature';
    } catch(e) { /* çeviri başarısız olursa Türkçe keyword kullan */ }

    if (count === 1) {
      // === TEK GÖRSEL: Yapay Zeka (Pollinations AI) ===
      const seed = Date.now() % 10000 + Math.floor(Math.random() * 1000);
      const aiUrl = 'https://image.pollinations.ai/prompt/' + encodeURIComponent(engKeyword + ' highly detailed, beautiful') + '?width=512&height=512&nologo=true&seed=' + seed;

      const resEl = document.getElementById('res_' + uid);
      resEl.style.maxWidth = '420px';
      resEl.style.borderRadius = '12px';
      resEl.style.border = '2px solid var(--acc)';
      resEl.style.overflow = 'hidden';
      // AI yüklenemezse LoremFlickr bağlantısına fallback yapar
      resEl.innerHTML = '<img src="' + aiUrl + '" style="width:100%;display:block;aspect-ratio:1/1;" alt="' + Security.sanitize(keyword) + '" onerror="this.onerror=null; this.src=\'https://loremflickr.com/512/512/' + engKeyword + '?lock=' + Date.now() + '\';"/>';

    } else {
      // === ÇOKLU GÖRSEL: AI ve Flickr Karışık Grid ===
      const resEl = document.getElementById('res_' + uid);
      const cols = count <= 4 ? 2 : count <= 9 ? 3 : 4;
      const imgSize = count <= 4 ? 256 : count <= 9 ? 200 : 160;
      let gridHtml = '<div style="display:grid;grid-template-columns:repeat(' + cols + ',1fr);gap:6px;padding:4px;">';
      const baseTime = Date.now();
      for (let i = 0; i < count; i++) {
        const lockVal = baseTime + i * 137 + Math.floor(Math.random() * 1000);
        // İlk görseli yapay zeka ürünü yap, diğerleri varyasyon için Flickr olsun
        const imgUrl = (i === 0)
          ? 'https://image.pollinations.ai/prompt/' + encodeURIComponent(engKeyword) + '?width=' + imgSize + '&height=' + imgSize + '&nologo=true&seed=' + lockVal
          : 'https://loremflickr.com/' + imgSize + '/' + imgSize + '/' + engKeyword + '?lock=' + lockVal;
        
        gridHtml += '<div style="position:relative;border-radius:8px;overflow:hidden;border:1px solid var(--bdr);aspect-ratio:1/1;background:rgba(255,255,255,.03)">' +
          '<img src="' + imgUrl + '" style="width:100%;height:100%;object-fit:cover;display:block;" alt="' + Security.sanitize(keyword) + ' ' + (i+1) + '" loading="lazy" onerror="this.style.display=\'none\'">' +
          '<span style="position:absolute;top:4px;left:6px;font-size:.65rem;color:#fff;background:rgba(0,0,0,.55);padding:1px 6px;border-radius:4px;font-weight:700">' + (i+1) + '</span>' +
        '</div>';
      }
      gridHtml += '</div>';
      gridHtml += '<p style="font-size:.72rem;color:var(--sub);margin-top:8px;text-align:center">' + count + ' adet "' + Security.sanitize(keyword) + '" görseli (Flickr\'dan aranıyor)</p>';
      resEl.innerHTML = gridHtml;
    }

    document.getElementById('spin_' + uid).style.display = 'none';
    document.getElementById('res_' + uid).style.display = 'block';
  } catch (e) {
    document.getElementById('spin_' + uid).innerHTML = '<p style="color:#fca5a5">❌ Görsel yüklenemedi.</p>';
  }
  botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
  gainXP(count > 1 ? 5 + count : 5, 'Görsel oluşturuldu' + (count > 1 ? ' (' + count + ' adet)' : ''));
}

// ===== WEATHER =====
function fetchWeather(city) {
  const cityKey = city.toLowerCase();
  AppState.cache.weather = AppState.cache.weather || {};
  if (AppState.cache.weather[cityKey] && (Date.now() - AppState.cache.weather[cityKey].time < 15 * 60000)) {
    addBotMsg(AppState.cache.weather[cityKey].data, true);
    return;
  }
  botStatusEl.textContent = '🌡️ Hava alınıyor...'; botStatusEl.style.color = '#fde047';
  fetch('https://wttr.in/' + encodeURIComponent(city) + '?format=j1')
    .then(r => r.json()).then(d => {
      botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
      const c = d.current_condition[0];
      const desc = (c.lang_tr && c.lang_tr[0]) ? c.lang_tr[0].value : c.weatherDesc[0].value;
      const html = '🌡 <b>' + city + ':</b> ' + desc + ' · <b style="color:#f97316">' + c.temp_C + '°C</b> · 💧' + c.humidity + '% · 💨' + c.windspeedKmph + ' km/s';
      AppState.cache.weather[cityKey] = { data: html, time: Date.now() };
      addBotMsg(html, true);
    }).catch(() => { botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80'; addBotMsg('❌ Hava alınamadı.'); });
}

function getLocWeather() {
  if (!navigator.geolocation) { fetchWeather('Istanbul'); return; }
  navigator.geolocation.getCurrentPosition(
    pos => fetchWeather(pos.coords.latitude.toFixed(4) + ',' + pos.coords.longitude.toFixed(4)),
    () => fetchWeather('Istanbul'), { timeout: 8000 }
  );
}

// ===== WIKIPEDIA =====
function fetchWiki(phrase) {
  botStatusEl.textContent = '🔍 Araştırılıyor...'; botStatusEl.style.color = '#fde047';
  fetch('https://tr.wikipedia.org/w/api.php?action=query&list=search&srsearch=' + encodeURIComponent(phrase) + '&srlimit=3&utf8=&format=json&origin=*')
    .then(r => r.json()).then(sd => {
      if (!sd.query || !sd.query.search || sd.query.search.length === 0) throw new Error('nf');
      const titles = sd.query.search.slice(0, 3).map(s => s.title);
      return Promise.all(titles.map(t => fetch('https://tr.wikipedia.org/api/rest_v1/page/summary/' + encodeURIComponent(t)).then(r => r.json()).catch(() => null)));
    }).then(results => {
      botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
      const valid = results.filter(d => d && d.extract);
      if (!valid.length) { addBotMsg('"' + phrase + '" bulunamadı.'); AppState.botState = 'NORMAL'; return; }
      let html = '🔍 <b>"' + phrase + '":</b><br><br>';
      valid.forEach((d, i) => {
        html += '<div style="margin-bottom:10px;padding:8px;background:rgba(255,255,255,.04);border-radius:8px;border-left:3px solid var(--acc)"><b>' + (i + 1) + '. ' + d.title + '</b><br>' + d.extract.substring(0, 250) + '</div>';
      });
      addBotMsg(html + '<br>✅ <b>Beynime kaydedildi! 🧠</b>', true);
      Memory.remember(phrase + ': ' + valid[0].extract.substring(0, 100));
      AppState.botState = 'NORMAL';
    }).catch(() => { botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80'; addBotMsg('Araştırma başarısız.'); AppState.botState = 'NORMAL'; });
}

// ===== AI (3-Tier: Local → Wikipedia → Pollinations) =====
const LOCAL_AI = {
  // Konu bazlı akıllı yanıtlar (API'ye gerek yok)
  patterns: [
    { match: /şiir\s*(yaz|söyle|oku)/i, fn: () => '📝 <b>Küçük Şiir</b><br><br><i>Güneş doğar her sabah,<br>Kuşlar öter dallarda.<br>Bilgi arayan gönüller,<br>Yıldız olur yarında.<br><br>Kitaplar açar kapılar,<br>Hayaller uçar göklere.<br>Öğrenen her çocuk bilir,<br>Gelecek onun elinde.</i><br><br>— Ata Sohbet 🤖' },
    { match: /hikaye\s*(yaz|anlat|söyle)/i, fn: () => '📖 <b>Küçük Bir Hikaye</b><br><br>Bir zamanlar küçük bir robot varmış. Adı <b>Ata</b>. Her gün yeni bir şey öğrenirmiş.<br><br>Bir gün bir çocuk ona sormuş: "<i>Sen neden bu kadar çok biliyorsun?</i>"<br><br>Ata gülümsemiş: "<i>Çünkü her gün bir şey öğreniyorum. Öğrenmek bitmez!</i>" 🌟<br><br><b>Son.</b> 📚' },
    { match: /fıkra|espri|şaka|komik/i, fn: () => { const jokes = ['😂 Öğretmen: "Dünya\'nın en uzun nehri hangisi?"\nÖğrenci: "Bilmem hocam ama keşke şu sınav soruları kadar uzun olsaydı!" 🤣','😂 – Doktor bey, hafızam çok zayıf.\n– Bu ne zamandır böyle?\n– Ne ne zamandır böyle? 🤔','😂 Anne oğluna sormuş:\n– Bugün okulda ne öğrendin?\n– Yeterince değil anne, yarın yine gitmem lazım! 📚']; return jokes[Math.floor(Math.random()*jokes.length)].replace(/\n/g,'<br>'); }},
    { match: /motivasyon|güç\s*ver|cesaret/i, fn: () => { const m = ['🚀 <b>Vazgeçme!</b> Her büyük başarı, küçük bir adımla başladı!<br><br>"<i>Başarısızlık, başarıya giden yolun virajıdır.</i>" — Thomas Edison','💪 <b>Sen yapabilirsin!</b><br><br>"<i>Gelecek, hayallerine inananlarındır.</i>"<br>— Eleanor Roosevelt<br><br>Bugün bir adım at, yarın farkı göreceksin! 🌟','🔥 <b>Haydi!</b> Sadece 5 dakika başla!<br><br>"<i>Bin fersahlık yolculuk, tek bir adımla başlar.</i>"<br>— Lao Tzu']; return m[Math.floor(Math.random()*m.length)]; }},
    { match: /matematik.*(formül|alan|çevre|hacim)/i, fn: () => '📐 <b>Temel Formüller:</b><br><br>🟦 <b>Kare:</b> Alan = a² · Çevre = 4a<br>🟫 <b>Dikdörtgen:</b> Alan = a×b · Çevre = 2(a+b)<br>🔺 <b>Üçgen:</b> Alan = (a×h)/2<br>⭕ <b>Daire:</b> Alan = π×r² · Çevre = 2πr<br>📦 <b>Küp:</b> Hacim = a³<br>📦 <b>Prizma:</b> Hacim = Taban Alanı × h' },
    { match: /(gezegenler|güneş\s*sistemi|uzay)/i, fn: () => '🌍 <b>Güneş Sistemi:</b><br><br>☀️ Güneş (Yıldız)<br>1️⃣ Merkür — En küçük, Güneş\'e en yakın<br>2️⃣ Venüs — En sıcak gezegen<br>3️⃣ <b>Dünya</b> — Bizim evimiz! 🏠<br>4️⃣ Mars — Kırmızı gezegen<br>5️⃣ Jüpiter — En büyük gezegen<br>6️⃣ Satürn — Halkalı gezegen<br>7️⃣ Uranüs — Yan yatık döner<br>8️⃣ Neptün — En uzak gezegen' },
    { match: /(atatürk|cumhuriyet|türkiye.*tarih)/i, fn: () => '🇹🇷 <b>Cumhuriyet\'in Kuruluşu:</b><br><br>👤 <b>Mustafa Kemal Atatürk</b> (1881-1938)<br><br>📅 Önemli Tarihler:<br>🔹 1919 — Samsun\'a çıkış (19 Mayıs)<br>🔹 1920 — TBMM açılışı (23 Nisan)<br>🔹 1922 — Büyük Taarruz (30 Ağustos)<br>🔹 <b>1923</b> — Cumhuriyet\'in ilanı (29 Ekim) 🎉<br><br>"<i>Ne mutlu Türk\'üm diyene!</i>" — Atatürk' },
    { match: /(insan\s*vücudu|organlar|sindirim|dolaşım|solunum)/i, fn: () => '🫀 <b>İnsan Vücudu Sistemleri:</b><br><br>❤️ <b>Dolaşım:</b> Kalp + Kan damarları<br>🫁 <b>Solunum:</b> Burun → Bronşlar → Akciğerler<br>🍕 <b>Sindirim:</b> Ağız → Mide → Bağırsak<br>🧠 <b>Sinir:</b> Beyin + Omurilik + Sinirler<br>💪 <b>Kas-İskelet:</b> 206 kemik + 600+ kas<br>🛡️ <b>Boşaltım:</b> Böbrekler + Mesane' },
    { match: /(saat\s*kaç|tarih\s*ne|bugün\s*ne|bugünün\s*tarihi|bugün\s*tarih|tarih\s*nedir|hangi\s*gün|kaç\s*tarih|günlerden\s*ne|bugün\s*hangi|ayın\s*kaçı)/i, fn: () => { const now = new Date(); return '🕐 Şu an: <b>' + now.toLocaleString('tr-TR') + '</b><br>📅 ' + now.toLocaleDateString('tr-TR', {weekday:'long',year:'numeric',month:'long',day:'numeric'}); }},
    { match: /(çarpım\s*tablosu|çarpma\s*tablo)/i, fn: () => { let h = '✖️ <b>Çarpım Tablosu:</b><br><br>'; for(let i=2;i<=9;i++){h+='<b>'+i+':</b> ';for(let j=1;j<=10;j++)h+=i+'×'+j+'='+i*j+(j<10?' · ':'');h+='<br>';} return h; }},
    { match: /(renk.*karıştır|renk.*oluş|ana\s*renk)/i, fn: () => '🎨 <b>Ana Renkler ve Karışımlar:</b><br><br>🔴 Kırmızı + 🟡 Sarı = 🟠 <b>Turuncu</b><br>🔴 Kırmızı + 🔵 Mavi = 🟣 <b>Mor</b><br>🔵 Mavi + 🟡 Sarı = 🟢 <b>Yeşil</b><br><br>Ana Renkler: 🔴🔵🟡<br>Ara Renkler: 🟠🟣🟢' },
  ],

  tryLocal(input) {
    const lw = input.toLowerCase();
    for (const p of this.patterns) {
      if (p.match.test(lw)) return p.fn();
    }
    return null;
  }
};

function fetchAI(input) {
  // Tier 1: Yerel akıllı yanıt
  const localAnswer = LOCAL_AI.tryLocal(input);
  if (localAnswer) {
    streamBotMsg(localAnswer, true);
    Memory.addMessage('bot', localAnswer.replace(/<[^>]+>/g, '').substring(0, 200));
    gainXP(3, 'Bilgi aldın');
    return;
  }

  // Tier 2: Cloudflare Worker Proxy / Gemini
  botStatusEl.textContent = '🧠 Gemini düşünüyor...'; botStatusEl.style.color = '#4285f4';
  tryAnthropicProxy(input);
}

// ===== PROXY → CLOUDFLARE WORKER (Gemini Edition — API key client'ta YOK) =====
function tryAnthropicProxy(input) {

  const proxyUrl = getProxyEndpoint();
  if (!proxyUrl || proxyUrl.includes('YOUR_USERNAME')) {
    tryPollinations(input);
    return;
  }

  const intent = detectIntent(input);
  const prompt = buildPrompt(input, intent);
  botStatusEl.textContent = '🧠 Gemini düşünüyor...'; botStatusEl.style.color = '#4285f4';

  fetch(getProxyEndpoint() + '/api/ai', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      input: input.substring(0, 500),
      systemPrompt: prompt,
      maxTokens: 400
    }),
    signal: AbortSignal.timeout(20000)
  }).then(r => {
    if (!r.ok) throw new Error('proxy_error_' + r.status);
    return r.json();
  }).then(data => {
    botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
    if (data.error) throw new Error(data.error);
    const text = (data.text || '').replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*?work normally\./gi, '').replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*$/gi, '').trim();
    if (!text || text.length < 6) throw new Error('Proxy returned empty response');
    
    let htmlText = safeHTML(text)
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
      .replace(/\*(.+?)\*/g, '<i>$1</i>');
    Memory.addMessage('bot', text.replace(/<[^>]+>/g, '').substring(0, 200));
    streamBotMsg('<span style="font-size:0.75rem;color:#4285f4;display:block;margin-bottom:6px">✨ Gemini 1.5 Flash ile yanıtlandı</span>' + htmlText, true);
    gainXP(4, 'Gemini Cevabı');
  }).catch(e => {
    console.warn('Gemini Proxy Error — Pollinations fallback:', e);
    tryPollinations(input);
  });
}

// Eski tryAnthropic: Geriye dönük uyumluluk için proxy'ye yönlendir
function tryAnthropic(input, _key) {
  tryAnthropicProxy(input);
}

// ===== DOĞRUDAN GEMINİ API (Kullanıcı kendi key'ini girdiyse) =====
function tryDirectGemini(input, apiKey) {
  const intent = detectIntent(input);
  const prompt = buildPrompt(input, intent);
  botStatusEl.textContent = '🔑 Gemini (kendi key)...'; botStatusEl.style.color = '#4285f4';

  const url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' + apiKey;

  fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt + '\n\nKullanıcı: ' + input.substring(0, 500) }] }],
      generationConfig: { maxOutputTokens: 600, temperature: 0.7 }
    }),
    signal: AbortSignal.timeout(20000)
  }).then(r => {
    if (!r.ok) throw new Error('gemini_direct_' + r.status);
    return r.json();
  }).then(data => {
    botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    if (!text) throw new Error('empty_response');
    let htmlText = safeHTML(text)
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
      .replace(/\*(.+?)\*/g, '<i>$1</i>');
    Memory.addMessage('bot', text.replace(/<[^>]+>/g, '').substring(0, 200));
    streamBotMsg('<span style="font-size:0.75rem;color:#4285f4;display:block;margin-bottom:6px">🔑 Gemini (Kendi Anahtarınız)</span>' + htmlText, true);
    gainXP(4, 'Gemini Direct');
  }).catch(e => {
    console.warn('Direct Gemini Error — Proxy fallback:', e);
    // Key geçersizse proxy'ye düş
    const proxyUrl = getProxyEndpoint();
    if (proxyUrl && !proxyUrl.includes('YOUR_USERNAME')) {
      // Proxy dene
      const intent2 = detectIntent(input);
      const prompt2 = buildPrompt(input, intent2);
      fetch(proxyUrl + '/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ input: input.substring(0, 500), systemPrompt: prompt2, maxTokens: 400 }),
        signal: AbortSignal.timeout(20000)
      }).then(r => r.json()).then(data => {
        botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
        if (data.error) throw new Error(data.error);
        const t = safeHTML(data.text || '').replace(/\n/g, '<br>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
        streamBotMsg(t, true);
      }).catch(() => tryPollinations(input));
    } else {
      tryPollinations(input);
    }
  });
}

function tryPollinations(input) {
  const intent = detectIntent(input);
  const prompt = buildPrompt(input, intent);
  botStatusEl.textContent = '🧠 AI düşünüyor...'; botStatusEl.style.color = '#c084fc';
  
  // Tier 1: Pollinations OpenAI-uyumlu POST endpoint
  fetch('https://text.pollinations.ai/openai', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: [{role:'system', content:prompt}, {role:'user', content:input}], model: 'openai' }),
    signal: AbortSignal.timeout(15000)
  })
    .then(r => {
      if (r.status === 429) throw new Error('rate_limit');
      if (!r.ok) throw new Error('api_error');
      return r.json();
    }).then(d => {
      let t = d?.choices?.[0]?.message?.content || '';
      t = t.replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*?work normally\./gi, '').trim();
      t = t.replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*$/gi, '').trim();
      if (t.length < 6) throw new Error('empty_response');
      t = t.replace(/\n/g, '<br>')
           .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
           .replace(/\*(.+?)\*/g, '<i>$1</i>');
      botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
      Memory.addMessage('bot', t.replace(/<br>/g, '\n').replace(/<[^>]+>/g, '').substring(0, 200));
      streamBotMsg(t, true);
      gainXP(3, 'AI cevabı');
    }).catch(err => {
      console.warn('Pollinations POST Error, trying GET endpoint:', err);
      // Tier 2: Pollinations Text GET endpoint (tamamen anahtarsız)
      tryPollinationsGET(input, prompt);
    });
}

function tryPollinationsGET(input, prompt) {
  const fullPrompt = prompt + '\n\nKullanıcı: ' + input;
  fetch('https://text.pollinations.ai/' + encodeURIComponent(fullPrompt) + '?model=openai', {
    method: 'GET',
    signal: AbortSignal.timeout(20000)
  }).then(r => {
    if (!r.ok) throw new Error('pollinations_get_' + r.status);
    return r.text();
  }).then(text => {
    botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
    if (!text || text.length < 6) throw new Error('empty_response');
    text = text.replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*?work normally\./gi, '').replace(/\*\*IMPORTANT NOTICE\*\*[\s\S]*$/gi, '').trim();
    if (text.length < 6) throw new Error('empty_after_cleanup');
    let t = safeHTML(text)
      .replace(/\n/g, '<br>')
      .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
      .replace(/\*(.+?)\*/g, '<i>$1</i>');
    Memory.addMessage('bot', text.replace(/<[^>]+>/g, '').substring(0, 200));
    streamBotMsg(t, true);
    gainXP(3, 'AI cevabı');
  }).catch(err => {
    console.warn('Pollinations GET Error, fully offline:', err);
    botStatusEl.textContent = '🟢 Çevrimiçi'; botStatusEl.style.color = '#4ade80';
    if (err.message === 'rate_limit') {
      addBotMsg('⏳ Yapay zeka şu an meşgul. Lütfen <b>10 saniye</b> bekleyip tekrar dene!<br><br>🔄 Bu arada şunları deneyebilirsin:<br>🎮 /oyun · 📊 /quiz · 🟩 /wordle', true);
    } else {
      addBotMsg('⚠️ <b>AI servisleri geçici olarak yanıt vermiyor.</b><br>' +
        '<span style="color:var(--sub);font-size:.82rem">Lütfen daha sonra tekrar deneyin veya internet bağlantınızı kontrol edin.</span><br><br>' +
        '💡 <b>Yapabileceklerin:</b><br>' +
        '• 🎮 <b>/oyun</b> ile oyun oyna (çevrimdışı)<br>' +
        '• 📊 <b>/quiz</b> ile bilgi yarışmasına katıl', true);
    }
  });
}

// ===== THEMES =====
function setTheme(t, btn) {
  document.documentElement.setAttribute('data-theme', t === 'default' ? '' : t);
  document.querySelectorAll('.tbtn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  localStorage.setItem('bot_theme', t);
}
function loadTheme() {
  let t = localStorage.getItem('bot_theme');
  if (!t) {
    const hr = new Date().getHours();
    // 08:00 - 18:00 arası gündüz (ocean), diğerleri gece (default)
    t = (hr >= 8 && hr < 18) ? 'ocean' : 'default';
  }
  document.documentElement.setAttribute('data-theme', t === 'default' ? '' : t);
  const btn = document.querySelector('.tbtn[data-t="' + t + '"]');
  if (btn) { document.querySelectorAll('.tbtn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); }
}

// ===== CMD PALETTE =====
function openCmdPalette() { document.getElementById('cmdOverlay').classList.add('active'); const ci = document.getElementById('cmdInput'); ci.value = ''; ci.focus(); renderCmdList(''); }
function closeCmdPalette() { document.getElementById('cmdOverlay').classList.remove('active'); }
function renderCmdList(q) {
  const list = document.getElementById('cmdList'); list.innerHTML = '';
  const filtered = q ? CMD_LIST.filter(c => c.name.includes(q.toLowerCase()) || c.desc.toLowerCase().includes(q.toLowerCase())) : CMD_LIST;
  filtered.forEach(c => {
    const d = document.createElement('div'); d.className = 'cmd-item';
    d.innerHTML = '<span class="ci-icon">' + c.icon + '</span><div><div class="ci-name">' + c.name + '</div><div class="ci-desc">' + c.desc + '</div></div>';
    d.onclick = () => { closeCmdPalette(); userInput.value = c.cmd; if (!c.cmd.endsWith(' ')) sendMessage(); else userInput.focus(); };
    list.appendChild(d);
  });
}

// ===== EXPORT =====
function exportChat() {
  const format = prompt('Hangi formatta indirmek istiyorsun? (txt, md, json, pdf)', 'md')?.toLowerCase();
  if (!format) return;
  if (format === 'pdf') { window.print(); return; }
  
  let content = '', ext = format, mime = 'text/plain';
  const msgs = Array.from(document.querySelectorAll('.message')).map(m => ({
    role: m.classList.contains('msg-user') ? 'SEN' : 'BOT',
    text: m.innerText
  }));
  
  if (format === 'json') {
    content = JSON.stringify({ app: 'Ata Ortaokulu Sohbet', date: new Date().toISOString(), messages: msgs }, null, 2);
    mime = 'application/json';
  } else if (format === 'md') {
    content = '# ATA ORTAOKULU SOHBET GEÇMİŞİ\n*Tarih: ' + new Date().toLocaleString('tr-TR') + '*\n\n';
    msgs.forEach(m => { content += '### ' + (m.role === 'SEN' ? '👤 Sen' : '🤖 Bot') + '\n' + m.text + '\n\n---\n\n'; });
  } else {
    content = '=== ATA ORTAOKULU SOHBET ===\nTarih: ' + new Date().toLocaleString('tr-TR') + '\n\n';
    msgs.forEach(m => { content += '[' + m.role + '] ' + m.text + '\n\n'; });
    ext = 'txt';
  }
  
  const a = document.createElement('a'); a.href = 'data:' + mime + ';charset=utf-8,' + encodeURIComponent(content);
  a.download = 'sohbet_' + new Date().toISOString().slice(0, 10) + '.' + ext; a.click();
}

// ===== MODALS =====
function openSettings() { 
  document.getElementById('settingsModal').classList.add('active'); 
  
  renderRules(); 
}
function closeSettings() { document.getElementById('settingsModal').classList.remove('active'); }
function renderRules() {
  const list = document.getElementById('ruleList'); list.innerHTML = '';
  if (!learnedRaw.length) { list.innerHTML = '<div style="color:var(--sub);text-align:center;padding:18px">Henüz öğrenilmiş kural yok.</div>'; return; }
  learnedRaw.forEach((rule, i) => {
    const d = document.createElement('div'); d.className = 'rule-item';
    d.innerHTML = '<button class="btn-del" onclick="delRule(' + i + ')">Sil</button><label>Anahtar:</label><input type="text" value="' + rule.keywords.join(', ') + '" id="ek_' + i + '"><label>Cevap:</label><textarea id="er_' + i + '">' + rule.response.replace(/<br\s*\/?>/gi, '\n').replace(/<[^>]+>/g, '') + '</textarea>';
    list.appendChild(d);
  });
}
function addNewRule() {
  const kw = document.getElementById('newRuleKw').value.trim();
  const res = document.getElementById('newRuleRes').value.trim();
  if (!kw || !res) { alert('Anahtar ve cevap gerekli!'); return; }
  const kws = kw.split(',').map(k => k.trim().toLowerCase()).filter(Boolean);
  const rule = { keywords: kws, response: res.replace(/\n/g, '<br>') };
  learnedRaw.push(rule); RULES.push({ kw: kws, r: rule.response });
  localStorage.setItem('bot_hafiza', JSON.stringify(learnedRaw));
  document.getElementById('newRuleKw').value = ''; document.getElementById('newRuleRes').value = '';
  renderRules(); addBotMsg('✅ Kural eklendi! 📝');
}

function delRule(i) {
  if (!confirm('Silmek istiyor musun?')) return;
  learnedRaw.splice(i, 1);
  localStorage.setItem('bot_hafiza', JSON.stringify(learnedRaw));
  // Bug #7 fix: RULES runtime dizisini de güncelle
  RULES.length = 0;
  RULES.push(...[
    { kw: ['hacker modu','matrix','hacker ol'], r: 'Sistem KONTROL ALTINA ALINDI. Terminal\'e geçiliyor... Hoş geldin, Neo.', a: 'HACKER_MODE', p: 100 },
    { kw: ['normal mod','eski haline','hacker modunu kapat'], r: 'Sistem güvenliği sağlandı.', a: 'NORMAL_MODE', p: 100 },
    { kw: ['ekranı salla','deprem','titre'], r: 'Sıkı tutun!! 8.0 şiddetinde titreşim! 🌍', a: 'SHAKE', p: 10 },
    { kw: ['şifre üret','şifre ver','güvenli şifre'], r: 'Kırılmaz şifre üretiliyor...', a: 'PASSWORD', p: 10 },
    { kw: ['alarm','saniye say','dakika','timer'], r: '__ALARM__', a: 'TIMER', p: 10 },
    ...learnedRaw.map(r => ({ kw: r.keywords, r: r.response, p: r.priority || 1, regex: r.isRegex || false }))
  ]);
  updateStats(); renderRules();
}
function clearMemory() { if (confirm('Tüm öğrenilenler silinecek!')) { localStorage.removeItem('bot_hafiza'); localStorage.removeItem('bot_longmem'); location.reload(); } }
function localLogout() {
  if (!confirm('Çıkış yapmak istediğine emin misin?\nProfil verilerin silinecek ama öğrenilen kurallar kalacak.')) return;
  localStorage.removeItem('bot_user');
  localStorage.removeItem('bot_stats');
  localStorage.removeItem('bot_badges');
  localStorage.removeItem('bot_longmem');
  localStorage.removeItem('bot_notes');
  localStorage.removeItem('bot_pet');
  location.reload();
}
function toggleSidebar() { document.querySelector('.sidebar').classList.toggle('open'); document.getElementById('sidebarBackdrop').classList.toggle('active'); }

// ===== REGISTER ALL PLUGINS =====
registerPlugin({ command: '/wordle', icon: '🟩', description: 'Kelime tahmin oyunu', needsArg: false, run: () => startWordle() });
registerPlugin({ command: '/pet', icon: '🐾', description: 'Sanal evcil hayvan', needsArg: false, run: () => showPet() });
registerPlugin({ command: '/macera', icon: '⚔️', description: 'RPG macera', needsArg: false, run: () => startAdventure() });
registerPlugin({ command: '/quiz', icon: '📊', description: 'Bilgi yarışması', needsArg: true, run: ctx => ctx.args ? startQuiz(ctx.args) : showQuizMenu() });
registerPlugin({ command: '/pomodoro', icon: '⏱️', description: 'Pomodoro zamanlayıcı', needsArg: false, run: () => startPomodoro() });
registerPlugin({ command: '/not', icon: '📋', description: 'Not defteri', needsArg: true, run: ctx => handleNotes(ctx.args) });
registerPlugin({ command: '/çiz', icon: '🎨', description: 'Çizim tahtası', needsArg: false, run: () => startDrawing() });
registerPlugin({ command: '/çevir', icon: '🌐', description: 'Metin çeviri', needsArg: true, run: ctx => doTranslate(ctx.args) });
registerPlugin({ command: '/analiz', icon: '📈', description: 'Metin analizi', needsArg: true, run: ctx => doTextAnalysis(ctx.args) });
registerPlugin({ command: '/şifrele', icon: '🔐', description: 'Metin şifreleme', needsArg: true, run: ctx => doCipher(ctx.args) });
registerPlugin({ command: '/çöz', icon: '🔓', description: 'Şifre çözme', needsArg: true, run: ctx => decodeCipher(ctx.args) });
registerPlugin({ command: '/emoji-tahmin', icon: '😂', description: 'Emoji bulmaca', needsArg: false, run: () => startEmojiGuess() });
registerPlugin({ command: '/oyun', icon: '🎮', description: 'Oyun menüsü', needsArg: false, run: () => openGameMenu() });
registerPlugin({ command: '/görsel', icon: '🖼️', description: 'Görsel oluştur', needsArg: true, run: ctx => ctx.args ? generateImage(ctx.args) : addBotMsg('❌ Kullanım: /görsel kedi') });
registerPlugin({ command: '/kart', icon: '📝', description: 'Flashcard çalışma', needsArg: false, run: () => showFlashcard() });
registerPlugin({ command: '/formül', icon: '🔢', description: 'Formül asistanı', needsArg: true, run: ctx => showFormula(ctx.args) });
registerPlugin({ command: '/hava', icon: '🌡️', description: 'Hava durumu', needsArg: true, run: ctx => fetchWeather(ctx.args || 'Istanbul') });
registerPlugin({ command: '/motivasyon', icon: '🚀', description: 'Motivasyon koçu', needsArg: false, run: () => { triggerConfetti(); addBotMsg('🚀 <b>Haydi!</b> Vazgeçme! Sadece 5 dakika başla, gücünü hissedeceksin! 💪🔥', true); } });
registerPlugin({ command: '/rastgele', icon: '🎲', description: 'İlginç bilgi', needsArg: false, run: () => { triggerConfetti(); addBotMsg(TRIVIA[Math.floor(Math.random() * TRIVIA.length)], true); } });
registerPlugin({ command: '/karakter', icon: '🎭', description: 'Bot karakteri değiştir', needsArg: false, run: () => { const ck = charKeys[Math.floor(Math.random() * charKeys.length)]; AppState.currentChar = ck; applyChar(); addBotMsg('🎭 Artık ben <b>' + CHARS[ck].n + '</b>\'yım! ' + CHARS[ck].p); } });
registerPlugin({ command: '/normal', icon: '❌', description: 'Normal moda dön', needsArg: false, run: () => { setMode('normal'); AppState.currentChar = 'normal'; applyChar(); } });

// ===== YENİ OYUN PLUGİNLERİ =====
registerPlugin({ command: '/hafıza', icon: '🃏', description: 'Hafıza kartı oyunu', needsArg: false, run: () => startMemoryGame() });
registerPlugin({ command: '/mateyar', icon: '⚡', description: 'Matematik yarışması (60s)', needsArg: false, run: () => startMathRace() });
registerPlugin({ command: '/sudoku', icon: '🔢', description: '4×4 mini Sudoku', needsArg: false, run: () => startSudoku() });

// ===== DERS MODÜLÜ =====
const LESSON_DATA = [
  { id: 'nedir', title: '🤖 Yapay Zeka Nedir?', color: '#3b82f6',
    content: 'Yapay Zeka (YZ), bilgisayarların insan gibi düşünmesini, öğrenmesini ve problem çözmesini sağlayan teknolojidir.<br><br>📌 <b>Temel Kavramlar:</b><br>• <b>Algoritma:</b> Bilgisayarın izlediği adımlar<br>• <b>Veri:</b> YZ\'nin öğrendiği bilgiler<br>• <b>Model:</b> Öğrenilen bilgilerin özeti<br><br>💡 <b>Örnek:</b> Netflix\'in film önerisi, Google Çeviri, sesli asistanlar.',
    quiz: { q: 'Yapay Zekanın öğrenmek için ihtiyaç duyduğu şey nedir?', opts: ['Veri','Su','Elektrik','Kağıt'], a: 0 }
  },
  { id: 'ml', title: '🧠 Makine Öğrenmesi', color: '#10b981',
    content: 'Makine Öğrenmesi, bilgisayarların örneklerden kendi kendine öğrenmesi sürecidir.<br><br>📌 <b>3 Ana Tür:</b><br>• <b>Denetimli Öğrenme:</b> Etiketli verilerle eğitim (kedi/köpek fotoğrafları)<br>• <b>Denetimsiz Öğrenme:</b> Kendi kalıplarını bulur<br>• <b>Pekiştirmeli Öğrenme:</b> Deneme yanılma ile öğrenir<br><br>💡 <b>Örnek:</b> E-posta spam filtresi, yüz tanıma sistemi.',
    quiz: { q: 'E-posta spam filtresi hangi öğrenme türüne örnektir?', opts: ['Denetimli','Denetimsiz','Pekiştirmeli','Klasik'], a: 0 }
  },

  { id: 'kural', title: '⚙️ Kural Tabanlı Sistemler', color: '#f97316',
    content: 'Kural tabanlı sistemler, önceden yazılmış kurallara göre çalışır. Eğer-ise (IF-THEN) mantığını kullanır.<br><br>📌 <b>Örnek Kurallar:</b><br>• EĞER sıcaklık > 38 İSE → Ateş var<br>• EĞER kelime = "merhaba" İSE → Selam ver<br><br>✅ <b>Avantaj:</b> Şeffaf, anlaşılır, kontrol edilebilir<br>❌ <b>Dezavantaj:</b> Tüm durumları önceden yazmak zor',
    quiz: { q: 'Kural tabanlı sistemlerin temel mantığı nedir?', opts: ['Eğer-İse (IF-THEN)','Deneme-Yanılma','Beyin sinapsları','Rastgele seçim'], a: 0 }
  },
  { id: 'gunluk', title: '🌍 Günlük Hayatta YZ', color: '#ec4899',
    content: 'Yapay zeka hayatımızın her alanında gizlidir!<br><br>📱 <b>Akıllı Telefon:</b> Yüz kilidi, fotoğraf çekimi<br>🎵 <b>Müzik:</b> Spotify\'ın şarkı önerisi<br>🛒 <b>Alışveriş:</b> Amazon\'un ürün önerisi<br>🚗 <b>Ulaşım:</b> Google Maps trafiği<br>🏥 <b>Sağlık:</b> Kanser teşhisi, ilaç keşfi<br>🎮 <b>Oyun:</b> Oyundaki rakip karakterler (NPC)',
    quiz: { q: 'Hangisi günlük hayatta YZ kullanımına örnek DEĞİLDİR?', opts: ['Kalemle yazı yazmak','Yüz kilidi','Spotify önerisi','GPS navigasyon'], a: 0 }
  },
  { id: 'gelecek', title: '🚀 YZ\'nin Geleceği', color: '#8b5cf6',
    content: 'Yapay Zeka hızla gelişiyor ve geleceği şekillendiriyor!<br><br>🔮 <b>Yakın Gelecek:</b><br>• Otonom araçlar (sürücüsüz arabalar)<br>• Kişisel YZ asistanları<br>• Akıllı şehirler<br><br>⚠️ <b>Dikkat Edilmesi Gerekenler:</b><br>• Gizlilik ve veri güvenliği<br>• İş kayıpları<br>• Etik sorunlar<br><br>💡 Siz de YZ\'yi öğrenerek bu geleceği şekillendirebilirsiniz! 🌟',
    quiz: { q: 'YZ\'nin geleceğiyle ilgili dikkat edilmesi gereken hangisi?', opts: ['Gizlilik ve veri güvenliği','Daha fazla yemek','Daha az kitap','Hızlı koşmak'], a: 0 }
  }
];

// ===== DERS KONUSUna ÖZEL QUİZ =====
const LESSON_QUIZZES = {
  nedir: [
    { q: 'YZ\'nin açılımı nedir?', opts: ['Yapay Zeka','Yüksek Zeka','Yazılım Zekası','Yaşayan Zeka'], a: 0 },
    { q: 'Hangisi bir yapay zeka uygulamasıdır?', opts: ['Hesap makinesi','Google Çeviri','Elektrik süpürgesi','Termos'], a: 1 },
    { q: 'YZ\'nin öğrenmek için temel ihtiyacı nedir?', opts: ['Elektrik','Su','Veri','Plastik'], a: 2 },
    { q: 'Algoritma ne anlama gelir?', opts: ['Bilgisayar donanımı','Adım adım çözüm yolu','Veritabanı','İşletim sistemi'], a: 1 },
    { q: 'Model kavramı YZ\'de ne ifade eder?', opts: ['Oyuncak robot','Öğrenilen bilgilerin özeti','Bir program dili','Ekran kartı'], a: 1 },
  ],
  ml: [
    { q: 'Makine öğrenmesi ne demektir?', opts: ['Fabrikada çalışan robot','Örneklerden kendi kendine öğrenme','İnsan tarafından programlama','Kodlama dili'], a: 1 },
    { q: 'Etiketli verilerle yapılan öğrenme türü hangisidir?', opts: ['Denetimsiz','Pekiştirmeli','Denetimli','Yarı denetimli'], a: 2 },
    { q: 'Spam filtreleme hangi öğrenme türünü kullanır?', opts: ['Denetimli öğrenme','Pekiştirmeli öğrenme','Denetimsiz öğrenme','Ezberleme'], a: 0 },
    { q: 'Pekiştirmeli öğrenme nasıl çalışır?', opts: ['Hazır kurallarla','Etiketli veriyle','Deneme yanılma ile','Kopyalayarak'], a: 2 },
    { q: 'Yüz tanıma sistemi hangi öğrenme türünü kullanır?', opts: ['Denetimli öğrenme','Denetimsiz öğrenme','Pekiştirmeli','Klasik programlama'], a: 0 },
  ],
  kural: [
    { q: 'Kural tabanlı sistemlerin temel mantığı nedir?', opts: ['Deneme yanılma','Eğer-İse (IF-THEN)','Veri toplama','Tahmin etme'], a: 1 },
    { q: 'Kural tabanlı sistemlerin avantajı nedir?', opts: ['Kendi kendine öğrenir','Şeffaf ve anlaşılır','Çok fazla veri ister','Çok hızlıdır'], a: 1 },
    { q: '"EĞER sıcaklık > 38 İSE ateş var" bir kural örneğidir. Bu ne tür bir sistem?', opts: ['Makine öğrenmesi','Kural tabanlı sistem','Derin öğrenme','Nöral ağ'], a: 1 },
    { q: 'Kural tabanlı sistemlerin dezavantajı', opts: ['Yavaş çalışır','Tüm durumları önceden yazmak zor','Veri gerektirir','Anlaşılması zordur'], a: 1 },
    { q: 'Chatbot\'lar genellikle hangi sistemi kullanır?', opts: ['Sadece makine öğrenmesi','Sadece kural tabanlı','Hibrit (kural + ML)','Hiçbiri'], a: 2 },
  ],
  gunluk: [
    { q: 'Hangisi günlük hayatta YZ örneği DEĞİLDİR?', opts: ['Spotify önerisi','Kalemle yazı yazmak','GPS navigasyon','Yüz kilidi'], a: 1 },
    { q: 'Netflix film önerisi hangi teknolojiyi kullanır?', opts: ['Kural tabanlı','Yapay zeka (ML)','El ile seçim','Rastgele'], a: 1 },
    { q: 'Oyunlardaki NPC karakterler ne için YZ kullanır?', opts: ['Grafik çizmek','Davranış kararları almak','Ses çıkarmak','Ekran boyutunu ayarlamak'], a: 1 },
    { q: 'Sağlık alanında YZ ne işe yarar?', opts: ['Ameliyat yapar','Teşhis destekler ve ilaç keşfeder','Hasta kaydeder','Hastaneyi temizler'], a: 1 },
    { q: 'Google Haritalar trafiği tahmin etmek için ne kullanır?', opts: ['Uydu görüntüsü','Yapay zeka ve geçmiş veri','Polis bilgisi','El ile hesaplama'], a: 1 },
  ],
  gelecek: [
    { q: 'Otonom araç nedir?', opts: ['Elektrikli araba','Sürücüsüz, kendi kendine giden araç','Hızlı tren','Uçan araba'], a: 1 },
    { q: 'YZ\'nin geleceğiyle ilgili en önemli endişe hangisidir?', opts: ['Renk seçimi','Gizlilik ve veri güvenliği','Fiyat','Kablo uzunluğu'], a: 1 },
    { q: 'Akıllı şehirler YZ\'yi ne için kullanır?', opts: ['Şehri boyamak','Trafik, enerji ve hizmet yönetimi','Sadece aydınlatma','Park yönetimi'], a: 1 },
    { q: 'İş kayıpları YZ\'den nasıl kaynaklanır?', opts: ['YZ para çalar','YZ bazı görevleri otomatikleştirir','YZ insanları kovder','YZ elektriği keser'], a: 1 },
    { q: 'Sen de YZ\'nin geleceğini şekillendirebilmek için ne yapmalısın?', opts: ['Hiçbir şey','YZ\'yi öğrenmek ve etik kullanmak','YZ\'yi yasaklamak','Bilgisayar kullanmamak'], a: 1 },
  ],
};

function startLessonQuiz(unitId) {
  const questions = LESSON_QUIZZES[unitId];
  const unit = LESSON_DATA.find(u => u.id === unitId);
  if (!questions || !unit) return;

  let current = 0, score = 0;
  const uid = 'lq' + Date.now();

  function renderQ() {
    const q = questions[current];
    const progress = `${current + 1}/${questions.length}`;
    const progressPct = Math.round((current / questions.length) * 100);
    addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px;border-left:4px solid ${unit.color}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <span style="font-size:.75rem;color:${unit.color};font-weight:700">📊 ${unit.title} — Quiz</span>
        <span style="font-size:.75rem;color:var(--sub)">${progress} • Puan: <b style="color:#fde047">${score}</b></span>
      </div>
      <div style="height:4px;background:rgba(255,255,255,.08);border-radius:99px;margin-bottom:12px">
        <div style="height:100%;width:${progressPct}%;background:${unit.color};border-radius:99px;transition:width .4s"></div>
      </div>
      <p style="font-weight:700;margin-bottom:10px;font-size:.92rem">${q.q}</p>
      ${q.opts.map((o, i) => `<button onclick="lqAns_${uid}_${current}(${i})" id="lqa${uid}_${current}_${i}"
        style="display:block;width:100%;margin:4px 0;padding:10px;background:rgba(255,255,255,.04);border:1px solid var(--bdr);border-radius:8px;color:var(--txt);cursor:pointer;text-align:left;font-size:.85rem;transition:.2s"
        onmouseover="this.style.background='rgba(59,130,246,.15)'" onmouseout="this.style.background='rgba(255,255,255,.04)'">${o}</button>`).join('')}
      <p id="lqf${uid}_${current}" style="min-height:18px;font-size:.82rem;margin-top:6px"></p>
    </div>`);

    window[`lqAns_${uid}_${current}`] = function(chosen) {
      const idx = current; // closure
      document.querySelectorAll(`[id^="lqa${uid}_${idx}_"]`).forEach(b => { b.disabled = true; b.style.cursor = 'default'; });
      const fb = document.getElementById(`lqf${uid}_${idx}`);
      if (chosen === q.a) {
        document.getElementById(`lqa${uid}_${idx}_${chosen}`).style.background = 'rgba(34,197,94,.3)';
        document.getElementById(`lqa${uid}_${idx}_${chosen}`).style.borderColor = '#22c55e';
        if (fb) fb.innerHTML = '<span style="color:#4ade80;font-weight:700">✅ Doğru! +10 XP</span>';
        score++; gainXP(10, 'Quiz sorusu doğru'); AudioEngine.correct();
      } else {
        document.getElementById(`lqa${uid}_${idx}_${chosen}`).style.background = 'rgba(239,68,68,.2)';
        document.getElementById(`lqa${uid}_${idx}_${chosen}`).style.borderColor = '#ef4444';
        const correctEl = document.getElementById(`lqa${uid}_${idx}_${q.a}`);
        if (correctEl) correctEl.style.background = 'rgba(34,197,94,.25)';
        if (fb) fb.innerHTML = `<span style="color:#fca5a5">❌ Yanlış. Doğru: <b>${q.opts[q.a]}</b></span>`;
        AudioEngine.wrong();
      }

      current++;
      setTimeout(() => {
        if (current < questions.length) {
          renderQ();
        } else {
          // Sonuç ekranı
          const pct = Math.round((score / questions.length) * 100);
          const stars = pct === 100 ? '⭐⭐⭐' : pct >= 60 ? '⭐⭐' : '⭐';
          const msg = pct === 100 ? '🏆 Mükemmel! Konuya hâkimsin!' : pct >= 60 ? '👍 İyi iş! Biraz daha çalışabilirsin.' : '📖 Dersi tekrar oku ve tekrar dene!';
          addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:16px;border-radius:12px;text-align:center;border-top:3px solid ${unit.color}">
            <p style="font-size:2.5rem;margin:6px 0">${stars}</p>
            <p style="font-weight:800;color:${unit.color};font-size:1.1rem">${unit.title} — Sonuç</p>
            <p style="font-size:1.8rem;font-weight:800;color:var(--acc);margin:10px 0">${score}/${questions.length}</p>
            <p style="font-size:.85rem;color:var(--txt);margin-bottom:12px">${msg}</p>
            <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap">
              <button onclick="startLessonQuiz('${unitId}')" style="padding:8px 16px;background:rgba(59,130,246,.2);border:1px solid var(--acc);border-radius:8px;color:var(--acc);font-weight:700;cursor:pointer;font-size:.82rem">🔄 Tekrar Dene</button>
              <button onclick="showLesson('')" style="padding:8px 16px;background:rgba(16,185,129,.15);border:1px solid #10b981;border-radius:8px;color:#4ade80;font-weight:700;cursor:pointer;font-size:.82rem">📚 Başka Ders</button>
            </div>
          </div>`);
          gainXP(pct === 100 ? 30 : score * 5, 'Quiz tamamladı');
          if (pct === 100) triggerConfetti();
          AudioEngine.levelUp();
        }
      }, 1200);
    };
  }

  renderQ();
}

function showLesson(unitId) {
  if (!unitId) {
    const btns = LESSON_DATA.map(u =>
      `<button onclick="qCmd('/ders ${u.id}')" style="display:block;width:100%;margin:4px 0;padding:12px;background:linear-gradient(135deg,rgba(59,130,246,.1),rgba(139,92,246,.1));border:1px solid var(--acc);border-radius:10px;color:var(--txt);cursor:pointer;font-weight:700;text-align:left">${u.title}</button>`
    ).join('');
    addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="font-weight:700;color:var(--acc);margin-bottom:10px">📚 Yapay Zeka Dersleri</p>${btns}</div>`);
    return;
  }
  const unit = LESSON_DATA.find(u => u.id === unitId.trim().toLowerCase());
  if (!unit) { showLesson(''); return; }

  Memory.addMessage('bot', `[SİSTEM BİLGİSİ] Kullanıcı "${unit.title}" dersini görüntülüyor.`);
  Memory.remember(`Öğrenci "${unit.title}" dersini çalıştı.`);

  const uid = 'ls' + Date.now();
  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:16px;border-radius:12px;border-left:4px solid ${unit.color}">
    <p style="font-weight:800;color:${unit.color};font-size:1.05rem;margin-bottom:10px">${unit.title}</p>
    <div style="font-size:.87rem;line-height:1.7;color:var(--txt)">${unit.content}</div>
    <div style="margin-top:14px;padding-top:12px;border-top:1px solid var(--bdr)">
      <p style="font-size:.78rem;color:#fde047;font-weight:700;margin-bottom:8px">🧪 Mini Sınav:</p>
      <p style="font-weight:700;margin-bottom:8px;font-size:.9rem">${unit.quiz.q}</p>
      ${unit.quiz.opts.map((o, i) => `<button onclick="lsAns_${uid}(${i})" style="display:block;width:100%;margin:3px 0;padding:9px;background:rgba(255,255,255,.04);border:1px solid var(--bdr);border-radius:8px;color:var(--txt);cursor:pointer;text-align:left;font-size:.85rem" id="lsb${uid}_${i}">${o}</button>`).join('')}
      <p id="lsf${uid}" style="font-size:.82rem;margin-top:8px;min-height:16px"></p>
      <div id="lsq${uid}"></div>
    </div>
  </div>`);
  gainXP(5, 'Ders tamamladın'); AudioEngine.click();
  window[`lsAns_${uid}`] = function(i) {
    document.querySelectorAll(`[id^="lsb${uid}_"]`).forEach(b => b.disabled = true);
    const fb = document.getElementById(`lsf${uid}`);
    if (i === unit.quiz.a) {
      document.getElementById(`lsb${uid}_${i}`).style.background = 'rgba(34,197,94,.25)';
      document.getElementById(`lsb${uid}_${i}`).style.borderColor = '#22c55e';
      if (fb) fb.innerHTML = '<span style="color:#4ade80;font-weight:700">✅ Doğru! Harika iş! +10 XP</span>';
      gainXP(10, 'Ders sorusu doğru'); AudioEngine.correct(); triggerConfetti();
    } else {
      document.getElementById(`lsb${uid}_${i}`).style.background = 'rgba(239,68,68,.2)';
      document.getElementById(`lsb${uid}_${i}`).style.borderColor = '#ef4444';
      document.getElementById(`lsb${uid}_${unit.quiz.a}`).style.background = 'rgba(34,197,94,.25)';
      if (fb) fb.innerHTML = `<span style="color:#fca5a5">❌ Yanlış. Doğru: <b>${unit.quiz.opts[unit.quiz.a]}</b></span>`;
      AudioEngine.wrong();
    }
  };
}

registerPlugin({ command: '/ders', icon: '📚', description: 'YZ Ders Modülü', needsArg: true, run: ctx => showLesson(ctx.args) });

// ===== PROGRESS REPORT =====
function showReport() {
  if (!userProfile) { addBotMsg('❌ Önce giriş yapmalısın!'); return; }
  const lvl = LEVELS[userProfile.level];
  const nxt = LEVELS[userProfile.level + 1];
  const pct = nxt ? Math.round((userProfile.xp - lvl.minXP) / (nxt.minXP - lvl.minXP) * 100) : 100;
  const bar = (p, color) => {
    const filled = Math.round(p / 10);
    return `<span style="color:${color}">${'█'.repeat(filled)}${'░'.repeat(10 - filled)}</span> ${p}%`;
  };
  const topBadges = BADGE_DEFS.filter(b => earnedBadges.includes(b.id)).map(b => b.icon).join(' ') || 'Henüz yok';
  const questDone = DAILY_QUESTS.filter(q => (userProfile.questsToday?.[q.id] || 0) >= q.target).length;

  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:16px;border-radius:12px">
    <p style="font-weight:800;color:var(--acc);font-size:1.05rem;margin-bottom:12px">📊 İLERLEME RAPORUN</p>
    <div style="font-size:.82rem;line-height:2">
      <b style="color:var(--sub)">👤 Profil</b><br>
      • Ad: <b>${userProfile.name}</b> | Seviye: <b>${lvl.icon} Lv.${userProfile.level + 1} ${lvl.name}</b><br>
      • Streak: <b>🔥 ${userProfile.streak || 0} gün</b><br><br>
      <b style="color:var(--sub)">⭐ XP Durumu</b><br>
      ${bar(pct, '#3b82f6')} (${userProfile.xp} / ${nxt ? nxt.minXP : 'MAX'} XP)<br><br>
      <b style="color:var(--sub)">📈 İstatistikler</b><br>
      • 💬 Mesaj: <b>${stats.msg}</b> | 🎮 Oyun: <b>${stats.games}</b> | ❤️ Tepki: <b>${stats.react}</b><br>
      • 🧠 Öğretilen kural: <b>${learnedRaw.length}</b><br><br>
      <b style="color:var(--sub)">📋 Günlük Görevler</b><br>
      ${bar(Math.round(questDone / DAILY_QUESTS.length * 100), '#10b981')} (${questDone}/${DAILY_QUESTS.length} tamamlandı)<br><br>
      <b style="color:var(--sub)">🏆 Kazanılan Rozetler</b><br>
      ${topBadges} — <b>${earnedBadges.length}/${BADGE_DEFS.length}</b> rozet
    </div>
  </div>`);
  gainXP(2, 'Rapor görüntülendi'); AudioEngine.click();
}
registerPlugin({ command: '/rapor', icon: '📊', description: 'İlerleme raporun', needsArg: false, run: () => showReport() });

// ===== MATEMATİK SORUSU =====
function showMathProblem() {
  const levels = [
    { q: (a,b) => `${a} + ${b} = ?`, ans: (a,b) => a+b, gen: () => [rnd(10,99), rnd(10,99)], tag:'Toplama' },
    { q: (a,b) => `${a} - ${b} = ?`, ans: (a,b) => a-b, gen: () => { const a=rnd(20,99); return [a, rnd(1,a)]; }, tag:'Çıkarma' },
    { q: (a,b) => `${a} × ${b} = ?`, ans: (a,b) => a*b, gen: () => [rnd(2,12), rnd(2,12)], tag:'Çarpma' },
    { q: (a,b) => `${a*b} ÷ ${b} = ?`, ans: (a,b) => a, gen: () => [rnd(2,12), rnd(2,9)], tag:'Bölme' },
  ];
  function rnd(min, max) { return Math.floor(Math.random()*(max-min+1))+min; }
  const lv = levels[Math.floor(Math.random()*levels.length)];
  const [a, b] = lv.gen();
  const answer = lv.ans(a, b);
  const uid = 'mth' + Date.now();
  const fakes = new Set([answer]);
  while (fakes.size < 4) fakes.add(answer + rnd(-5, 5));
  const opts = [...fakes].sort(() => Math.random()-0.5);

  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <p style="font-size:.72rem;color:var(--sub);text-align:center">${lv.tag}</p>
    <p style="font-size:2rem;font-weight:800;color:var(--acc);text-align:center;padding:14px 0">${lv.q(a,b)}</p>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px">
      ${opts.map(o => `<button onclick="mthAns_${uid}(${o},${answer})" style="padding:12px;background:rgba(255,255,255,.06);border:1px solid var(--bdr);border-radius:8px;color:var(--txt);cursor:pointer;font-size:1rem;font-weight:700" id="mb${uid}_${o}">${o}</button>`).join('')}
    </div>
    <p id="mf${uid}" style="text-align:center;font-size:.82rem;margin-top:8px;min-height:16px"></p>
  </div>`);
  gainXP(1); AudioEngine.click();

  window[`mthAns_${uid}`] = function(val, ans) {
    document.querySelectorAll(`[id^="mb${uid}_"]`).forEach(b => b.disabled = true);
    const fb = document.getElementById(`mf${uid}`);
    if (val === ans) {
      document.getElementById(`mb${uid}_${val}`).style.background = 'rgba(34,197,94,.3)';
      if (fb) fb.innerHTML = '<span style="color:#4ade80;font-weight:700">✅ Doğru! +5 XP</span>';
      gainXP(5, 'Matematik sorusu doğru'); AudioEngine.correct();
    } else {
      document.getElementById(`mb${uid}_${val}`).style.background = 'rgba(239,68,68,.2)';
      document.getElementById(`mb${uid}_${ans}`).style.background = 'rgba(34,197,94,.3)';
      if (fb) fb.innerHTML = `<span style="color:#fca5a5">❌ Yanlış! Cevap: <b>${ans}</b></span>`;
      AudioEngine.wrong();
    }
  };
}
registerPlugin({ command: '/matematik', icon: '🔢', description: 'Rastgele matematik sorusu', needsArg: false, run: () => showMathProblem() });

// ===== RENK BİLGİSİ =====
function showColor(name) {
  const colors = {
    'kırmızı': { hex:'#ef4444', rgb:'239,68,68', desc:'Sıcak renk. Tehlike, enerji, tutku.' },
    'mavi': { hex:'#3b82f6', rgb:'59,130,246', desc:'Soğuk renk. Güven, huzur, gökyüzü.' },
    'sarı': { hex:'#fde047', rgb:'253,224,71', desc:'Sıcak renk. Neşe, güneş, dikkat.' },
    'yeşil': { hex:'#4ade80', rgb:'74,222,128', desc:'Soğuk renk. Doğa, sağlık, büyüme.' },
    'turuncu': { hex:'#f97316', rgb:'249,115,22', desc:'Sıcak renk. Yaratıcılık, eğlence.' },
    'mor': { hex:'#a855f7', rgb:'168,85,247', desc:'Soğuk renk. Gizemlilik, yaratıcılık.' },
    'siyah': { hex:'#0f172a', rgb:'15,23,42', desc:'Tüm renklerin yokluğu. Güç, şıklık.' },
    'beyaz': { hex:'#f1f5f9', rgb:'241,245,249', desc:'Tüm renklerin birleşimi. Saf, temiz.' },
  };
  const c = colors[name?.toLowerCase()?.trim()];
  if (!c) {
    addBotMsg(`🎨 Mevcut renkler: ${Object.keys(colors).join(', ')}<br>Kullanım: <b>/renk kırmızı</b>`);
    return;
  }
  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <div style="width:60px;height:60px;border-radius:12px;background:${c.hex};margin:0 auto 10px;border:2px solid rgba(255,255,255,.2)"></div>
    <p style="font-weight:700;color:${c.hex};text-align:center;font-size:1.1rem">${name.charAt(0).toUpperCase()+name.slice(1)}</p>
    <p style="text-align:center;font-size:.82rem;color:var(--sub);margin:6px 0">HEX: <b style="color:var(--txt)">${c.hex}</b> | RGB: <b style="color:var(--txt)">${c.rgb}</b></p>
    <p style="font-size:.85rem;color:var(--txt);text-align:center">${c.desc}</p>
  </div>`);
  gainXP(2); AudioEngine.click();
}
registerPlugin({ command: '/renk', icon: '🎨', description: 'Renk bilgisi göster', needsArg: true, run: ctx => showColor(ctx.args) });

// ===== TARİHTE BUGÜN =====
const TODAY_IN_HISTORY = [
  ['1453','İstanbul, Osmanlı tarafından fethedildi 🏰'],
  ['1923','Türkiye Cumhuriyeti kuruldu 🇹🇷'],
  ['1969','Armstrong Ay\'a ilk adımı attı 🌙'],
  ['1903','Wright kardeşler ilk uçuşu gerçekleştirdi ✈️'],
  ['1879','Edison ampulü icat etti 💡'],
  ['1928','Penisilin keşfedildi 🧪'],
  ['1998','Google kuruldu 🔍'],
  ['2001','Wikipedia açıldı 📖'],
  ['1687','Newton yer çekimi yasasını yayımladı 🍎'],
  ['2007','İlk iPhone tanıtıldı 📱'],
];
function showTodayHistory() {
  const item = TODAY_IN_HISTORY[Math.floor(Math.random() * TODAY_IN_HISTORY.length)];
  const now = new Date();
  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <p style="font-weight:700;color:#fde047;margin-bottom:8px">📅 TARİHTE BUGÜN</p>
    <p style="font-size:.78rem;color:var(--sub)">${now.toLocaleDateString('tr-TR', {day:'numeric', month:'long'})}</p>
    <p style="font-size:1rem;margin:10px 0;line-height:1.6"><b style="color:var(--acc)">${item[0]}</b> — ${item[1]}</p>
  </div>`, true);
  gainXP(2); AudioEngine.click();
}
registerPlugin({ command: '/tarih', icon: '📅', description: 'Tarihte bugün', needsArg: false, run: () => showTodayHistory() });

// ===== WEB AUDIO ENGINE =====
const AudioEngine = {
  ctx: null,
  enabled: Storage.get('bot_sound', true),

  init() {
    if (!this.ctx) {
      try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
    }
  },

  _play(notes, type = 'sine') {
    if (!this.enabled || !notes?.length) return;
    this.init();
    if (!this.ctx) return;
    let t = this.ctx.currentTime;
    notes.forEach(([freq, dur, vol = 0.3]) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain); gain.connect(this.ctx.destination);
      osc.type = type;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(vol, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.start(t); osc.stop(t + dur);
      t += dur * 0.85;
    });
  },

  correct() { this._play([[440,0.08],[660,0.12]], 'square'); },
  wrong()   { this._play([[280,0.06],[220,0.1]], 'sawtooth'); },
  click()   { this._play([[600,0.04,0.15]], 'sine'); },
  levelUp() { this._play([[261,0.1],[329,0.1],[392,0.1],[523,0.25]], 'sine'); },
  badge()   { this._play([[523,0.08],[659,0.08],[784,0.15]], 'triangle'); },

  toggle() {
    this.enabled = !this.enabled;
    Storage.set('bot_sound', this.enabled);
    const btn = document.getElementById('btnAudioToggle');
    if (btn) btn.textContent = this.enabled ? '🔊' : '🔇';
    showToast(this.enabled ? '🔊' : '🔇', this.enabled ? 'Ses Açık' : 'Ses Kapalı', '', '');
  }
};


// ===== DAILY FACTS =====
const DAILY_FACTS = [
  '🧪 Su, bilinen tek madde: katı, sıvı ve gaz halinde doğal olarak bulunur!',
  '🌋 Dünya üzerinde her gün yaklaşık 50 deprem meydana gelir.',
  '🌊 Okyanusların %95\'i henüz keşfedilmedi!',
  '🧮 Sıfır sayısı ilk olarak Hintliler tarafından kullanılmıştır.',
  '🌈 Gökkuşağı aslında tam bir dairedir!',
  '💡 Edison ampulü icat etmeden önce 1000\'den fazla deneme yaptı.',
  '🦈 Köpekbalıkları dinozorlardan daha eskidir — 400 milyon yıllık!',
];
function showDailyFact() {
  const el = document.getElementById('dailyFact'); if (!el) return;
  const idx = Math.floor(new Date().getDate() * 7 + new Date().getMonth()) % DAILY_FACTS.length;
  el.innerHTML = '<b>💡 Günün Bilgisi:</b> ' + DAILY_FACTS[idx];
}

// ===== INIT =====
function initAfterUser() {
  checkStreak();
  updateStats(); loadTheme(); updateXPBar(); renderBadges(); showDailyFact();
  renderUserCard(); renderModeButtons(); renderQuests();
}

(function initApp() {
  chatbox = document.getElementById('chatbox');
  userInput = document.getElementById('userInput');
  typing = document.getElementById('typing');
  botStatusEl = document.getElementById('botStatus');

  // Keyboard
  userInput.addEventListener('keypress', e => { if (e.key === 'Enter') sendMessage(); });
  document.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); openCmdPalette(); }
    if (e.key === 'Escape') { closeCmdPalette(); closeSettings(); }
  });
  const cmdInput = document.getElementById('cmdInput');
  if (cmdInput) {
    cmdInput.addEventListener('input', e => renderCmdList(e.target.value));
    cmdInput.addEventListener('keydown', e => { 
      if (e.key === 'Escape') closeCmdPalette(); 
      if (e.key === 'Enter') { 
        const items = document.querySelectorAll('.cmd-item'); 
        if (items.length) items[0].click(); 
      } 
    });
  }

  // Onboarding or welcome
  if (!userProfile) {
    showOnboarding();
  } else {
    initAfterUser();
    const greeting = new Date().getHours() < 12 ? 'Günaydın' : new Date().getHours() < 18 ? 'İyi günler' : 'İyi akşamlar';
    setTimeout(() => addBotMsg(greeting + ' <b>' + userProfile.name + '</b>! 🎉 v10.0 PRO hazır!<br>🧠 AI · 🎮 Oyunlar · 📊 Quiz · 🎭 Modlar<br><b>Ctrl+K</b> komut paleti!', true), 600);
  }
})();
// ============================================
// MEGA Asistan Bot v9.0 PRO — Part 3
// Games + Tools (Wordle, Quiz, Pet, etc.)
// ============================================

// ===== WORDLE =====
const WORDLE_WORDS=['bilim','kitap','robot','yazma','okuma','zaman','bulut','deniz','nehir','araba','kalem','meyve','hayal','hafta','orman','insan','sanat','evren','duvar','kural','yürek','kıyam','çiçek','toprak','yıldız'].filter(w=>w.length===5);
function startWordle(){
  let uid='w'+Date.now();
  let answer=WORDLE_WORDS[Math.floor(Math.random()*WORDLE_WORDS.length)].toUpperCase();
  let maxG=6,row=0,col=0,chars=[],active=true;
  let grid='<div class="wordle-grid" id="wg'+uid+'">';
  for(let r=0;r<maxG;r++){grid+='<div class="wordle-row">';for(let c=0;c<5;c++)grid+='<div class="wordle-cell" id="wc'+uid+'_'+r+'_'+c+'"></div>';grid+='</div>';}
  grid+='</div>';
  let kb='ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ'.split('');
  let kbH='<div class="wordle-kb" id="wkb'+uid+'">';
  kb.forEach(k=>{kbH+='<button class="wordle-key" data-k="'+k+'" onclick="wKey'+uid+"('"+k+"')"+'">' +k+'</button>';});
  kbH+='<button class="wordle-key" style="min-width:50px;background:#4ade80;color:#0f172a" onclick="wKey'+uid+"('ENTER')"+'">GİR</button>';
  kbH+='<button class="wordle-key" style="min-width:50px;background:#ef4444" onclick="wKey'+uid+"('DEL')"+'">⌫</button></div>';
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="text-align:center;font-weight:700;color:#4ade80;margin-bottom:8px">🟩 WORDLE</p>'+grid+kbH+'<p id="wm'+uid+'" style="text-align:center;font-size:.8rem;color:var(--sub);margin-top:8px">'+maxG+' hakkın var</p></div>');
  stats.games++;updateStats();saveStats();gainXP(5,'Wordle başlattın');updateQuest('games');
  window['wKey'+uid]=function(k){
    if(!active)return;
    if(k==='DEL'){if(col>0){col--;document.getElementById('wc'+uid+'_'+row+'_'+col).textContent='';chars.pop();}return;}
    if(k==='ENTER'){
      if(chars.length!==5){document.getElementById('wm'+uid).textContent='5 harf gir!';return;}
      let g=chars.join(''),ans=[...answer],res=Array(5).fill('absent');
      for(let i=0;i<5;i++){if(g[i]===ans[i]){res[i]='correct';ans[i]=null;}}
      for(let i=0;i<5;i++){if(res[i]==='correct')continue;let idx=ans.indexOf(g[i]);if(idx!==-1){res[i]='present';ans[idx]=null;}}
      for(let i=0;i<5;i++){let cell=document.getElementById('wc'+uid+'_'+row+'_'+i);cell.className='wordle-cell '+res[i];
        let kb=document.querySelector('#wkb'+uid+' [data-k="'+g[i]+'"]');
        if(kb){if(res[i]==='correct')kb.className='wordle-key k-correct';else if(res[i]==='present'&&!kb.classList.contains('k-correct'))kb.className='wordle-key k-present';else if(!kb.classList.contains('k-correct')&&!kb.classList.contains('k-present'))kb.className='wordle-key k-absent';}
      }
      if(g===answer){active=false;document.getElementById('wm'+uid).innerHTML='<span style="color:#4ade80;font-weight:700">🏆 TEBRİKLER! '+answer+'</span>';triggerConfetti();gainXP(20,'Wordle kazandın!');}
      else{row++;col=0;chars=[];if(row>=maxG){active=false;document.getElementById('wm'+uid).innerHTML='<span style="color:#ef4444">Cevap: <b>'+answer+'</b></span>';}
      else document.getElementById('wm'+uid).textContent=(maxG-row)+' hakkın kaldı';}
      return;
    }
    if(col<5){document.getElementById('wc'+uid+'_'+row+'_'+col).textContent=k;chars.push(k);col++;}
  };
}

// ===== PET =====
let petData=JSON.parse(localStorage.getItem('bot_pet')||'null');
function showPet(){
  if(!petData){petData={type:'🐱',name:'Minnoş',hunger:80,happy:80,energy:80,level:1,xp:0,born:Date.now()};localStorage.setItem('bot_pet',JSON.stringify(petData));}
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><div class="pet-container"><p style="font-weight:700;color:var(--acc)">' +petData.name+' — Lv.'+petData.level+'</p><div class="pet-display">'+petData.type+'</div><div class="pet-bars"><div class="pet-bar-row"><span class="label">🍖 Açlık</span><div class="pet-bar-bg"><div class="pet-bar-fill" style="width:'+petData.hunger+'%;background:#ef4444"></div></div><span>'+Math.round(petData.hunger)+'%</span></div><div class="pet-bar-row"><span class="label">😊 Mutluluk</span><div class="pet-bar-bg"><div class="pet-bar-fill" style="width:'+petData.happy+'%;background:#fde047"></div></div><span>'+Math.round(petData.happy)+'%</span></div><div class="pet-bar-row"><span class="label">⚡ Enerji</span><div class="pet-bar-bg"><div class="pet-bar-fill" style="width:'+petData.energy+'%;background:#4ade80"></div></div><span>'+Math.round(petData.energy)+'%</span></div></div><div class="pet-actions"><button class="pet-btn" style="background:#ef4444" onclick="feedPet()">🍖 Besle</button><button class="pet-btn" style="background:#fde047;color:#0f172a" onclick="playPet()">🎾 Oyna</button><button class="pet-btn" style="background:#4ade80;color:#0f172a" onclick="sleepPet()">😴 Uyut</button></div></div></div>');
}
function feedPet(){if(!petData)return;petData.hunger=Math.min(100,petData.hunger+20);petData.xp+=5;savePet();showToast('🍖','Beslendi!','+20 açlık','success');gainXP(2);}
function playPet(){if(!petData)return;petData.happy=Math.min(100,petData.happy+25);petData.energy=Math.max(0,petData.energy-15);petData.xp+=8;savePet();showToast('🎾','Oynandı!','+25 mutluluk','success');gainXP(3);}
function sleepPet(){if(!petData)return;petData.energy=Math.min(100,petData.energy+30);petData.xp+=3;savePet();showToast('😴','Uyudu!','+30 enerji','success');}
function savePet(){localStorage.setItem('bot_pet',JSON.stringify(petData));}

// ===== ADVENTURE =====
function startAdventure(){
  const stories=[
    {title:'🚀 Uzay Macerası',steps:[
      {text:'Bilinmeyen gezegene yaklaşıyorsun.',opts:['İniş yap','Sinyali takip et'],next:[1,2]},
      {text:'Parlayan kristaller buldun!',opts:['Kristali al','Mağaraya gir'],next:[3,4]},
      {text:'Eski uzay istasyonu buldun!',opts:['Gir','Geri dön'],next:[5,0]},
      {text:'Kristal süper güç verdi! 🌟',opts:['🏆 Tekrar'],next:[-1]},
      {text:'Hazineyi buldun! 💎',opts:['🏆 Tekrar'],next:[-1]},
      {text:'Harita buldun! 🗺️',opts:['🏆 Tekrar'],next:[-1]},
    ]},
  ];
  const story=stories[Math.floor(Math.random()*stories.length)];let step=0;
  window._advStep=function(n){if(n===-1){startAdventure();return;}step=n;renderStep();};
  function renderStep(){
    const s=story.steps[step];
    const btns=s.opts.map((o,i)=>'<button onclick="_advStep('+s.next[i]+')" style="display:block;width:100%;margin:4px 0;padding:10px;background:linear-gradient(135deg,rgba(59,130,246,.2),rgba(139,92,246,.2));border:1px solid var(--acc);border-radius:10px;color:var(--txt);cursor:pointer;font-weight:600">'+o+'</button>').join('');
    addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="font-weight:700;color:var(--acc);margin-bottom:8px">'+story.title+'</p><p style="margin-bottom:10px;line-height:1.6">'+s.text+'</p>'+btns+'</div>');
    if(s.next[0]===-1){gainXP(15,'Macera tamamladın!');triggerConfetti();}
  }
  renderStep();stats.games++;updateStats();saveStats();gainXP(5);updateQuest('games');
}

// ===== QUIZ =====
const QUIZ_CATS={
  bilim:{name:'🔬 Bilim',qs:[{q:'Suyun formülü?',opts:['H2O','CO2','NaCl','O2'],a:0},{q:'Işık hızı kaç km/s?',opts:['300.000','150.000','1M','50.000'],a:0},{q:'En yakın gezegen?',opts:['Merkür','Venüs','Mars','Dünya'],a:0}]},
  tarih:{name:'📜 Tarih',qs:[{q:'İstanbul fethi?',opts:['1453','1071','1299','1923'],a:0},{q:'Cumhuriyet?',opts:['1923','1920','1919','1938'],a:0},{q:'Matbaa kim?',opts:['Gutenberg','Edison','Newton','Tesla'],a:0}]},
  coğrafya:{name:'🌍 Coğrafya',qs:[{q:'En büyük okyanus?',opts:['Pasifik','Atlantik','Hint','Arktik'],a:0},{q:'Türkiye en uzun nehir?',opts:['Kızılırmak','Fırat','Dicle','Sakarya'],a:0},{q:'En soğuk kıta?',opts:['Antarktika','Avrupa','Asya','K.Amerika'],a:0}]},
  genel:{name:'🧠 Genel',qs:[{q:'Olimpiyatlar kaç yılda?',opts:['4','2','3','5'],a:0},{q:'Mona Lisa kim?',opts:['Da Vinci','Picasso','Van Gogh','Monet'],a:0},{q:'Pi sayısı?',opts:['3.14','2.71','1.61','3.41'],a:0}]},
};
function showQuizMenu(){
  const cats=Object.keys(QUIZ_CATS);
  const btns=cats.map(c=>'<button onclick="qCmd(\'/quiz '+c+'\')" style="display:block;width:100%;margin:4px 0;padding:12px;background:linear-gradient(135deg,rgba(59,130,246,.15),rgba(168,85,247,.15));border:1px solid var(--acc);border-radius:10px;color:var(--txt);cursor:pointer;font-weight:700;font-size:.92rem">'+QUIZ_CATS[c].name+'</button>').join('');
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="font-weight:700;color:var(--acc);margin-bottom:10px">📊 Kategori Seç:</p>'+btns+'</div>');
}
function startQuiz(cat){
  cat=cat.toLowerCase();if(!QUIZ_CATS[cat]){addBotMsg('❌ /quiz yaz.');return;}
  let qs=[...QUIZ_CATS[cat].qs].sort(()=>Math.random()-.5),qi=0,score=0,uid='qz'+Date.now();
  function showQ(){
    if(qi>=qs.length){addBotMsg('📊 <b>Tamamlandı!</b> Puan: <b style="color:#4ade80">'+score+'/'+qs.length+'</b>');gainXP(score*5);if(score>=2)triggerConfetti();return;}
    const q=qs[qi],opts=q.opts.map((o,i)=>'<button onclick="window._qa'+uid+'('+i+')" style="display:block;width:100%;margin:3px 0;padding:10px;background:rgba(255,255,255,.04);border:1px solid var(--bdr);border-radius:8px;color:var(--txt);cursor:pointer;font-size:.88rem;text-align:left">'+o+'</button>').join('');
    addBotMsg('<div style="background:rgba(0,0,0,.35);padding:12px;border-radius:10px"><p style="font-size:.75rem;color:var(--sub)">Soru '+(qi+1)+'/'+qs.length+'</p><p style="font-weight:700;margin-bottom:8px">'+q.q+'</p>'+opts+'</div>');
  }
  window['_qa'+uid]=function(i){if(i===qs[qi].a){score++;showToast('✅','Doğru!','','success');}else showToast('❌','Yanlış!','Doğru: '+qs[qi].opts[qs[qi].a],'');qi++;showQ();};
  showQ();stats.games++;updateStats();saveStats();updateQuest('games');
}

// ===== FLASHCARD =====
const FLASH_SETS=[
  {cat:'🇬🇧 İngilizce',cards:[{f:'Hello',b:'Merhaba'},{f:'Book',b:'Kitap'},{f:'Water',b:'Su'},{f:'Science',b:'Bilim'}]},
  {cat:'🔬 Bilim',cards:[{f:'Fotosentez',b:'Bitkilerin ışıkla besin üretmesi'},{f:'Atom',b:'Maddenin en küçük yapı taşı'}]},
  {cat:'🌍 Başkentler',cards:[{f:'Türkiye',b:'Ankara'},{f:'Fransa',b:'Paris'},{f:'Japonya',b:'Tokyo'}]},
];
function showFlashcard(){
  const set=FLASH_SETS[Math.floor(Math.random()*FLASH_SETS.length)];let ci=0,uid='fc'+Date.now();
  function renderCard(){
    const c=set.cards[ci];
    addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="font-weight:700;color:var(--acc)">' +set.cat+' ('+(ci+1)+'/'+set.cards.length+')</p><div class="flashcard" id="fc'+uid+'" onclick="this.classList.toggle(\'flipped\')"><div class="flashcard-inner"><div class="flashcard-front"><p style="font-size:.75rem;color:var(--sub)">SORU</p><p style="font-size:1.4rem;font-weight:700;margin-top:8px">'+c.f+'</p></div><div class="flashcard-back"><p style="font-size:.75rem;color:var(--sub)">CEVAP</p><p style="font-size:1.2rem;font-weight:700;margin-top:8px;color:#4ade80">'+c.b+'</p></div></div></div><div style="text-align:center;margin-top:8px"><button onclick="_fcN'+uid+'()" style="padding:8px 20px;background:var(--acc);color:#fff;border:none;border-radius:8px;cursor:pointer;font-weight:700">Sonraki →</button></div></div>');
  }
  window['_fcN'+uid]=function(){ci=(ci+1)%set.cards.length;renderCard();gainXP(1);};
  renderCard();gainXP(3);
}

// ===== FORMULA =====
function showFormula(topic){
  const formulas={alan:{t:'📐 Alan',f:'Kare: a² | Dikdörtgen: a×b | Üçgen: (a×h)/2 | Daire: π×r²'},hız:{t:'🏎️ Hız',f:'v = s/t | s = v×t | t = s/v'},ohm:{t:'⚡ Ohm',f:'V = I×R | R = V/I | I = V/R'},};
  if(!topic){addBotMsg('🔢 Mevcut: alan, hız, ohm. Kullanım: <b>/formül alan</b>');return;}
  const key=Object.keys(formulas).find(k=>topic.toLowerCase().includes(k));
  if(key){const f=formulas[key];addBotMsg('<div style="background:rgba(0,0,0,.35);padding:14px;border-radius:12px"><p style="font-weight:700;color:var(--acc)">'+f.t+'</p><p style="font-family:monospace;color:#4ade80;margin-top:8px">'+f.f+'</p></div>');gainXP(3);}
  else addBotMsg('❌ Bulunamadı. <b>/formül</b> yaz.');
}

// ===== POMODORO =====
let pomoState={active:false,paused:false,timeLeft:0,isBreak:false,cycles:0,interval:null};
function startPomodoro(){
  if(pomoState.active){addBotMsg('⏱️ Zaten aktif!');return;}
  pomoState={active:true,paused:false,timeLeft:25*60,isBreak:false,cycles:0,interval:null};
  const uid='pm'+Date.now();
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><div class="pomo-display"><p style="font-weight:700;color:#a855f7">🍅 POMODORO</p><div class="pomo-timer" id="pt'+uid+'">25:00</div><div class="pomo-status" id="ps'+uid+'">🎯 Çalışma</div><div class="pomo-btns"><button class="pomo-btn" style="background:#ef4444" onclick="stopPomo()">⏹</button><button class="pomo-btn" style="background:#fde047;color:#0f172a" onclick="pausePomo()">⏸</button></div></div></div>');
  pomoState.interval=setInterval(()=>{
    if(pomoState.paused)return;pomoState.timeLeft--;
    const el=document.getElementById('pt'+uid);if(el)el.textContent=Math.floor(pomoState.timeLeft/60).toString().padStart(2,'0')+':'+(pomoState.timeLeft%60).toString().padStart(2,'0');
    if(pomoState.timeLeft<=0){
      if(!pomoState.isBreak){pomoState.cycles++;pomoState.isBreak=true;pomoState.timeLeft=5*60;const ps=document.getElementById('ps'+uid);if(ps)ps.textContent='☕ Mola!';showToast('🍅','Bitti!','Mola yap.','success');triggerConfetti();gainXP(10,'Pomodoro tamamladın');}
      else{pomoState.isBreak=false;pomoState.timeLeft=25*60;const ps=document.getElementById('ps'+uid);if(ps)ps.textContent='🎯 Çalışma';showToast('☕','Mola bitti!','','');}
    }
  },1000);
}
function stopPomo(){if(pomoState.interval)clearInterval(pomoState.interval);pomoState.active=false;showToast('⏹','Durduruldu','','');}
function pausePomo(){pomoState.paused=!pomoState.paused;showToast(pomoState.paused?'⏸':'▶',pomoState.paused?'Duraklatıldı':'Devam','','');}

// ===== NOTES =====
let userNotes=JSON.parse(localStorage.getItem('bot_notes')||'[]');
function handleNotes(cmd){
  if(!cmd||cmd.trim()===''){
    if(!userNotes.length){addBotMsg('📋 Not defteri boş. <b>/not Yarın sınav!</b>');return;}
    let html='📋 <b>Notların ('+userNotes.length+'):</b><br><br>';
    userNotes.forEach((n,i)=>{html+='<div class="note-item"><div class="note-text">'+n.text+'</div><div class="note-date">'+new Date(n.date).toLocaleString('tr-TR')+' · <a href="#" onclick="deleteNote('+i+');return false;" style="color:#fca5a5">Sil</a></div></div>';});
    addBotMsg(html);return;
  }
  userNotes.push({text:cmd,date:Date.now()});localStorage.setItem('bot_notes',JSON.stringify(userNotes));
  addBotMsg('✅ Not kaydedildi: "<b>'+cmd+'</b>" 📋');gainXP(2);
}
function deleteNote(i){userNotes.splice(i,1);localStorage.setItem('bot_notes',JSON.stringify(userNotes));addBotMsg('🗑️ Silindi!');}

// ===== DRAWING =====
function startDrawing(){
  const uid='dr'+Date.now();
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px"><p style="font-weight:700;color:#ec4899;margin-bottom:8px">🎨 Çizim Tahtası</p><div class="draw-toolbar"><input type="color" id="dc'+uid+'" value="#4ade80"><input type="range" id="ds'+uid+'" min="1" max="20" value="3"><button onclick="drClear(\''+uid+'\')">🗑️</button><button onclick="drSave(\''+uid+'\')">💾</button></div><canvas id="drc'+uid+'" width="380" height="250" style="background:#0f172a;border:2px solid #ec4899;border-radius:8px;display:block;width:100%;cursor:crosshair;touch-action:none"></canvas></div>');
  setTimeout(()=>{
    const cv=document.getElementById('drc'+uid);if(!cv)return;
    const ctx=cv.getContext('2d');let drawing=false;
    ctx.lineCap='round';ctx.lineJoin='round';
    function gp(e){const r=cv.getBoundingClientRect();const x=(e.clientX||e.touches[0].clientX)-r.left;const y=(e.clientY||e.touches[0].clientY)-r.top;return{x:x*(cv.width/r.width),y:y*(cv.height/r.height)};}
    function start(e){drawing=true;const p=gp(e);ctx.beginPath();ctx.moveTo(p.x,p.y);}
    function draw(e){if(!drawing)return;const p=gp(e);ctx.strokeStyle=document.getElementById('dc'+uid).value;ctx.lineWidth=document.getElementById('ds'+uid).value;ctx.lineTo(p.x,p.y);ctx.stroke();}
    function stop(){drawing=false;}
    cv.addEventListener('mousedown',start);cv.addEventListener('mousemove',draw);cv.addEventListener('mouseup',stop);cv.addEventListener('mouseleave',stop);
    cv.addEventListener('touchstart',e=>{e.preventDefault();start(e);},{passive:false});cv.addEventListener('touchmove',e=>{e.preventDefault();draw(e);},{passive:false});cv.addEventListener('touchend',stop);
    window.drClear=function(u){document.getElementById('drc'+u).getContext('2d').clearRect(0,0,380,250);};
    window.drSave=function(u){const a=document.createElement('a');a.download='cizim.png';a.href=document.getElementById('drc'+u).toDataURL();a.click();gainXP(5);};
  },300);
  gainXP(3);
}

// ===== TRANSLATE =====
function doTranslate(text){
  if(!text){addBotMsg('❌ Kullanım: <b>/çevir İngilizce merhaba</b>');return;}
  const parts=text.split(' ');const lang=parts[0];const msg=parts.slice(1).join(' ');
  if(!msg){addBotMsg('❌ Metin yaz: <b>/çevir İngilizce günaydın</b>');return;}
  addBotMsg('🌐 Çevriliyor...');
  fetch('https://text.pollinations.ai/openai', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages: [{role:'system', content:'Sadece çeviriyi yaz. "'+msg+'" metnini '+lang+' diline çevir.'}, {role:'user', content:msg+' - '+lang+' çevirisi'}], model: 'openai' })
  }).then(r=>r.json()).then(d=>{let t=d?.choices?.[0]?.message?.content||'';addBotMsg('🌐 <b>'+lang+':</b><br><span style="font-size:1.15rem;color:#4ade80">'+t+'</span>');gainXP(3);})
    .catch(()=>addBotMsg('❌ Çeviri yapılamadı.'));
}

// ===== TEXT ANALYSIS =====
function doTextAnalysis(text){
  if(!text){addBotMsg('❌ Kullanım: <b>/analiz metin</b>');return;}
  const words=text.split(/\s+/).filter(Boolean),chars=text.length,sentences=text.split(/[.!?]+/).filter(Boolean).length;
  let freq={};words.forEach(w=>{const l=w.toLowerCase().replace(/[.,!?]/g,'');freq[l]=(freq[l]||0)+1;});
  const top=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,5).map(([w,c])=>'<b>'+w+'</b> ('+c+'x)').join(', ');
  addBotMsg('📈 <b>Analiz:</b><br>📝 '+chars+' karakter · 📖 '+words.length+' kelime · 📄 '+sentences+' cümle<br>🔤 En sık: '+top);gainXP(3);
}

// ===== CIPHER =====
function doCipher(text){
  if(!text){addBotMsg('❌ <b>/şifrele mesaj</b>');return;}
  let r='';for(let ch of text){let c=ch.charCodeAt(0);if(c>=65&&c<=90)r+=String.fromCharCode(((c-65+3)%26)+65);else if(c>=97&&c<=122)r+=String.fromCharCode(((c-97+3)%26)+97);else r+=ch;}
  addBotMsg('🔐 <b>Şifreli:</b> <b style="color:#f97316;letter-spacing:2px">'+r+'</b><br><span style="font-size:.78rem;color:var(--sub)">Çözmek: <b>/çöz '+r+'</b></span>');gainXP(3);
}
function decodeCipher(text){
  if(!text){addBotMsg('❌ <b>/çöz metin</b>');return;}
  let r='';for(let ch of text){let c=ch.charCodeAt(0);if(c>=65&&c<=90)r+=String.fromCharCode(((c-65-3+26)%26)+65);else if(c>=97&&c<=122)r+=String.fromCharCode(((c-97-3+26)%26)+97);else r+=ch;}
  addBotMsg('🔓 <b>Çözülmüş:</b> <b style="color:#4ade80">'+r+'</b>');
}

// ===== EMOJI GUESS =====
function startEmojiGuess(){
  const puzzles=[{emoji:'🦁👑',answer:'aslan kral',hint:'Disney filmi'},{emoji:'❄️👸',answer:'karlar kraliçesi',hint:'Elsa'},{emoji:'🕷️🦸‍♂️',answer:'örümcek adam',hint:'Süper kahraman'},{emoji:'⚡🧙',answer:'harry potter',hint:'Büyücü'}];
  const p=puzzles[Math.floor(Math.random()*puzzles.length)];
  AppState.proMode='EMOJI_GUESS';AppState.modeState={answer:p.answer,emoji:p.emoji,hint:p.hint,tries:0};
  addBotMsg('<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px;text-align:center"><p style="font-weight:700;color:#fde047">😂 EMOJİ TAHMİN</p><p style="font-size:3rem;margin:12px 0">'+p.emoji+'</p><p style="color:var(--sub);font-size:.85rem">Bu ne?</p><p style="font-size:.75rem;color:var(--sub)">İpucu: '+p.hint+'</p></div>');
  stats.games++;updateStats();saveStats();gainXP(3);updateQuest('games');
}

// ===== GAME MODAL SYSTEM =====

function openGameMenu(){
  if (window.innerWidth <= 768) { const sb = document.querySelector('.sidebar'); if(sb && sb.classList.contains('open')) toggleSidebar(); }
  const ov=document.getElementById('gameOverlay'),bd=document.getElementById('gameBody'),tt=document.getElementById('gameTitle');
  if(!ov)return; tt.textContent='🎮 Oyun Merkezi'; AppState.activeGame=null;
  if(AppState.gameInterval){clearInterval(AppState.gameInterval);AppState.gameInterval=null;} if(AppState.gameRAF){cancelAnimationFrame(AppState.gameRAF);AppState.gameRAF=null;}
  const G=[{id:'snake',i:'🐍',n:'Yılan',d:'Klasik yılan oyunu'},{id:'xox',i:'❌',n:'XOX',d:'Bilgisayara karşı'},{id:'breakout',i:'🧱',n:'Breakout',d:'Tuğla kırma'},{id:'pong',i:'🏓',n:'Pong',d:'Masa tenisi'},{id:'minesweeper',i:'💣',n:'Mayın Tarlası',d:'8×8 mayın avı'},{id:'reaction',i:'🎯',n:'Tepki Hızı',d:'Ne kadar hızlısın?'},{id:'shooting',i:'✈️',n:'Uç Vurma',d:'Uçakları düşür!'},{id:'racing',i:'🏎️',n:'Araba Yarışı',d:'2D sürüş!'},{id:'memory',i:'🃏',n:'Hafıza Kartı',d:'Eşleştirme'},{id:'mathrace',i:'⚡',n:'Matematik',d:'60s yarış'},{id:'sudoku',i:'🔢',n:'Sudoku',d:'4×4 bulmaca'},{id:'timber',i:'🪓',n:'Ağaç Kesme',d:'Dal gelince kaç'}];
  bd.innerHTML='<div class="gmenu-grid">'+G.map(g=>'<div class="gcard" onclick="openGameInModal(\''+g.id+'\')"><div class="gcard-i">'+g.i+'</div><div class="gcard-n">'+g.n+'</div><div class="gcard-d">'+g.d+'</div></div>').join('')+'</div>';
  ov.classList.add('active'); AudioEngine.click();
}
function openGameInModal(gid){
  const bd=document.getElementById('gameBody'),tt=document.getElementById('gameTitle');
  AppState.activeGame=gid; bd.innerHTML=''; stats.games++;updateStats();saveStats();updateQuest('games');
  const M={snake:()=>{tt.textContent='🐍 Yılan';startSnakeGame(bd);},xox:()=>{tt.textContent='❌ XOX';startXoxGame(bd);},breakout:()=>{tt.textContent='🧱 Breakout';startBreakoutGame(bd);},pong:()=>{tt.textContent='🏓 Pong';startPongGame(bd);},minesweeper:()=>{tt.textContent='💣 Mayın Tarlası';startMinesweeperGame(bd);},reaction:()=>{tt.textContent='🎯 Tepki Hızı';startReactionGame(bd);},shooting:()=>{tt.textContent='✈️ Uç Vurma';startShootingGame(bd);},racing:()=>{tt.textContent='🏎️ Araba Yarışı';startRacingGame(bd);},memory:()=>{closeGameModal();startMemoryGame();},mathrace:()=>{closeGameModal();startMathRace();},sudoku:()=>{closeGameModal();startSudoku();},timber:()=>{tt.textContent='🪓 Ağaç Kesme';startTimberGame(bd);}};
  if(M[gid])M[gid](); else bd.innerHTML='<p>Oyun bulunamadı</p>';
  gainXP(5,'Oyun başlattın');
}
function closeGameModal(){
  document.getElementById('gameOverlay').classList.remove('active');
  document.getElementById('gameModal').classList.remove('fullscreen', 'live-code-mode');
  if(AppState.gameInterval){clearInterval(AppState.gameInterval);AppState.gameInterval=null;}
  if(AppState.gameRAF){cancelAnimationFrame(AppState.gameRAF);AppState.gameRAF=null;} AppState.activeGame=null;
}
function toggleGameFullscreen(){document.getElementById('gameModal').classList.toggle('fullscreen');}
function genGame(type,name){openGameMenu();}

// ===== 🪓 TIMBER GAME =====
function startTimberGame(ct){
  ct.innerHTML='<div style="text-align:center"><div id="timbSc" style="font-size:1.5rem;font-weight:bold;margin:10px;color:var(--acc)">Skor: 0</div><canvas id="timbCv" width="300" height="400" style="background:#0f172a;border-radius:8px;box-shadow:0 0 10px rgba(0,0,0,0.5);display:block;margin:0 auto;cursor:pointer;"></canvas><p style="font-size:.72rem;color:var(--sub);margin-top:8px">Ok tuşları veya Sol/Sağ dokun</p></div>';
  const cv=document.getElementById('timbCv'), ctx=cv.getContext('2d'), sd=document.getElementById('timbSc');
  let score=0, over=false, player=0; 
  let br=[-1,-1,0,1,-1,0,1,0]; 
  const getRnd = () => Math.random()<0.5?0:1;
  function draw() {
    ctx.clearRect(0,0,cv.width,cv.height);
    ctx.fillStyle='#78350f'; ctx.fillRect(120,0,60,400);
    for(let i=0;i<6;i++){
      let y = 320-(i*60);
      if(br[i]===0){ ctx.fillStyle='#166534'; ctx.fillRect(20,y+10,100,20); }
      if(br[i]===1){ ctx.fillStyle='#166534'; ctx.fillRect(180,y+10,100,20); }
    }
    ctx.fillStyle='#ea580c';
    if(player===0) ctx.fillRect(70,320,40,50); else ctx.fillRect(190,320,40,50);
    sd.textContent='Skor: '+score;
    if(over) {
      ctx.fillStyle='rgba(0,0,0,0.7)'; ctx.fillRect(0,0,300,400);
      ctx.fillStyle='#ef4444'; ctx.font='bold 28px sans-serif'; ctx.textAlign='center';
      ctx.fillText('OYUN BİTTİ!',150,180);
      ctx.fillStyle='#fff'; ctx.font='14px sans-serif'; ctx.fillText('Tekrar oynamak için dokun',150,220);
    }
  }
  function act(side) {
    if(over){ score=0;player=side;over=false;br=[-1,-1]; for(let i=0;i<6;i++) br.push(Math.random()>0.3?getRnd():-1); draw(); return; }
    player=side; if(br[0]===side){ over=true; draw(); return; } 
    br.shift(); br.push(Math.random()>0.3?getRnd():-1);
    if(br[0]===side) over=true; else score+=5;
    draw();
  }
  draw();
  const kd = e => { if(e.key==='ArrowLeft') act(0); if(e.key==='ArrowRight') act(1); };
  window.addEventListener('keydown', kd);
  cv.addEventListener('mousedown', e => { act((e.clientX - cv.getBoundingClientRect().left)<150?0:1); });
  const intv = setInterval(()=>{ if(!document.getElementById('timbCv')){ window.removeEventListener('keydown',kd); clearInterval(intv); } }, 1000);
}

// ===== 🐍 SNAKE GAME =====
function startSnakeGame(ct){
  const W=400,H=400,GR=20,SZ=W/GR;
  ct.innerHTML='<div class="gbar"><span>Skor: <b id="snkS">0</b></span><span>En İyi: <b id="snkB">'+Storage.get('snake_best',0)+'</b></span></div><canvas class="gcv" id="snkC" width="'+W+'" height="'+H+'" tabindex="0"></canvas><p style="font-size:.72rem;color:var(--sub);margin-top:8px">Ok tuşları / kaydırma ile yön değiştir · Boşluk: tekrar</p>';
  const cv=document.getElementById('snkC'),ctx=cv.getContext('2d'); cv.focus();
  let snake=[{x:10,y:10}],dir={x:1,y:0},ndir={x:1,y:0},food,score=0,alive=true,spd=120,lt=0;
  function pf(){do{food={x:Math.floor(Math.random()*GR),y:Math.floor(Math.random()*GR)};}while(snake.some(s=>s.x===food.x&&s.y===food.y));}
  pf();
  function draw(){
    ctx.fillStyle='#0a1224';ctx.fillRect(0,0,W,H);
    ctx.strokeStyle='rgba(255,255,255,.03)';for(let i=0;i<GR;i++){ctx.beginPath();ctx.moveTo(i*SZ,0);ctx.lineTo(i*SZ,H);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*SZ);ctx.lineTo(W,i*SZ);ctx.stroke();}
    ctx.fillStyle='#ef4444';ctx.shadowColor='#ef4444';ctx.shadowBlur=10;ctx.beginPath();ctx.arc(food.x*SZ+SZ/2,food.y*SZ+SZ/2,SZ/2-2,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
    snake.forEach((s,i)=>{const t=i/snake.length;ctx.fillStyle=i===0?'#4ade80':'hsl('+(140+t*40)+',70%,'+(55-t*20)+'%)';ctx.shadowColor=i===0?'#4ade80':'transparent';ctx.shadowBlur=i===0?8:0;ctx.fillRect(s.x*SZ+1,s.y*SZ+1,SZ-2,SZ-2);});
    ctx.shadowBlur=0;
  }
  function upd(){
    if(!alive)return; dir={...ndir};
    const hd={x:snake[0].x+dir.x,y:snake[0].y+dir.y};
    if(hd.x<0)hd.x=GR-1;if(hd.x>=GR)hd.x=0;if(hd.y<0)hd.y=GR-1;if(hd.y>=GR)hd.y=0;
    if(snake.some(s=>s.x===hd.x&&s.y===hd.y)){gover();return;}
    snake.unshift(hd);
    if(hd.x===food.x&&hd.y===food.y){score++;document.getElementById('snkS').textContent=score;pf();AudioEngine.correct();if(score%5===0&&spd>50)spd-=10;}else snake.pop();
    draw();
  }
  function gover(){
    alive=false;const b=Storage.get('snake_best',0);if(score>b){Storage.set('snake_best',score);document.getElementById('snkB').textContent=score;}
    ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(0,0,W,H);ctx.textAlign='center';ctx.fillStyle='#ef4444';ctx.font='bold 28px Inter';ctx.fillText('GAME OVER',W/2,H/2-20);ctx.fillStyle='#4ade80';ctx.font='bold 20px Inter';ctx.fillText('Skor: '+score,W/2,H/2+15);ctx.fillStyle='#94a3b8';ctx.font='14px Inter';ctx.fillText('Boşluk: tekrar',W/2,H/2+45);
    gainXP(Math.max(score*2,2),'Yılan: '+score);AudioEngine.wrong();
  }
  draw();
  function loop(ts){if(!alive||AppState.activeGame!=='snake')return;if(ts-lt>=spd){lt=ts;upd();}else draw();AppState.gameRAF=requestAnimationFrame(loop);}
  AppState.gameRAF=requestAnimationFrame(loop);
  cv.addEventListener('keydown',e=>{e.preventDefault();if(e.key==='ArrowUp'&&dir.y!==1)ndir={x:0,y:-1};else if(e.key==='ArrowDown'&&dir.y!==-1)ndir={x:0,y:1};else if(e.key==='ArrowLeft'&&dir.x!==1)ndir={x:-1,y:0};else if(e.key==='ArrowRight'&&dir.x!==-1)ndir={x:1,y:0};else if(e.key===' '&&!alive)startSnakeGame(ct);});
  let ts=null;
  cv.addEventListener('touchstart',e=>{e.preventDefault();ts={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:false});
  cv.addEventListener('touchend',e=>{if(!ts)return;const dx=e.changedTouches[0].clientX-ts.x,dy=e.changedTouches[0].clientY-ts.y;if(Math.abs(dx)>Math.abs(dy)){if(dx>20&&dir.x!==-1)ndir={x:1,y:0};else if(dx<-20&&dir.x!==1)ndir={x:-1,y:0};}else{if(dy>20&&dir.y!==-1)ndir={x:0,y:1};else if(dy<-20&&dir.y!==1)ndir={x:0,y:-1};}ts=null;});
}

// ===== ❌ XOX GAME =====
function startXoxGame(ct){
  ct.innerHTML='<p style="font-size:.82rem;color:var(--sub);margin-bottom:12px">Sen: <b style="color:#3b82f6">X</b> · Bilgisayar: <b style="color:#ef4444">O</b></p><div class="xox-g" id="xoxG"></div><p id="xoxM" style="font-size:.88rem;margin-top:12px;min-height:24px;font-weight:600"></p><button class="gbtn gs" onclick="openGameInModal(\'xox\')" style="margin-top:8px;display:none" id="xoxR">🔄 Tekrar</button>';
  let bd=Array(9).fill(''),go=false;
  const wins=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  function ren(){document.getElementById('xoxG').innerHTML=bd.map((c,i)=>'<div class="xox-c '+(c?'tk ':' ')+(c==='X'?'xm':c==='O'?'om':'')+'" onclick="xoxMv('+i+')" id="xc'+i+'">'+c+'</div>').join('');}
  function chk(b,p){return wins.find(w=>w.every(i=>b[i]===p));}
  window.xoxMv=function(i){
    if(go||bd[i])return; bd[i]='X';ren();
    const w=chk(bd,'X');if(w){w.forEach(j=>{const e=document.getElementById('xc'+j);if(e)e.classList.add('wn');});xEnd('🎉 Kazandın!',true);return;}
    if(bd.every(c=>c)){xEnd('🤝 Berabere!',false);return;}
    setTimeout(()=>{
      let mv=-1;for(let j=0;j<9;j++){if(!bd[j]){bd[j]='O';if(chk(bd,'O')){mv=j;bd[j]='';break;}bd[j]='';}}
      if(mv<0)for(let j=0;j<9;j++){if(!bd[j]){bd[j]='X';if(chk(bd,'X')){mv=j;bd[j]='';break;}bd[j]='';}}
      if(mv<0&&!bd[4])mv=4;
      if(mv<0){const cn=[0,2,6,8].filter(j=>!bd[j]);if(cn.length)mv=cn[Math.floor(Math.random()*cn.length)];}
      if(mv<0)mv=bd.findIndex(c=>!c);
      bd[mv]='O';ren();
      const aw=chk(bd,'O');if(aw){aw.forEach(j=>{const e=document.getElementById('xc'+j);if(e)e.classList.add('wn');});xEnd('😞 Bilgisayar kazandı!',false);return;}
      if(bd.every(c=>c))xEnd('🤝 Berabere!',false);
    },400);
  };
  function xEnd(msg,won){go=true;document.getElementById('xoxM').innerHTML=msg;document.getElementById('xoxR').style.display='inline-block';if(won){gainXP(15,'XOX kazandın!');triggerConfetti();AudioEngine.levelUp();}else{gainXP(3,'XOX');AudioEngine.wrong();}}
  ren();
}

// ===== 🧱 BREAKOUT GAME =====
function startBreakoutGame(ct){
  const W=400,H=480;
  ct.innerHTML='<div class="gbar"><span>Skor: <b id="brS">0</b></span><span>Can: <b id="brL">3</b></span></div><canvas class="gcv" id="brC" width="'+W+'" height="'+H+'" tabindex="0"></canvas><p style="font-size:.72rem;color:var(--sub);margin-top:8px">Mouse/parmak ile paddle hareket · Boşluk: tekrar</p>';
  const cv=document.getElementById('brC'),ctx=cv.getContext('2d');cv.focus();
  const pW=70,pH=12,bR=6;let pX=(W-pW)/2,bX=W/2,bY=H-40,bdx=3,bdy=-3,sc=0,lv=3,act=true;
  const cols=['#3b82f6','#ef4444','#fde047','#4ade80','#a855f7','#f97316'];
  const bkR=5,bkC=8,bkW=W/bkC-4,bkH=18;
  let bks=[];for(let r=0;r<bkR;r++)for(let c=0;c<bkC;c++)bks.push({x:c*(bkW+4)+2,y:r*(bkH+4)+30,w:bkW,h:bkH,a:true,cl:cols[r%cols.length]});
  function draw(){
    ctx.fillStyle='#0a1224';ctx.fillRect(0,0,W,H);
    bks.forEach(b=>{if(!b.a)return;ctx.fillStyle=b.cl;ctx.fillRect(b.x,b.y,b.w,b.h);});
    ctx.fillStyle='#3b82f6';ctx.shadowColor='#3b82f6';ctx.shadowBlur=10;ctx.fillRect(pX,H-25,pW,pH);ctx.shadowBlur=0;
    ctx.fillStyle='#fff';ctx.shadowColor='#fff';ctx.shadowBlur=8;ctx.beginPath();ctx.arc(bX,bY,bR,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }
  function upd(){
    if(!act)return; bX+=bdx;bY+=bdy;
    if(bX<bR||bX>W-bR)bdx=-bdx;if(bY<bR)bdy=-bdy;
    if(bY+bR>=H-25&&bX>=pX&&bX<=pX+pW&&bdy>0){bdy=-bdy;bdx+=(bX-(pX+pW/2))*0.08;AudioEngine.click();}
    if(bY>H+10){lv--;document.getElementById('brL').textContent=lv;if(lv<=0){brGO(false);return;}bX=W/2;bY=H-40;bdx=3*(Math.random()>.5?1:-1);bdy=-3;AudioEngine.wrong();}
    bks.forEach(b=>{if(!b.a)return;if(bX+bR>b.x&&bX-bR<b.x+b.w&&bY+bR>b.y&&bY-bR<b.y+b.h){b.a=false;bdy=-bdy;sc++;document.getElementById('brS').textContent=sc;AudioEngine.correct();if(bks.every(b=>!b.a))brGO(true);}});
    draw();
  }
  function brGO(won){act=false;ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(0,0,W,H);ctx.textAlign='center';ctx.fillStyle=won?'#4ade80':'#ef4444';ctx.font='bold 26px Inter';ctx.fillText(won?'TEBRİKLER!':'GAME OVER',W/2,H/2-15);ctx.fillStyle='#fff';ctx.font='18px Inter';ctx.fillText('Skor: '+sc,W/2,H/2+15);ctx.fillStyle='#94a3b8';ctx.font='14px Inter';ctx.fillText('Boşluk: tekrar',W/2,H/2+42);gainXP(won?25:sc,'Breakout: '+sc);if(won)triggerConfetti();}
  draw();
  function loop(){if(AppState.activeGame!=='breakout')return;upd();AppState.gameRAF=requestAnimationFrame(loop);}
  AppState.gameRAF=requestAnimationFrame(loop);
  cv.addEventListener('mousemove',e=>{const r=cv.getBoundingClientRect();pX=(e.clientX-r.left)*(W/r.width)-pW/2;pX=Math.max(0,Math.min(W-pW,pX));});
  cv.addEventListener('touchmove',e=>{e.preventDefault();const r=cv.getBoundingClientRect();pX=(e.touches[0].clientX-r.left)*(W/r.width)-pW/2;pX=Math.max(0,Math.min(W-pW,pX));},{passive:false});
  cv.addEventListener('keydown',e=>{if(e.key===' '&&!act)startBreakoutGame(ct);});
}

// ===== 🏓 PONG GAME =====
function startPongGame(ct){
  const W=400,H=300;
  ct.innerHTML='<div class="gbar"><span>Sen: <b id="pgP">0</b></span><span style="color:#fde047;font-weight:700">İlk 5 kazanır</span><span>AI: <b id="pgA">0</b></span></div><canvas class="gcv" id="pgC" width="'+W+'" height="'+H+'" tabindex="0"></canvas><p style="font-size:.72rem;color:var(--sub);margin-top:8px">Mouse/parmak ile paddle hareket ettir</p>';
  const cv=document.getElementById('pgC'),ctx=cv.getContext('2d');cv.focus();
  const pdW=10,pdH=60,br=6;let pY=H/2-pdH/2,aY=H/2-pdH/2,bx=W/2,by=H/2,dx=3,dy=2,ps=0,as=0,act=true;
  function draw(){
    ctx.fillStyle='#0a1224';ctx.fillRect(0,0,W,H);
    ctx.setLineDash([4,8]);ctx.strokeStyle='rgba(255,255,255,.1)';ctx.beginPath();ctx.moveTo(W/2,0);ctx.lineTo(W/2,H);ctx.stroke();ctx.setLineDash([]);
    ctx.fillStyle='#3b82f6';ctx.shadowColor='#3b82f6';ctx.shadowBlur=8;ctx.fillRect(8,pY,pdW,pdH);
    ctx.fillStyle='#ef4444';ctx.shadowColor='#ef4444';ctx.fillRect(W-18,aY,pdW,pdH);ctx.shadowBlur=0;
    ctx.fillStyle='#fff';ctx.shadowColor='#fff';ctx.shadowBlur=10;ctx.beginPath();ctx.arc(bx,by,br,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  }
  function upd(){
    if(!act)return;bx+=dx;by+=dy;if(by<br||by>H-br)dy=-dy;
    if(bx-br<=18&&by>=pY&&by<=pY+pdH&&dx<0){dx=-dx*1.05;dy+=(by-(pY+pdH/2))*0.12;AudioEngine.click();}
    if(aY<by-pdH/2-5)aY+=2.5;else if(aY>by-pdH/2+5)aY-=2.5;
    if(bx+br>=W-18&&by>=aY&&by<=aY+pdH&&dx>0){dx=-dx*1.05;dy+=(by-(aY+pdH/2))*0.12;AudioEngine.click();}
    if(bx<0){as++;document.getElementById('pgA').textContent=as;rb(-1);}
    if(bx>W){ps++;document.getElementById('pgP').textContent=ps;rb(1);}
    if(ps>=5||as>=5)pgEnd();else draw();
  }
  function rb(d){bx=W/2;by=H/2;dx=3*d;dy=2*(Math.random()>.5?1:-1);}
  function pgEnd(){act=false;const won=ps>=5;ctx.fillStyle='rgba(0,0,0,.7)';ctx.fillRect(0,0,W,H);ctx.textAlign='center';ctx.fillStyle=won?'#4ade80':'#ef4444';ctx.font='bold 24px Inter';ctx.fillText(won?'KAZANDIN!':'KAYBETTİN',W/2,H/2-15);ctx.fillStyle='#94a3b8';ctx.font='14px Inter';ctx.fillText(ps+' - '+as,W/2,H/2+15);ctx.fillText('Boşluk: tekrar',W/2,H/2+40);gainXP(won?20:5,won?'Pong kazandın!':'Pong');if(won){triggerConfetti();AudioEngine.levelUp();}else AudioEngine.wrong();}
  draw();
  function loop(){if(AppState.activeGame!=='pong')return;upd();AppState.gameRAF=requestAnimationFrame(loop);}
  AppState.gameRAF=requestAnimationFrame(loop);
  cv.addEventListener('mousemove',e=>{const r=cv.getBoundingClientRect();pY=(e.clientY-r.top)*(H/r.height)-pdH/2;pY=Math.max(0,Math.min(H-pdH,pY));});
  cv.addEventListener('touchmove',e=>{e.preventDefault();const r=cv.getBoundingClientRect();pY=(e.touches[0].clientY-r.top)*(H/r.height)-pdH/2;pY=Math.max(0,Math.min(H-pdH,pY));},{passive:false});
  cv.addEventListener('keydown',e=>{if(e.key===' '&&!act)startPongGame(ct);});
}

// ===== 💣 MINESWEEPER =====
function startMinesweeperGame(ct){
  const R=8,C=8,MN=10;
  ct.innerHTML='<div class="gbar"><span>💣 <b id="mnMC">'+MN+'</b></span><span>⏱️ <b id="mnT">0</b>s</span><span>🚩 <b id="mnF">0</b></span></div><div id="mnG" style="margin:8px 0"></div><p style="font-size:.72rem;color:var(--sub)">Sol tık: Aç · Sağ tık: 🚩 Bayrak</p><p id="mnM" style="font-size:.88rem;margin-top:8px;min-height:22px;font-weight:600"></p>';
  let bd=[],rv=[],fg=[],go=false,fc=true,ti=null,sec=0;
  function init(){bd=Array.from({length:R},()=>Array(C).fill(0));rv=Array.from({length:R},()=>Array(C).fill(false));fg=Array.from({length:R},()=>Array(C).fill(false));go=false;fc=true;sec=0;}
  function placeMn(sr,sc){let p=0;while(p<MN){const r=Math.floor(Math.random()*R),c=Math.floor(Math.random()*C);if(bd[r][c]===-1||(Math.abs(r-sr)<=1&&Math.abs(c-sc)<=1))continue;bd[r][c]=-1;p++;}
    for(let r=0;r<R;r++)for(let c=0;c<C;c++){if(bd[r][c]===-1)continue;let n=0;for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=r+dr,nc=c+dc;if(nr>=0&&nr<R&&nc>=0&&nc<C&&bd[nr][nc]===-1)n++;}bd[r][c]=n;}}
  function ren(){
    const g=document.getElementById('mnG');g.style.cssText='display:grid;grid-template-columns:repeat('+C+',34px);gap:2px;justify-content:center;';g.innerHTML='';
    for(let r=0;r<R;r++)for(let c=0;c<C;c++){const cl=document.createElement('div');cl.className='mn-c';
      if(rv[r][c]){cl.classList.add('rv');if(bd[r][c]===-1){cl.classList.add('mh');cl.textContent='💣';}else if(bd[r][c]>0){cl.textContent=bd[r][c];cl.classList.add('n'+bd[r][c]);}}
      else if(fg[r][c]){cl.classList.add('fg');cl.textContent='🚩';}
      cl.addEventListener('click',()=>reveal(r,c));cl.addEventListener('contextmenu',e=>{e.preventDefault();tFlag(r,c);});g.appendChild(cl);}
  }
  function reveal(r,c){
    if(go||rv[r][c]||fg[r][c])return;if(fc){placeMn(r,c);fc=false;ti=setInterval(()=>{sec++;document.getElementById('mnT').textContent=sec;},1000);}
    rv[r][c]=true;if(bd[r][c]===-1){mnEnd(false);return;}
    if(bd[r][c]===0)for(let dr=-1;dr<=1;dr++)for(let dc=-1;dc<=1;dc++){const nr=r+dr,nc=c+dc;if(nr>=0&&nr<R&&nc>=0&&nc<C&&!rv[nr][nc])reveal(nr,nc);}
    ren();AudioEngine.click();let un=0;for(let r=0;r<R;r++)for(let c=0;c<C;c++)if(!rv[r][c])un++;if(un===MN)mnEnd(true);
  }
  function tFlag(r,c){if(go||rv[r][c])return;fg[r][c]=!fg[r][c];document.getElementById('mnF').textContent=fg.flat().filter(Boolean).length;ren();}
  function mnEnd(won){go=true;if(ti)clearInterval(ti);if(!won){for(let r=0;r<R;r++)for(let c=0;c<C;c++)if(bd[r][c]===-1)rv[r][c]=true;ren();}
    const m=document.getElementById('mnM');m.innerHTML=(won?'<span style="color:#4ade80">🏆 Kazandın! '+sec+'s</span>':'<span style="color:#ef4444">💥 Mayına bastın!</span>')+'<br><button class="gbtn gs" style="margin-top:8px" onclick="openGameInModal(\'minesweeper\')">🔄 Tekrar</button>';
    if(won){gainXP(30,'Mayın kazandın!');triggerConfetti();AudioEngine.levelUp();}else{gainXP(3,'Mayın');AudioEngine.wrong();}}
  init();ren();
}

// ===== 🎯 REACTION TIME =====
function startReactionGame(ct){
  ct.innerHTML='<p style="font-size:.82rem;color:var(--sub);margin-bottom:12px">Ekran <b style="color:#4ade80">yeşil</b> olunca hemen tıkla!</p><div class="rbox" id="rxB" style="background:#ef4444;color:#fff">Hazır ol...</div><p id="rxM" style="font-size:.88rem;margin-top:12px;min-height:22px;font-weight:600;text-align:center"></p><div id="rxR" style="font-size:.78rem;color:var(--sub);text-align:center;margin-top:8px"></div>';
  let rd=0,tms=[],wt=false,st=0,to=null;const MX=5,bx=document.getElementById('rxB'),msg=document.getElementById('rxM'),res=document.getElementById('rxR');
  function nxt(){
    if(rd>=MX){fin();return;}bx.style.background='#ef4444';bx.textContent='Bekle...';bx.style.cursor='default';wt=false;
    to=setTimeout(()=>{if(AppState.activeGame!=='reaction')return;bx.style.background='#22c55e';bx.textContent='TIKLA!';bx.style.cursor='pointer';wt=true;st=performance.now();},1500+Math.random()*3000);
  }
  bx.addEventListener('click',()=>{
    if(!wt){if(bx.style.backgroundColor==='rgb(239, 68, 68)'){clearTimeout(to);msg.innerHTML='<span style="color:#ef4444">⚡ Çok erken!</span>';setTimeout(nxt,1000);}return;}
    const el=Math.round(performance.now()-st);tms.push(el);rd++;wt=false;
    const cl=el<250?'#4ade80':el<400?'#fde047':'#ef4444';
    msg.innerHTML='<span style="color:'+cl+'">'+el+' ms</span> ('+rd+'/'+MX+')';bx.style.background='#1e293b';bx.textContent=el+' ms';bx.style.cursor='default';
    AudioEngine.click();res.innerHTML=tms.map((t,i)=>(i+1)+'. '+t+'ms').join(' | ');setTimeout(nxt,1200);
  });
  function fin(){
    const avg=Math.round(tms.reduce((a,b)=>a+b,0)/tms.length),best=Math.min(...tms);
    const gr=avg<250?'⚡ Şimşek!':avg<350?'🏎️ Çok Hızlı!':avg<500?'👍 İyi!':'🐌 Yavaş...';
    bx.style.background='linear-gradient(135deg,rgba(59,130,246,.2),rgba(168,85,247,.2))';bx.innerHTML='<div style="text-align:center"><p style="font-size:2rem">'+gr+'</p><p style="font-size:.85rem">Ort: <b>'+avg+'ms</b><br>En İyi: <b>'+best+'ms</b></p></div>';bx.style.cursor='default';
    msg.innerHTML='<button class="gbtn" style="margin-top:8px" onclick="openGameInModal(\'reaction\')">🔄 Tekrar</button>';
    gainXP(avg<300?15:avg<500?8:3,'Tepki: '+avg+'ms');if(avg<250)triggerConfetti();AudioEngine.levelUp();
  }
  setTimeout(nxt,1000);
}

// ===== ✈️ UÇ VURMA OYUNU =====
function startShootingGame(ct) {
  const W = 400, H = 400;
  ct.innerHTML = '<div class="gbar"><span>Skor: <b id="shS">0</b></span><span>⏱️ <b id="shT">45</b>s</span><span>Combo: <b id="shC">x1</b></span></div>' +
    '<canvas class="gcv" id="shCv" width="' + W + '" height="' + H + '" tabindex="0" style="cursor:crosshair"></canvas>' +
    '<p style="font-size:.72rem;color:var(--sub);margin-top:8px">Uçakları tıklayarak vur! 🎯</p>';
  const cv = document.getElementById('shCv'), ctx = cv.getContext('2d');
  cv.focus();

  let score = 0, combo = 0, timeLeft = 45, active = true;
  let planes = [], particles = [], stars = [];
  const planeEmoji = ['✈️', '🛩️', '🚀', '🛸', '🦅'];

  // Yıldızlı arkaplan
  for (let i = 0; i < 60; i++) stars.push({ x: Math.random() * W, y: Math.random() * H, s: Math.random() * 1.5 + 0.5, b: Math.random() });

  function spawnPlane() {
    const fromLeft = Math.random() > 0.5;
    planes.push({
      x: fromLeft ? -40 : W + 40,
      y: 30 + Math.random() * (H - 100),
      speed: (1.5 + Math.random() * 3) * (fromLeft ? 1 : -1),
      size: 24 + Math.random() * 16,
      emoji: planeEmoji[Math.floor(Math.random() * planeEmoji.length)],
      bobPhase: Math.random() * Math.PI * 2,
      hp: 1
    });
  }

  function addParticle(x, y) {
    for (let i = 0; i < 12; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 3;
      particles.push({
        x, y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        life: 1,
        color: ['#ef4444', '#f97316', '#fde047', '#fff'][Math.floor(Math.random() * 4)],
        size: 2 + Math.random() * 4
      });
    }
  }

  function draw() {
    // Gece gökyüzü gradyanı
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#0a0e27');
    grad.addColorStop(0.5, '#0f172a');
    grad.addColorStop(1, '#1a1a2e');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // Yıldızlar
    stars.forEach(s => {
      s.b += 0.02;
      const alpha = 0.3 + Math.abs(Math.sin(s.b)) * 0.7;
      ctx.fillStyle = 'rgba(255,255,255,' + alpha + ')';
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.s, 0, Math.PI * 2);
      ctx.fill();
    });

    // Uçaklar
    planes.forEach(p => {
      const bobY = Math.sin(p.bobPhase) * 5;
      ctx.font = p.size + 'px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      // Glow efekti
      ctx.shadowColor = '#3b82f6';
      ctx.shadowBlur = 12;
      ctx.fillText(p.emoji, p.x, p.y + bobY);
      ctx.shadowBlur = 0;
    });

    // Patlamalar
    particles.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  function update() {
    if (!active) return;

    // Uçakları hareket ettir
    planes.forEach(p => {
      p.x += p.speed;
      p.bobPhase += 0.04;
    });
    // Ekrandan çıkanları kaldır
    planes = planes.filter(p => p.x > -60 && p.x < W + 60);

    // Partikülleri güncelle
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.08;
      p.life -= 0.025;
    });
    particles = particles.filter(p => p.life > 0);

    // Yeni uçak spawn
    if (Math.random() < 0.04 + (45 - timeLeft) * 0.001) spawnPlane();

    draw();
  }

  // Tıklama ile vurma
  function handleClick(e) {
    if (!active) return;
    const rect = cv.getBoundingClientRect();
    const mx = (e.clientX - rect.left) * (W / rect.width);
    const my = (e.clientY - rect.top) * (H / rect.height);

    let hit = false;
    for (let i = planes.length - 1; i >= 0; i--) {
      const p = planes[i];
      const bobY = Math.sin(p.bobPhase) * 5;
      const dist = Math.sqrt((mx - p.x) ** 2 + (my - (p.y + bobY)) ** 2);
      if (dist < p.size * 0.8) {
        addParticle(p.x, p.y + bobY);
        planes.splice(i, 1);
        combo++;
        const mul = Math.min(combo, 5);
        score += 10 * mul;
        document.getElementById('shS').textContent = score;
        document.getElementById('shC').textContent = 'x' + mul;
        hit = true;
        AudioEngine.correct();
        break;
      }
    }
    if (!hit) {
      combo = 0;
      document.getElementById('shC').textContent = 'x1';
      // Miss efekti
      ctx.fillStyle = 'rgba(239,68,68,.3)';
      ctx.beginPath();
      ctx.arc(mx, my, 15, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  // Touch desteği
  function handleTouch(e) {
    e.preventDefault();
    const touch = e.touches[0];
    handleClick({ clientX: touch.clientX, clientY: touch.clientY });
  }

  cv.addEventListener('click', handleClick);
  cv.addEventListener('touchstart', handleTouch, { passive: false });

  // Zamanlayıcı
  AppState.gameInterval = setInterval(() => {
    if (!active) return;
    timeLeft--;
    const el = document.getElementById('shT');
    if (el) el.textContent = timeLeft;
    if (timeLeft <= 0) {
      active = false;
      clearInterval(AppState.gameInterval);
      AppState.gameInterval = null;
      if (AppState.gameRAF) { cancelAnimationFrame(AppState.gameRAF); AppState.gameRAF = null; }

      // Son ekran
      ctx.fillStyle = 'rgba(0,0,0,.75)';
      ctx.fillRect(0, 0, W, H);
      ctx.textAlign = 'center';
      ctx.shadowColor = '#4ade80';
      ctx.shadowBlur = 20;
      ctx.fillStyle = score >= 200 ? '#4ade80' : score >= 100 ? '#fde047' : '#ef4444';
      ctx.font = 'bold 28px Inter';
      ctx.fillText(score >= 200 ? '🏆 ACE PİLOT!' : score >= 100 ? '👍 İYİ NİŞANCI!' : '🎯 ANTRENMAN BİTTİ', W / 2, H / 2 - 30);
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 22px Inter';
      ctx.fillText('Skor: ' + score, W / 2, H / 2 + 10);
      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px Inter';
      ctx.fillText('Boşluk: tekrar', W / 2, H / 2 + 42);
      gainXP(Math.floor(score / 5), 'Uç Vurma: ' + score);
      if (score >= 200) triggerConfetti();
      AudioEngine.levelUp();
    }
  }, 1000);

  // Oyun döngüsü
  function loop() {
    if (AppState.activeGame !== 'shooting') return;
    update();
    AppState.gameRAF = requestAnimationFrame(loop);
  }
  AppState.gameRAF = requestAnimationFrame(loop);

  // Tekrar başlatma
  cv.addEventListener('keydown', e => {
    if (e.key === ' ' && !active) startShootingGame(ct);
  });

  // İlk uçakları spawn et
  for (let i = 0; i < 4; i++) spawnPlane();
}

// ===== 🏎️ ARABA YARIŞI OYUNU =====
function startRacingGame(ct) {
  const W = 300, H = 480;
  ct.innerHTML = '<div class="gbar"><span>Skor: <b id="rcS">0</b></span><span>Hız: <b id="rcSpd">60</b> km/h</span><span>Can: <b id="rcL">3</b></span></div>' +
    '<canvas class="gcv" id="rcCv" width="' + W + '" height="' + H + '" tabindex="0"></canvas>' +
    '<p style="font-size:.72rem;color:var(--sub);margin-top:8px">← → Ok tuşları veya kaydırma ile yön değiştir</p>';
  const cv = document.getElementById('rcCv'), ctx = cv.getContext('2d');
  cv.focus();

  // Yol ayarları
  const roadL = 40, roadR = W - 40, roadW = roadR - roadL;
  const laneW = roadW / 3;
  const lanes = [roadL + laneW * 0.5, roadL + laneW * 1.5, roadL + laneW * 2.5];

  // Oyuncu
  const carW = 30, carH = 50;
  let playerX = lanes[1], playerLane = 1;
  let targetX = playerX;

  // Oyun değişkenleri
  let score = 0, lives = 3, speed = 3, active = true;
  let enemies = [], particles = [], roadOffset = 0;
  let frameCount = 0, invincible = 0;

  const carColors = ['#ef4444', '#3b82f6', '#fbbf24', '#a855f7', '#10b981'];
  const playerColor = '#4ade80';

  function spawnEnemy() {
    const lane = Math.floor(Math.random() * 3);
    enemies.push({
      x: lanes[lane],
      y: -60,
      w: 28, h: 48,
      color: carColors[Math.floor(Math.random() * carColors.length)],
      speed: speed * (0.6 + Math.random() * 0.5)
    });
  }

  function addCrashParticle(x, y) {
    for (let i = 0; i < 20; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = 2 + Math.random() * 4;
      particles.push({
        x, y,
        vx: Math.cos(angle) * spd,
        vy: Math.sin(angle) * spd,
        life: 1,
        color: ['#ef4444', '#f97316', '#fde047', '#fff'][Math.floor(Math.random() * 4)],
        size: 2 + Math.random() * 5
      });
    }
  }

  function drawCar(x, y, w, h, color, isPlayer) {
    // Gövde
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = isPlayer ? 15 : 8;
    ctx.beginPath();
    ctx.roundRect(x - w / 2, y - h / 2, w, h, 5);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Cam
    ctx.fillStyle = isPlayer ? 'rgba(59,130,246,.6)' : 'rgba(100,200,255,.5)';
    ctx.fillRect(x - w / 2 + 4, y - h / 2 + (isPlayer ? 6 : h - 16), w - 8, 10);

    // Farlar
    if (isPlayer) {
      ctx.fillStyle = '#fde047';
      ctx.shadowColor = '#fde047';
      ctx.shadowBlur = 6;
      ctx.fillRect(x - w / 2 + 2, y - h / 2, 5, 4);
      ctx.fillRect(x + w / 2 - 7, y - h / 2, 5, 4);
      ctx.shadowBlur = 0;
    } else {
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(x - w / 2 + 2, y + h / 2 - 4, 5, 4);
      ctx.fillRect(x + w / 2 - 7, y + h / 2 - 4, 5, 4);
    }

    // Tekerlekler
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(x - w / 2 - 3, y - h / 2 + 6, 5, 12);
    ctx.fillRect(x + w / 2 - 2, y - h / 2 + 6, 5, 12);
    ctx.fillRect(x - w / 2 - 3, y + h / 2 - 18, 5, 12);
    ctx.fillRect(x + w / 2 - 2, y + h / 2 - 18, 5, 12);
  }

  function draw() {
    // Çim ve yol
    ctx.fillStyle = '#0a3d0a';
    ctx.fillRect(0, 0, W, H);

    // Yol
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(roadL, 0, roadW, H);

    // Yol kenarı çizgileri
    ctx.fillStyle = '#fbbf24';
    ctx.fillRect(roadL - 3, 0, 3, H);
    ctx.fillRect(roadR, 0, 3, H);

    // Şerit çizgileri (kayan)
    ctx.setLineDash([30, 30]);
    ctx.lineDashOffset = -roadOffset;
    ctx.strokeStyle = 'rgba(255,255,255,.3)';
    ctx.lineWidth = 2;
    for (let i = 1; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(roadL + laneW * i, 0);
      ctx.lineTo(roadL + laneW * i, H);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Orta çizgi (kesintisiz)
    ctx.setLineDash([40, 20]);
    ctx.lineDashOffset = -roadOffset;
    ctx.strokeStyle = 'rgba(255,255,255,.08)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 3; i++) {
      ctx.beginPath();
      ctx.moveTo(lanes[i], 0);
      ctx.lineTo(lanes[i], H);
      ctx.stroke();
    }
    ctx.setLineDash([]);

    // Çim detayları
    ctx.fillStyle = '#0d4f0d';
    for (let y = (roadOffset * 0.3 % 40); y < H; y += 40) {
      ctx.fillRect(8, y, 15, 3);
      ctx.fillRect(W - 23, y + 20, 15, 3);
    }

    // Düşman arabalar
    enemies.forEach(e => drawCar(e.x, e.y, e.w, e.h, e.color, false));

    // Oyuncu (yanıp sönme invincible modunda)
    if (invincible <= 0 || Math.floor(frameCount / 4) % 2 === 0) {
      drawCar(playerX, H - 80, carW, carH, playerColor, true);
    }

    // Partiküller
    particles.forEach(p => {
      ctx.globalAlpha = p.life;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;

    // Hız efekti çizgileri
    if (speed > 5) {
      ctx.strokeStyle = 'rgba(255,255,255,' + Math.min((speed - 5) * 0.03, 0.15) + ')';
      ctx.lineWidth = 1;
      for (let i = 0; i < 3; i++) {
        const sx = roadL + Math.random() * roadW;
        const sy = Math.random() * H;
        ctx.beginPath();
        ctx.moveTo(sx, sy);
        ctx.lineTo(sx, sy + 15 + speed * 2);
        ctx.stroke();
      }
    }
  }

  function update() {
    if (!active) return;
    frameCount++;

    // Yol kayması
    roadOffset += speed;

    // Oyuncu yumuşak hareket
    playerX += (targetX - playerX) * 0.15;

    // Hız artışı
    if (frameCount % 120 === 0 && speed < 12) {
      speed += 0.3;
      document.getElementById('rcSpd').textContent = Math.round(60 + (speed - 3) * 15);
    }

    // Skor
    if (frameCount % 10 === 0) {
      score++;
      document.getElementById('rcS').textContent = score;
    }

    // Düşman spawn
    if (Math.random() < 0.015 + speed * 0.003) spawnEnemy();

    // Düşmanlar güncelle
    enemies.forEach(e => { e.y += e.speed + speed * 0.4; });
    enemies = enemies.filter(e => e.y < H + 80);

    // Çarpışma kontrolü
    if (invincible > 0) invincible--;
    else {
      const py = H - 80;
      for (let i = enemies.length - 1; i >= 0; i--) {
        const e = enemies[i];
        if (Math.abs(playerX - e.x) < (carW + e.w) / 2 - 4 &&
            Math.abs(py - e.y) < (carH + e.h) / 2 - 4) {
          addCrashParticle(playerX, py);
          enemies.splice(i, 1);
          lives--;
          document.getElementById('rcL').textContent = lives;
          AudioEngine.wrong();
          invincible = 60; // 1 saniye dokunulmazlık
          if (lives <= 0) { gameOver(); return; }
          break;
        }
      }
    }

    // Partiküller güncelle
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.1;
      p.life -= 0.02;
    });
    particles = particles.filter(p => p.life > 0);

    draw();
  }

  function gameOver() {
    active = false;
    if (AppState.gameInterval) { clearInterval(AppState.gameInterval); AppState.gameInterval = null; }
    if (AppState.gameRAF) { cancelAnimationFrame(AppState.gameRAF); AppState.gameRAF = null; }

    ctx.fillStyle = 'rgba(0,0,0,.75)';
    ctx.fillRect(0, 0, W, H);
    ctx.textAlign = 'center';
    ctx.shadowColor = score >= 100 ? '#4ade80' : '#ef4444';
    ctx.shadowBlur = 20;
    ctx.fillStyle = score >= 100 ? '#4ade80' : '#ef4444';
    ctx.font = 'bold 28px Inter';
    ctx.fillText(score >= 100 ? '🏆 SÜPER SÜRÜŞ!' : '💥 KAZA!', W / 2, H / 2 - 40);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 22px Inter';
    ctx.fillText('Skor: ' + score, W / 2, H / 2);
    ctx.fillStyle = '#94a3b8';
    ctx.font = '13px Inter';
    ctx.fillText('Hız: ' + Math.round(60 + (speed - 3) * 15) + ' km/h', W / 2, H / 2 + 28);
    ctx.fillText('Boşluk: tekrar', W / 2, H / 2 + 52);

    gainXP(Math.floor(score / 3), 'Araba Yarışı: ' + score);
    if (score >= 100) triggerConfetti();
    AudioEngine.levelUp();
  }

  // Kontroller
  cv.addEventListener('keydown', e => {
    e.preventDefault();
    if (!active && e.key === ' ') { startRacingGame(ct); return; }
    if (e.key === 'ArrowLeft' && playerLane > 0) { playerLane--; targetX = lanes[playerLane]; }
    if (e.key === 'ArrowRight' && playerLane < 2) { playerLane++; targetX = lanes[playerLane]; }
  });

  // Touch kontrol
  let touchStartX = null;
  cv.addEventListener('touchstart', e => {
    e.preventDefault();
    touchStartX = e.touches[0].clientX;
  }, { passive: false });
  cv.addEventListener('touchend', e => {
    if (!touchStartX) return;
    const dx = e.changedTouches[0].clientX - touchStartX;
    if (dx > 30 && playerLane < 2) { playerLane++; targetX = lanes[playerLane]; }
    else if (dx < -30 && playerLane > 0) { playerLane--; targetX = lanes[playerLane]; }
    touchStartX = null;
  });

  // Oyun döngüsü
  function loop() {
    if (AppState.activeGame !== 'racing') return;
    update();
    AppState.gameRAF = requestAnimationFrame(loop);
  }
  AppState.gameRAF = requestAnimationFrame(loop);
}

// ===== MATRIX CANVAS (RAF + visibilitychange ile CPU tasarrufu) =====

function initMatrix() {
  const mc = document.getElementById('matrixCanvas'); if (!mc) return;
  const ctx = mc.getContext('2d');
  mc.width = window.innerWidth; mc.height = window.innerHeight;
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&'.split('');
  const fs = 15, cols = Math.floor(mc.width / fs);
  const drops = Array.from({ length: cols }, () => 1);
  let lastTime = 0;
  const FRAME_MS = 50; // ~20fps — matrix efekti için yeterli

  function drawMatrix(ts) {
    // Sekme gizliyse veya hacker modu kapandıysa döngüyü bitir
    if (document.hidden || !document.body.classList.contains('hacker-mode')) {
      AppState.isMatrixRunning = false;
      AppState.matrixRAF = null;
      return;
    }
    if (ts - lastTime >= FRAME_MS) {
      lastTime = ts;
      ctx.fillStyle = 'rgba(0,0,0,0.05)'; ctx.fillRect(0, 0, mc.width, mc.height);
      ctx.fillStyle = '#0F0'; ctx.font = fs + 'px monospace';
      drops.forEach((d, i) => { ctx.fillText(letters[Math.floor(Math.random() * letters.length)], i * fs, d * fs); if (d * fs > mc.height && Math.random() > .975) drops[i] = 0; drops[i]++; });
    }
    AppState.matrixRAF = requestAnimationFrame(drawMatrix);
  }

  function startMatrix() {
    if (AppState.isMatrixRunning || document.hidden || !document.body.classList.contains('hacker-mode')) return;
    AppState.isMatrixRunning = true;
    AppState.matrixRAF = requestAnimationFrame(drawMatrix);
  }

  function stopMatrix() {
    if (AppState.matrixRAF) { cancelAnimationFrame(AppState.matrixRAF); AppState.matrixRAF = null; }
    AppState.isMatrixRunning = false;
  }

  // visibilitychange: sekme arka plana geçince durdur, öne gelince devam et
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stopMatrix();
    else if (document.body.classList.contains('hacker-mode')) startMatrix();
  });

  // Hacker modu açıldığında/kapandığında matrix'i başlat/durdur
  // MutationObserver ile body class değişikliğini izle
  new MutationObserver(() => {
    if (document.body.classList.contains('hacker-mode')) startMatrix();
    else stopMatrix();
  }).observe(document.body, { attributes: true, attributeFilter: ['class'] });

  // startMatrix'i global'e al ki hacker modu handler'ı kullanabilsin
  window._startMatrix = startMatrix;
  window._stopMatrix = stopMatrix;
}
setTimeout(initMatrix, 1000);

const TICKER_QUOTES = ["Hiçbir şey imkansız değildir!", "Yapay zeka ile kendi sınırlarını aş!", "Geleceği kodlayanlar çizer.", "Ata Ortaokulu — Gelecek Sensin!"];
setInterval(() => {
  tickerWeatherText = '💡 ' + TICKER_QUOTES[Math.floor(Math.random() * TICKER_QUOTES.length)];
  buildTicker();
}, 8000);
// ===== TICKER =====
let tickerWeatherText = '';
function buildTicker() {
  const inner = document.getElementById('tickerInner'); if (!inner) return;
  let items = [];
  if (tickerWeatherText) items.push(tickerWeatherText);
  if (window._tickerRates) items = items.concat(window._tickerRates);
  if (!items.length) return;
  const html = items.map(t => '<span class="ticker-item">' + t + '</span><span class="ticker-sep"> &nbsp;·&nbsp; </span>').join('');
  inner.innerHTML = html + html;
}
function fetchTickerRates() {
  if (AppState.cache.currency && (Date.now() - AppState.cache.currency.time < 15 * 60000)) {
    window._tickerRates = AppState.cache.currency.data;
    buildTicker();
    return;
  }
  fetch('https://api.frankfurter.app/latest?from=USD&to=TRY,EUR,GBP')
    .then(r => r.json()).then(d => {
      window._tickerRates = ['💵 USD→TRY: <b>' + d.rates.TRY.toFixed(2) + '</b>', '💶 EUR→TRY: <b>' + (d.rates.TRY / d.rates.EUR).toFixed(2) + '</b>'];
      AppState.cache.currency = { data: window._tickerRates, time: Date.now() };
      buildTicker();
    }).catch(() => {});
}
fetchTickerRates();
setInterval(fetchTickerRates, 5 * 60 * 1000);

const ActiveAppGames = {};

// ===== HAFIZA KARTI OYUNU =====
function startMemoryGame() {
  const emojis = ['🐱','🐶','🦊','🐸','🦁','🐯','🐻','🦄'];
  const cards = [...emojis, ...emojis].sort(() => Math.random() - 0.5);
  const uid = 'mem' + Date.now();
  let flipped = [], matched = [], moves = 0, lock = false;

  const grid = cards.map((e, i) =>
    `<div class="mem-card" id="mc${uid}_${i}" onclick="ActiveAppGames['${uid}'].flip(${i})" data-emoji="${e}">
      <div class="mem-inner"><div class="mem-front">❓</div><div class="mem-back">${e}</div></div>
    </div>`
  ).join('');

  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <p style="font-weight:700;color:#f59e0b;text-align:center;margin-bottom:8px">🃏 HAFIZA KARTI — Eşleştir!</p>
    <div class="mem-grid" id="mg${uid}">${grid}</div>
    <p id="mm${uid}" style="text-align:center;font-size:.8rem;color:var(--sub);margin-top:8px">Hamle: 0</p>
  </div>`);

  stats.games++; updateStats(); saveStats(); gainXP(5, 'Hafıza Kartı başlattın'); updateQuest('games');
  AudioEngine.click();

  ActiveAppGames[uid] = {
    flip: function(i) {
    if (lock || flipped.includes(i) || matched.includes(i)) return;
    const card = document.getElementById(`mc${uid}_${i}`);
    card.classList.add('flipped');
    flipped.push(i);
    AudioEngine.click();

    if (flipped.length === 2) {
      lock = true; moves++;
      document.getElementById(`mm${uid}`).textContent = `Hamle: ${moves}`;
      const [a, b] = flipped;
      const ea = document.getElementById(`mc${uid}_${a}`).dataset.emoji;
      const eb = document.getElementById(`mc${uid}_${b}`).dataset.emoji;

      if (ea === eb) {
        matched.push(a, b);
        [a, b].forEach(idx => document.getElementById(`mc${uid}_${idx}`).classList.add('matched'));
        flipped = []; lock = false;
        AudioEngine.correct();
        if (matched.length === cards.length) {
          document.getElementById(`mm${uid}`).innerHTML =
            `<span style="color:#4ade80;font-weight:700">🏆 TEBRİKLER! ${moves} hamlede bitirdin!</span><br><button onclick="startMemoryGame()" style="margin-top:10px;padding:8px 16px;background:#3b82f6;color:white;border-radius:6px;border:none;cursor:pointer">🔄 Tekrar Oyna</button>`;
          triggerConfetti(); gainXP(20, 'Hafıza Kartı tamamladın!'); AudioEngine.levelUp();
        }
      } else {
        setTimeout(() => {
          [a, b].forEach(idx => document.getElementById(`mc${uid}_${idx}`).classList.remove('flipped'));
          flipped = []; lock = false;
          AudioEngine.wrong();
        }, 900);
      }
    }
  }
};
}

// ===== MATEMATİK YARIŞMASI =====
function startMathRace() {
  const uid = 'mr' + Date.now();
  let score = 0, combo = 0, timeLeft = 60, interval = null, active = true;

  function genQ() {
    const ops = ['+', '-', '×'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let a, b, ans;
    if (op === '+') { a = Math.floor(Math.random()*50)+1; b = Math.floor(Math.random()*50)+1; ans = a+b; }
    else if (op === '-') { a = Math.floor(Math.random()*50)+10; b = Math.floor(Math.random()*a)+1; ans = a-b; }
    else { a = Math.floor(Math.random()*12)+2; b = Math.floor(Math.random()*12)+2; ans = a*b; }
    return { q: `${a} ${op} ${b} = ?`, ans };
  }

  let current = genQ();
  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <p style="font-weight:700;color:#f97316;text-align:center">⚡ MATEMATİK YARIŞMASI</p>
    <div style="display:flex;justify-content:space-between;margin:8px 0;font-size:.82rem">
      <span style="color:var(--sub)">⏱️ <b id="mr_t${uid}">60</b>s</span>
      <span style="color:#4ade80">Puan: <b id="mr_s${uid}">0</b></span>
      <span style="color:#fde047">Combo: <b id="mr_c${uid}">x1</b></span>
    </div>
    <div id="mr_q${uid}" style="font-size:1.6rem;font-weight:800;color:var(--acc);text-align:center;padding:16px 0">${current.q}</div>
    <div style="display:flex;gap:8px">
      <input id="mr_i${uid}" type="number" placeholder="Cevap yaz..." style="flex:1;padding:10px;border-radius:8px;border:1px solid var(--bdr);background:rgba(255,255,255,.06);color:var(--txt);font-size:1rem;outline:none" onkeypress="if(event.key==='Enter') mrCheck_${uid}()">
      <button onclick="mrCheck_${uid}()" style="padding:10px 16px;background:linear-gradient(135deg,var(--acc),var(--acc2));color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer">✓</button>
    </div>
    <div id="mr_fb${uid}" style="text-align:center;font-size:.82rem;margin-top:6px;min-height:18px"></div>
  </div>`);

  stats.games++; updateStats(); saveStats(); updateQuest('games'); AudioEngine.click();

  interval = setInterval(() => {
    if (!active) return;
    timeLeft--;
    const el = document.getElementById(`mr_t${uid}`);
    if (el) el.textContent = timeLeft;
    if (timeLeft <= 0) {
      clearInterval(interval); active = false;
      const inp = document.getElementById(`mr_i${uid}`);
      if (inp) inp.disabled = true;
      document.getElementById(`mr_fb${uid}`).innerHTML = `<span style="color:#fde047;font-weight:700">⏰ Süre doldu! Puan: ${score}</span>`;
      gainXP(Math.floor(score / 2), 'Matematik Yarışması'); triggerConfetti();
    }
  }, 1000);

  window[`mrCheck_${uid}`] = function() {
    if (!active) return;
    const inp = document.getElementById(`mr_i${uid}`);
    const val = parseInt(inp.value);
    const fb = document.getElementById(`mr_fb${uid}`);
    if (isNaN(val)) return;

    if (val === current.ans) {
      combo++;
      const mul = Math.min(combo, 5);
      score += 10 * mul;
      fb.innerHTML = `<span style="color:#4ade80;font-weight:700">✅ Doğru! +${10 * mul} puan ${mul > 1 ? '🔥 COMBO x' + mul : ''}</span>`;
      AudioEngine.correct();
    } else {
      combo = 0;
      fb.innerHTML = `<span style="color:#fca5a5">❌ Yanlış! Cevap: <b>${current.ans}</b></span>`;
      AudioEngine.wrong();
    }

    const sEl = document.getElementById(`mr_s${uid}`);
    const cEl = document.getElementById(`mr_c${uid}`);
    if (sEl) sEl.textContent = score;
    if (cEl) cEl.textContent = 'x' + Math.min(combo + 1, 5);
    current = genQ();
    const qEl = document.getElementById(`mr_q${uid}`);
    if (qEl) qEl.textContent = current.q;
    inp.value = ''; inp.focus();
  };
}

// ===== 4×4 MİNİ SUDOKU =====
function startSudoku() {
  const puzzles = [
    { board: [[1,0,3,0],[0,4,0,2],[4,0,0,3],[0,2,4,0]], sol: [[1,2,3,4],[3,4,1,2],[4,1,2,3],[2,3,4,1]] },
    { board: [[2,0,4,0],[0,4,0,2],[0,2,0,4],[4,0,2,0]], sol: [[2,3,4,1],[1,4,3,2],[3,2,1,4],[4,1,2,3]] },
    { board: [[0,3,4,0],[4,0,0,2],[1,0,0,3],[0,2,1,0]], sol: [[2,3,4,1],[4,1,3,2],[1,4,2,3],[3,2,1,4]] }
  ];
  const pz = puzzles[Math.floor(Math.random() * puzzles.length)];
  const uid = 'sdk' + Date.now();
  let hints = 3;

  function renderGrid() {
    return pz.board.map((row, r) =>
      `<div class="sdk-row">${row.map((c, col) =>
        c !== 0
          ? `<div class="sdk-cell fixed">${c}</div>`
          : `<input class="sdk-cell input" id="sc${uid}_${r}_${col}" type="number" min="1" max="4" maxlength="1"
              oninput="this.value=this.value.slice(-1);if(this.value<1||this.value>4)this.value=''">`
      ).join('')}</div>`
    ).join('');
  }

  addBotMsg(`<div style="background:rgba(0,0,0,.45);padding:14px;border-radius:12px">
    <p style="font-weight:700;color:#a78bfa;text-align:center;margin-bottom:8px">🔢 4×4 MİNİ SUDOKU</p>
    <p style="font-size:.72rem;color:var(--sub);text-align:center;margin-bottom:10px">Her satır, sütun ve 2×2 kutuda 1-4 rakamları birer kez kullanılmalı</p>
    <div class="sdk-grid">${renderGrid()}</div>
    <div style="display:flex;gap:8px;margin-top:10px;justify-content:center">
      <button onclick="ActiveAppGames['${uid}'].check()" style="padding:8px 18px;background:#10b981;color:#fff;border:none;border-radius:8px;font-weight:700;cursor:pointer">✅ Kontrol Et</button>
      <button onclick="ActiveAppGames['${uid}'].hint()" style="padding:8px 14px;background:rgba(167,139,250,.2);border:1px solid #a78bfa;color:#a78bfa;border-radius:8px;font-weight:700;cursor:pointer">💡 İpucu (<span id="sh${uid}">${hints}</span>)</button>
    </div>
    <p id="sm${uid}" style="text-align:center;font-size:.82rem;margin-top:8px;min-height:18px"></p>
  </div>`);

  stats.games++; updateStats(); saveStats(); gainXP(5, 'Sudoku başlattın'); updateQuest('games'); AudioEngine.click();

  ActiveAppGames[uid] = ActiveAppGames[uid] || {};
  ActiveAppGames[uid].check = function() {
    let ok = true;
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (pz.board[r][c] !== 0) continue;
        const inp = document.getElementById(`sc${uid}_${r}_${c}`);
        const val = parseInt(inp?.value);
        if (val !== pz.sol[r][c]) { ok = false; if (inp) inp.style.borderColor = '#ef4444'; }
        else { if (inp) inp.style.borderColor = '#22c55e'; }
      }
    }
    const msg = document.getElementById(`sm${uid}`);
    if (ok) {
      if (msg) msg.innerHTML = '<span style="color:#4ade80;font-weight:700">🏆 Mükemmel! Sudoku tamamlandı!</span><br><button onclick="startSudoku()" style="margin-top:10px;padding:8px 16px;background:#10b981;color:white;border-radius:6px;border:none;cursor:pointer">🔄 Tekrar Oyna</button>';
      triggerConfetti(); gainXP(25, 'Sudoku çözdün!'); AudioEngine.levelUp();
    } else {
      if (msg) msg.innerHTML = '<span style="color:#fca5a5">❌ Bazı hücreler yanlış!</span>';
      AudioEngine.wrong();
    }
  };

  ActiveAppGames[uid].hint = function() {
    if (hints <= 0) { showToast('💡', 'İpucu Bitti!', 'Artık ipucu hakkın yok.', ''); return; }
    const empties = [];
    for (let r = 0; r < 4; r++)
      for (let c = 0; c < 4; c++)
        if (pz.board[r][c] === 0) {
          const inp = document.getElementById(`sc${uid}_${r}_${c}`);
          if (inp && !inp.value) empties.push({ r, c, inp });
        }
    if (!empties.length) return;
    const pick = empties[Math.floor(Math.random() * empties.length)];
    pick.inp.value = pz.sol[pick.r][pick.c];
    pick.inp.style.borderColor = '#f59e0b';
    pick.inp.disabled = true;
    hints--;
    const hEl = document.getElementById(`sh${uid}`);
    if (hEl) hEl.textContent = hints;
    AudioEngine.click();
  };
}




// DOMPurify: artık npm paketinden import ediliyor (dosya başında)
// Inline kopya kaldırıldı — ~250KB tasarruf
// ============================================
// DOMPurify 3.2.7 inline — source map removed (not needed for embedded usage)
// ============================================
// EVENT DELEGATION (CSP FIX)
// ============================================
// Module scripts run after DOM is ready — no need for DOMContentLoaded
(function initEventDelegation() {
    // Static Bindings
    const bind = (id, fn) => { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
    bind('btnAudioToggle', () => window.AudioEngine && window.AudioEngine.toggle());
    bind('btnCompleteOnboarding', completeOnboarding);
    bind('btnDemoOnboarding', demoOnboarding);
    bind('btnMobileMenu', toggleSidebar);
    bind('sidebarBackdrop', toggleSidebar);
    bind('btnMobileMenu', toggleSidebar);
    bind('btnOpenGameMenu', openGameMenu);
    bind('btnOpenSettings', openSettings);
    bind('btnExportChat', exportChat);
    bind('btnLogoutUser', localLogout);
    bind('btnClearMemory', clearMemory);
    bind('btnToggleVoice', toggleVoice);
    bind('btnSendMessage', sendMessage);
    bind('btnCloseSettings', closeSettings);
    bind('btnAddNewRule', addNewRule);
    bind('btnToggleGameFullscreen', toggleGameFullscreen);
    bind('btnCloseGameModal', closeGameModal);
    bind('btnAudioToggle', () => window.AudioEngine && window.AudioEngine.toggle());

    const voiceBtn = document.querySelector('.audio-btn');
    if (voiceBtn) voiceBtn.addEventListener('click', () => AudioEngine.toggle());

    const inpOb = document.getElementById('inpOnboardName');
    if (inpOb) inpOb.addEventListener('keypress', (e) => { if (e.key === 'Enter') completeOnboarding(); });
    
    const inpUsr = document.getElementById('userInput');
    if (inpUsr) inpUsr.addEventListener('keypress', (e) => { if (e.key === 'Enter') sendMessage(); });

    // ===== SETTINGS TABS =====
    document.querySelectorAll('.stab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.stab').forEach(t => { t.classList.remove('active'); t.setAttribute('aria-selected', 'false'); });
        document.querySelectorAll('.stab-panel').forEach(p => p.classList.remove('active'));
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        const panel = document.getElementById('panel' + tab.dataset.tab.charAt(0).toUpperCase() + tab.dataset.tab.slice(1));
        if (panel) panel.classList.add('active');
      });
    });

    // ===== API KEY PANEL =====
    const savedKey = null;
    const savedProxy = localStorage.getItem('mega_proxy_url');
    if (savedKey) { const el = document.getElementById('inputApiKey'); if (el) el.value = savedKey; }
    if (savedProxy) { const el = document.getElementById('inputProxyUrl'); if (el) el.value = savedProxy; }

    bind('btnSaveApiKey', () => {
      const key = document.getElementById('inputApiKey').value.trim();
      const proxy = document.getElementById('inputProxyUrl').value.trim();
      if (key) { sessionStorage.setItem('mega_gemini_key', key); localStorage.setItem('mega_gemini_key', key); }
      else { sessionStorage.removeItem('mega_gemini_key'); localStorage.removeItem('mega_gemini_key'); }
      if (proxy) localStorage.setItem('mega_proxy_url', proxy);
      else localStorage.removeItem('mega_proxy_url');
      document.getElementById('apiTestResult').innerHTML = '<span style="color:#4ade80">✅ Kaydedildi!</span>';
      showToast('🔑', 'API Ayarları Kaydedildi', '', '');
    });

    bind('btnTestApiKey', () => {
      const key = document.getElementById('inputApiKey').value.trim();
      if (!key) { document.getElementById('apiTestResult').innerHTML = '<span style="color:#ef4444">❌ Anahtar girilmedi</span>'; return; }
      document.getElementById('apiTestResult').innerHTML = '<span style="color:var(--acc)">Test ediliyor...</span>';
      fetch('https://generativelanguage.googleapis.com/v1beta/models?key=' + key, { signal: AbortSignal.timeout(8000) })
        .then(r => { if (!r.ok) throw new Error(r.status); return r.json(); })
        .then(data => {
          const models = data.models ? data.models.length : 0;
          document.getElementById('apiTestResult').innerHTML = '<span style="color:#4ade80">✅ Başarılı! ' + models + ' model erişilebilir.</span>';
        })
        .catch(e => {
          document.getElementById('apiTestResult').innerHTML = '<span style="color:#ef4444">❌ Hata: Geçersiz anahtar veya ağ sorunu (' + e.message + ')</span>';
        });
    });

    bind('btnClearApiKey', () => {
      sessionStorage.removeItem('mega_gemini_key');
      localStorage.removeItem('mega_gemini_key');
      localStorage.removeItem('mega_proxy_url');
      document.getElementById('inputApiKey').value = '';
      document.getElementById('inputProxyUrl').value = '';
      document.getElementById('apiTestResult').innerHTML = '<span style="color:var(--sub)">Temizlendi.</span>';
    });

    // Performans Modu Toggle
    const lowEndToggle = document.getElementById('toggleLowEnd');
    if (lowEndToggle) {
      lowEndToggle.checked = isLowEndMode();
      lowEndToggle.addEventListener('change', () => {
        localStorage.setItem('mega_lowend_mode', lowEndToggle.checked ? 'true' : 'false');
        applyPerformanceMode();
        showToast('⚡', lowEndToggle.checked ? 'Performans Modu Açık' : 'Performans Modu Kapalı', 'Efektler ' + (lowEndToggle.checked ? 'kapatıldı' : 'açıldı'), '');
      });
    }
    applyPerformanceMode();

    // ===== STUDY ANALYZER =====
    const studyDrop = document.getElementById('studyDropZone');
    const studyInput = document.getElementById('studyFileInput');
    if (studyDrop && studyInput) {
      studyDrop.addEventListener('click', () => studyInput.click());
      studyDrop.addEventListener('dragover', e => { e.preventDefault(); studyDrop.classList.add('dragover'); });
      studyDrop.addEventListener('dragleave', () => studyDrop.classList.remove('dragover'));
      studyDrop.addEventListener('drop', e => { e.preventDefault(); studyDrop.classList.remove('dragover'); if (e.dataTransfer.files[0]) handleStudyFile(e.dataTransfer.files[0]); });
      studyInput.addEventListener('change', e => { if (e.target.files[0]) handleStudyFile(e.target.files[0]); e.target.value = ''; });
    }

    bind('btnStudyQuiz', () => {
      if (!studyAnalyzer.hasContent()) return;
      closeSettings();
      addBotMsg('📊 Quiz oluşturuluyor, lütfen bekleyin...', false);
      const prompt = studyAnalyzer.buildQuizPrompt();
      const fetchQuiz = fetch('https://text.pollinations.ai/openai', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: [{role:'user', content:prompt}], model: 'openai' }),
          signal: AbortSignal.timeout(20000)
        }).then(r => r.json()).then(d => d?.choices?.[0]?.message?.content || '');

      fetchQuiz.then(text => {
        const qs = studyAnalyzer.parseQuizResponse(text);
        if (!qs || qs.length === 0) { addBotMsg('❌ Quiz oluşturulamadı. Farklı bir dosya deneyin.', true); return; }
        AppState.proMode = 'STUDY_QUIZ';
        addBotMsg(studyAnalyzer.getQuestionHTML(), true);
        gainXP(5, 'Ders Quiz Başlatıldı');
      }).catch(e => { addBotMsg('❌ Quiz oluşturulurken hata: ' + e.message, true); });
    });

    bind('btnStudyAnalyze', () => {
      if (!studyAnalyzer.hasContent()) return;
      closeSettings();
      addBotMsg('🔍 Analiz yapılıyor...', false);
      const prompt = studyAnalyzer.buildAnalysisPrompt();
      const fetchAnalysis = fetch('https://text.pollinations.ai/openai', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: [{role:'user', content:prompt}], model: 'openai' }),
          signal: AbortSignal.timeout(20000)
        }).then(r => r.json()).then(d => d?.choices?.[0]?.message?.content || '');

      fetchAnalysis.then(text => {
        let html = safeHTML(text).replace(/\n/g, '<br>').replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/\*(.+?)\*/g, '<i>$1</i>');
        streamBotMsg('<span style="font-size:0.75rem;color:#0891b2;display:block;margin-bottom:6px">📚 Ders Notu Analizi: ' + studyAnalyzer.filename + '</span>' + html, true);
        gainXP(10, 'Ders Analizi');
      }).catch(e => { addBotMsg('❌ Analiz hatası: ' + e.message, true); });
    });

    bind('btnStudyClear', () => {
      studyAnalyzer.clear();
      document.getElementById('studyFileInfo').style.display = 'none';
      document.getElementById('studyResult').textContent = '';
      document.querySelectorAll('#btnStudyQuiz, #btnStudyAnalyze, #btnStudyClear').forEach(b => b.disabled = true);
    });

    // ===== ESCAPE KEY: Tüm modal/overlay kapat =====
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (document.getElementById('gameOverlay')?.classList.contains('active')) closeGameModal();
        else if (document.getElementById('settingsModal')?.classList.contains('active')) closeSettings();
        else if (document.getElementById('cmdOverlay')?.classList.contains('active')) closeCmdPalette();
      }
    });
})();

// Dynamic Document Binding
document.addEventListener('click', (e) => {
    const btnQCmd = e.target.closest('[data-qcmd]');
    if (btnQCmd) { qCmd(btnQCmd.getAttribute('data-qcmd')); return; }

    const themeBtn = e.target.closest('[data-theme]');
    if (themeBtn) { setTheme(themeBtn.getAttribute('data-theme'), themeBtn); return; }

    // Quiz cevap tıklama (StudyAnalyzer)
    const quizBtn = e.target.closest('[data-quiz-answer]');
    if (quizBtn && AppState.proMode === 'STUDY_QUIZ') {
      const idx = parseInt(quizBtn.dataset.quizAnswer);
      const result = studyAnalyzer.checkAnswer(idx);
      if (result) {
        if (result.correct) {
          addBotMsg('✅ <b>Doğru!</b> ' + result.correctAnswer, true);
          AudioEngine.correct();
        } else {
          addBotMsg('❌ Yanlış. Doğru cevap: <b>' + result.correctAnswer + '</b>', true);
          AudioEngine.wrong();
        }
        if (result.isFinished) {
          AppState.proMode = 'NORMAL';
          addBotMsg(studyAnalyzer.getResultHTML(), true);
          gainXP(result.score * 5, 'Ders Quiz: ' + result.score + '/' + result.total);
          if (result.score >= 4) triggerConfetti();
        } else {
          setTimeout(() => addBotMsg(studyAnalyzer.getQuestionHTML(), true), 600);
        }
      }
      return;
    }
});

// ===== STUDY FILE HANDLER (TXT + PDF) =====
async function handleStudyFile(file) {
  if (file.size > 500 * 1024) {
    document.getElementById('studyResult').innerHTML = '<span style="color:#ef4444">❌ Dosya 500KB sınırını aşıyor.</span>';
    return;
  }
  try {
    let text = '';
    if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
      text = await file.text();
    } else if (file.type === 'application/pdf') {
      text = await extractTextFromPDF(file);
    } else {
      document.getElementById('studyResult').innerHTML = '<span style="color:#ef4444">❌ Sadece PDF ve TXT desteklenir.</span>';
      return;
    }

    if (text.length < 50) {
      document.getElementById('studyResult').innerHTML = '<span style="color:#ef4444">❌ Dosyada yeterli metin bulunamadı.</span>';
      return;
    }

    studyAnalyzer.loadText(text, file.name);
    const stats = studyAnalyzer.getStats();

    document.getElementById('studyFileInfo').style.display = 'block';
    document.getElementById('studyFileName').textContent = '✅ ' + file.name;
    document.getElementById('studyFileStats').textContent = stats.words + ' kelime, ' + stats.sentences + ' cümle, ' + stats.chars + ' karakter';
    document.getElementById('studyResult').innerHTML = '<span style="color:#4ade80">Dosya yüklendi! Artık quiz oluşturabilir veya analiz edebilirsiniz.</span>';
    document.querySelectorAll('#btnStudyQuiz, #btnStudyAnalyze, #btnStudyClear').forEach(b => b.disabled = false);

    // Ayrıca ana belleğe de ekle
    Memory.remember('Yüklenen ders notu (' + file.name + '): ' + text.substring(0, 1000));

  } catch (err) {
    document.getElementById('studyResult').innerHTML = '<span style="color:#ef4444">❌ Hata: ' + err.message + '</span>';
  }
}

// EXPOSE GLOBAL FUNCTIONS FOR INLINE HTML ONCLICK HANDLERS
window.openGameInModal = openGameInModal;
window.startSnakeGame = startSnakeGame;
window.startXoxGame = startXoxGame;
window.xoxMv = typeof xoxMv !== 'undefined' ? xoxMv : null;
window.startBreakoutGame = startBreakoutGame;
window.startPongGame = startPongGame;
window.startMinesweeperGame = startMinesweeperGame;
window.startReactionGame = startReactionGame;
window.startShootingGame = startShootingGame;
window.startRacingGame = startRacingGame;
window.startMemoryGame = startMemoryGame;
window.startMathRace = startMathRace;
window.startSudoku = startSudoku;
window.startTimberGame = startTimberGame;








window.selectAvatar = selectAvatar;
window.demoOnboarding = demoOnboarding;
window.completeOnboarding = completeOnboarding;
window.setMode = setMode;
if(typeof qCmd !== 'undefined') window.qCmd = qCmd;
if(typeof deleteNote !== 'undefined') window.deleteNote = deleteNote;
if(typeof drClear !== 'undefined') window.drClear = drClear;
if(typeof drSave !== 'undefined') window.drSave = drSave;
if(typeof stopPomo !== 'undefined') window.stopPomo = stopPomo;
if(typeof pausePomo !== 'undefined') window.pausePomo = pausePomo;
if(typeof feedPet !== 'undefined') window.feedPet = feedPet;
if(typeof playPet !== 'undefined') window.playPet = playPet;
if(typeof sleepPet !== 'undefined') window.sleepPet = sleepPet;
window._advStep = typeof _advStep !== 'undefined' ? _advStep : null;







